const Mock = require('mockjs');

const deptInfo = [
  '机关1-部门1',
  '机关1-部门2',
  '机关2-部门1',
  '机关2-部门2',
  '机关3-部门1',
]

const demoApi = {

  // 获取生命周期
  [`GET /api/virtual/statistic/totalCount`](ctx) {
    // const { dateType } = ctx.request.query || 'year';
    const currentDate = new Date();
    ctx.response.type = 'application/json';
    ctx.response.body = {
      "code": 200,
      "message": "ok",
      "success": true,
      "timestamp": currentDate * 1,
      "result": [
        {
          "name": "普及教育人次",
          "type": "universal",
          "value": Mock.Random.integer(100, 200),
          "counts": Mock.Random.integer(10, 20),
        },
        {
          "name": "专业培训人次",
          "type": "professional",
          "value": Mock.Random.integer(100, 200),
          "counts": Mock.Random.integer(10, 20),
        },
      ],
    }
  },
  // 获取生命周期
  [`GET /api/virtual/statistic/trainingCount`](ctx) {
    // const { dateType } = ctx.request.query || 'year';
    const currentDate = new Date();
    ctx.response.type = 'application/json';
    ctx.response.body = {
      "code": 200,
      "message": "ok",
      "success": true,
      "timestamp": currentDate * 1,
      "result": [
        {
          "name": "参训人次",
          "type": "training",
          "value": Mock.Random.integer(100, 200)
        },
        {
          "name": "未参数人次",
          "type": "no-training",
          "value": Mock.Random.integer(20, 80)
        },
      ],
    }
  },
  // 获取生命周期
  [`GET /api/virtual/statistic/passCount`](ctx) {
    // const { dateType } = ctx.request.query || 'year';
    const currentDate = new Date();
    ctx.response.type = 'application/json';
    ctx.response.body = {
      "code": 200,
      "message": "ok",
      "success": true,
      "timestamp": currentDate * 1,
      "result": [
        {
          "name": "合格人次",
          "type": "pass",
          "value": Mock.Random.integer(100, 200)
        },
        {
          "name": "不合格人次",
          "type": "no-pass",
          "value": Mock.Random.integer(20, 80)
        },
      ],
    }
  },
}

module.exports = demoApi;