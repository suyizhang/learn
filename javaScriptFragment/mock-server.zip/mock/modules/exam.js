const Mock = require('mockjs');

const deptInfo = [
  '机关1-部门1',
  '机关1-部门2',
  '机关2-部门1',
  '机关2-部门2',
  '机关3-部门1',
]

const demoApi = {
  // 获取保密教育人次统计
  [`GET /api/exam/statistic/totalCount`](ctx) {
    const { dateType } = ctx.request.query || 'year';
    const currentDate = new Date();
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth() + 1;
    let list = []
    if (dateType === 'year') {
      for (let i = 0; i < currentMonth; i++) {
        list.push({
          name: `${currentYear}年${i + 1}月`,
          value: Mock.Random.integer(50, 300)
        })
      }
    } else if (dateType === 'month') {
      for (let i = 0; i < 5; i++) {
        list.push({
          name: `第${i + 1}周`,
          value: Mock.Random.integer(10, 100)
        })
      }
    } else if (dateType === 'total') {
      for (let i = 0; i < 12; i++) {
        const month = i < currentMonth ? currentMonth - i : 13 - i;
        const year = i < currentMonth ? currentYear : currentYear - 1;
        list.push({
          name: `${year}年${month}月`,
          value: Mock.Random.integer(50, 300)
        })
      }
      list.reverse();
    }

    ctx.response.type = 'application/json';
    ctx.response.body = {
      "code": 200,
      "message": "ok",
      "success": true,
      "timestamp": currentDate * 1,
      "result": list,
    }
  },
  // 获取生命周期
  [`GET /api/exam/statistic/deptCount`](ctx) {
    // const { dateType } = ctx.request.query || 'year';
    const currentDate = new Date();
    ctx.response.type = 'application/json';
    const result = [];
    for (let i = 0; i < 5; i++) {
      result.push({
        "name": deptInfo[i],
        "value": Mock.Random.integer(50, 300)
      })
    }
    ctx.response.body = {
      "code": 200,
      "message": "ok",
      "success": true,
      "timestamp": currentDate * 1,
      "result": result,
    }
  },
  // 获取生命周期
  [`GET /api/exam/statistic/actualAndPlan`](ctx) {
    // const { dateType } = ctx.request.query || 'year';
    const currentDate = new Date();
    ctx.response.type = 'application/json';
    const count = Mock.Random.integer(200, 400)
    ctx.response.body = {
      "code": 200,
      "message": "ok",
      "success": true,
      "timestamp": currentDate * 1,
      "result": [
        {
          "type": "actual",
          "name": "实际人次",
          "value": Math.ceil(count * Math.random())
        },
        {
          "type": "planning",
          "name": "计划人次",
          "value": count
        },
      ],
    }
  },
  // 获取生命周期
  [`GET /api/exam/statistic/visitedDevice`](ctx) {
    // const { dateType } = ctx.request.query || 'year';
    const currentDate = new Date();
    ctx.response.type = 'application/json';
    ctx.response.body = {
      "code": 200,
      "message": "ok",
      "success": true,
      "timestamp": currentDate * 1,
      "result": [
        {
          "name": "网页端",
          "value": Mock.Random.integer(200, 400)
        },
        {
          "name": "小程序",
          "value": Mock.Random.integer(200, 400)
        },
      ],
    }
  },
  // 获取生命周期
  [`GET /api/exam/statistic/trainingAndExamCount`](ctx) {
    // const { dateType } = ctx.request.query || 'year';
    const currentDate = new Date();
    ctx.response.type = 'application/json';
    ctx.response.body = {
      "code": 200,
      "message": "ok",
      "success": true,
      "timestamp": currentDate * 1,
      "result": [
        {
          "type": "training",
          "name": "培训人次",
          "value": Mock.Random.integer(150, 300)
        },
        {
          "type": "pass",
          "name": "合格人次",
          "value": Mock.Random.integer(100, 150)
        },
        {
          "type": "no-pass",
          "name": "不合格人次",
          "value": Mock.Random.integer(10, 50)
        },
      ],
    }
  },
  // 获取生命周期
  [`GET /api/exam/statistic/certificateCount`](ctx) {
    // const { dateType } = ctx.request.query || 'year';
    const currentDate = new Date();
    ctx.response.type = 'application/json';
    const count = Mock.Random.integer(200, 400)
    ctx.response.body = {
      "code": 200,
      "message": "ok",
      "success": true,
      "timestamp": currentDate * 1,
      "result": [
        {
          "name": "参训人次",
          "type": "total",
          "value": count,
          "counts": Mock.Random.integer(20, 40)
        },
        {
          "name": "发证人次",
          "type": "pass",
          "value": Math.ceil(count * Math.random())
        },
      ],
    }
  },
  // 获取生命周期
  [`GET /api/exam/statistic/trainingClassCount`](ctx) {
    // const { dateType } = ctx.request.query || 'year';
    const currentDate = new Date();
    ctx.response.type = 'application/json';
    ctx.response.body = {
      "code": 200,
      "message": "ok",
      "success": true,
      "timestamp": currentDate * 1,
      "result": [
        {
          "type": "unstart",
          "name": "未开始",
          "value": Mock.Random.integer(50, 100),
          "counts": Mock.Random.integer(2, 10),
        },
        {
          "type": "ongoing",
          "name": "进行中",
          "value": Mock.Random.integer(50, 100),
          "counts": Mock.Random.integer(2, 10),
        },
        {
          "type": "done",
          "name": "已完成",
          "value": Mock.Random.integer(50, 100),
          "counts": Mock.Random.integer(2, 10),
        },
      ],
    }
  },
  // 获取生命周期
  [`GET /api/exam/statistic/eduClassCount`](ctx) {
    // const { dateType } = ctx.request.query || 'year';
    const currentDate = new Date();
    ctx.response.type = 'application/json';
    const result = [];
    for (let i = 0; i < 5; i++) {
      result.push({
        "name": deptInfo[i],
        "value": Mock.Random.integer(50, 300),
        "counts": Mock.Random.integer(5, 20),
      })
    }
    ctx.response.body = {
      "code": 200,
      "message": "ok",
      "success": true,
      "timestamp": currentDate * 1,
      "result": result,
    }
  },
  // 获取生命周期
  [`GET /api/exam/statistic/borrowingCount`](ctx) {
    // const { dateType } = ctx.request.query || 'year';
    const currentDate = new Date();
    ctx.response.type = 'application/json';
    const fileCounts = Mock.Random.integer(500, 1000)
    const serveCounts = Mock.Random.integer(200, 400)
    ctx.response.body = {
      "code": 200,
      "message": "ok",
      "success": true,
      "timestamp": currentDate * 1,
      "result": {
        "serveCounts": serveCounts,
        "borrowCounts": Math.ceil(serveCounts * Math.random()),
        "list": [
          {
            "name": "资料总数",
            "type": "total",
            "value": fileCounts
          },
          {
            "name": "借出数量",
            "type": "borrowing",
            "value": Math.ceil(fileCounts * Math.random())
          },
        ]
      },
    }
  },
}

module.exports = demoApi;