const exam = require('./modules/exam');
const virtual = require('./modules/virtual');

const mockApi = {
  exam,
  virtual
}

module.exports = mockApi;