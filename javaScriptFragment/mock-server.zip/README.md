# mock-server
使用 Koa 和 mockjs 搭建本地服务

## 默认端口 5002 

## 启动命令
```
  npm start
```

## 新建 mock-api
在 `mock` 文件夹下新加文件，按照 demo.js 格式编写模拟接口，模拟数据使用 [mock.js 语法](https://mr-welson.github.io/2018/11/09/2018-11-09-Mock.JS/)
