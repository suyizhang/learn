### `yarn start`

### `yarn build`

### mock-server

`cd mock-server`
`yarn`
`yarn start`


登录未做用户名密码校验 不为空即可，登录状态保存在localStorage中；
本项目默认端口 3000， mock-server 默认 3001，若 3001 端口被占用，则无法请求，更换请求端口可以在 src/utils/remote.config.js 文件下替换 apiUrl 即可;
