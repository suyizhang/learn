import React, { useEffect } from 'react';
import { Route, withRouter } from 'react-router-dom';
import './index.less';

const PrivateRoute = (props) => {
  const { component: Component, history, ...rest } = props;
  const isLogin = window.localStorage.getItem('login') === 'true';
  
  useEffect(() => {
    if (!isLogin) {
      history.push({
        pathname: '/login'
      });
    }
  }, [history, isLogin]);

  return isLogin ?
    <Route {...rest} render={(props) => <Component {...props} />} /> :
    <p className='login'>请登录...</p>;
};

export default withRouter(PrivateRoute);
