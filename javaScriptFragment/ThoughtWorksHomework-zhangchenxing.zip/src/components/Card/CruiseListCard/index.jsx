import React, { useState } from 'react';
import { Input } from 'antd';
import CuriseText from '../../CuriseText';
import Popover from '../../Popover';
import { debounce } from '../../../utils/utils';

import './index.less';

const CruiseListCard = (props) => {
  const { data, updateCruise } = props;
  const addIconRef = React.useRef(null);
  const [visible, setVisible] = useState(false);
  const [inputValue, setInputValue] = useState('');

  const handlerInputChange = (event) => {
    const value = event.target.value;
    setInputValue(value);
  };

  const popverCancel = () => {
    setVisible(false);
    setInputValue('');
  };

  const popverOk = async () => {
    if (!inputValue) {
      return;
    };
    let resources = inputValue.split(',').filter(v => v);
    const option = {
      ...data,
      resources: data.resources.concat(resources),
    };
    await updateCruise(data.id, option);
    popverCancel();
  };

  const overlay = () => {
    return <div className='cruise-list-overlay-view'>
      <div className='cruise-list-message'>Separate multiple resource name with commas</div>
      <i className="cruise-cancel-icon icon-close" />
      <Input placeholder='input value' value={inputValue} onChange={handlerInputChange} />
      <div className='cruise-list-overlay-footer'>
        <div className='cruise-footer-button' onClick={debounce(popverOk, 200)}>Add Resource</div>
        <div className='cruise-footer-button' onClick={debounce(popverCancel, 200)}>Cancel</div>
      </div>
    </div>;
  };

  // delete Resource
  const deleteResource = (value) => {
    const resources = data.resources.filter((v, index) => index !== value);
    updateCruise(data.id, { ...data, resources });
  };

  const showPop = () => {
    if (visible) {
      return;
    }
    setVisible(true);
  };

  const handleVisibleChange = (value) => {
    setVisible(value);
  };

  // deny
  const denyCurise = () => {
    const option = {
      ...data,
      status: 'idle',
    };
    updateCruise(data.id, option);
  };

  return (
    <div className='cruise-list-card-view'>
      <div className='curise-list-left'>
        <i className={`icon-${data.os || 'windows'} curise-icon`}></i>
      </div>
      <div className='curise-list-right'>
        <div className='curise-right-message'>
          <div className='message-title'>
            <CuriseText
              icon='icon-desktop'
              color='#00b4cf'
              text={data.name || ''}
            />
            <span className={`${data.status || ''} curise-status`}>{data.status || ''}</span>
          </div>
          <div className='curise-address'>
            <CuriseText
              icon='icon-info'
              text={data.ip || ''}
              className='curise-address-text'
            />
            <CuriseText
              icon='icon-folder'
              text={data.location || ''}
            />
          </div>
        </div>
        <div className='curise-right-footer'>
          <div className="curise-footer-left">
            <div className='footer-add-icon' onClick={showPop} ref={addIconRef}>
              {
                <Popover
                  placement="bottomLeft"
                  trigger="click"
                  overlay={overlay()}
                  onVisibleChange={handleVisibleChange}
                  visible={visible}
                  arrowProps={{ size: 10 }}
                  container={() => addIconRef.current}
                >
                  <div className='icon-box'>
                    <i className='icon-plus' />
                  </div>
                </Popover>
              }
            </div>
            {data.resources && data.resources.map((v, index) => {
              return (
                <div className='resource-item' key={v}>{v} <i onClick={() => deleteResource(index)} className='icon-trash' /></div>
              );
            })}
          </div>
          <div className="curise-footer-right">
            {data.status === 'building' && <div className="curise-right-deny" onClick={denyCurise}>
              <i className='icon-deny' />
              Deny
            </div>}
          </div>
        </div>
      </div>
    </div>
  );
};

CruiseListCard.defaultProps = {
  data: {
    os: 'windows',
    resources: ["Firefox", "Safari", "Ubuntu", "Chrome"],
  },
};

export default CruiseListCard;
