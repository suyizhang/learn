import React from 'react';
import './index.less';

const historyList = [
  'bjstdmngbdr15.thoughtworks.com/var/lib/cruise-agent',
  'bjstdmngbdr14.thoughtworks.com/var/lib/cruise-agent',
  'bjstdmngbdr12.thoughtworks.com/var/lib/cruise-agent',
  'bjstdmngbdr16.thoughtworks.com/var/lib/cruise-agent',
  'bjstdmngbdr11.thoughtworks.com/var/lib/cruise-agent',
  'bjstdmngbdr10.thoughtworks.com/var/lib/cruise-agent',
  'bjstdmngbdr25.thoughtworks.com/var/lib/cruise-agent',
  'bjstdmngbdr18.thoughtworks.com/var/lib/cruise-agent',
];

const Tabs = (props) => {
  const { list, current, children, onChange } = props;

  const handlerMenu = (value) => {
    // 当前页则不做操作
    if(current === value) {
      return;
    }
    onChange(value);
  }
  return (
    <div className='suyi-tabs-view'>
      <div className='tabs-menu-view'>
        <div className='tabs-menu-content'>
          {list.map(v => {
            return (
              <div
                key={v.code}
                onClick={() => handlerMenu(v.code)}
                className={`${current === v.code ? 'active' : ''} suyi-tabs-item`}
              >
                <i className={`${v.icon} tabs-icon`} />{ v.text}
              </div>
            );
          })}
        </div>
        <div className='tabs-menu-histoy'>
          <div className="history-title">
            History
          </div>
          {historyList.map(v => {
            return (
              <div className='history-item' key={v}>{v}</div>
            );
          })}
        </div>
      </div>
      <div className='tabs-content-view'>
        {children}
      </div>
    </div>
  )
}

Tabs.defaultProps = {
  list: [],
};

export default Tabs;
