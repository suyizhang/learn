import React, { forwardRef } from 'react';
import Overlay from './Overlay';
import DomObserver from './DomObserver';
import { combineRef } from './utils';

import './index.less';

const isPointerEventSupported = !!window.PointerEvent;
const isTouchEventSupported = !!window.TouchEvent;

const safeCall = (fn, ...args) => {
  if (typeof fn === 'function') {
    fn(...args);
  }
}

class Popover extends React.Component {
  constructor(props) {
    super(props)
    this.triggerRef = React.createRef();
    this.overlayRef = React.createRef();
    this.state = {
      visible: false,
      hasEvent: false,
    };
  }

  static getDerivedStateFromProps(props, state) {
    // resolve dom node change
    if (props.visible !== state.visible && typeof props.visible === 'boolean') {
      return {
        visible: props.visible
      };
    }
    return null;
  }

  componentDidUpdate(preProps, preState) {
    const { visible, hasEvent } = this.state;
    if (preState.visible !== visible && visible === true && !hasEvent) {
      document.addEventListener('click', this.handleBody);
      this.setState({ hasEvent: true });
    }
    if (preState.visible !== visible && visible === false && hasEvent) {
      document.removeEventListener('click', this.handleBody);
      this.setState({ hasEvent: false });
    }
  }

  componentWillUnmount() {
    document.removeEventListener('click', this.handleBody);
  };

  handleBody = (e) => {
    if (this.overlayRef && this.triggerRef) {
      const overCurrent = this.overlayRef.current;
      const triggerCurrent = this.triggerRef.current;
      // 第一次打开时会冒泡 会触发一次  所以需要判断点击是不是当前div
      // 组件已挂载且事件触发对象不在div内
      if (!e.path.find(v => v === triggerCurrent) && !e.path.find(v => v === overCurrent.overlayRef.current)) {
        this.close();
      }
    }
  };

  getChildProps() {
    return this.props.children.props;
  }

  handleMouseEnter = (e) => {
    safeCall(this.getChildProps().onMouseEnter, e);
    if (!isPointerEventSupported && !isTouchEventSupported) {
      this.open();
    }
  }

  handleMouseLeave = (e) => {
    safeCall(this.getChildProps().onMouseLeave, e);
    if (!isPointerEventSupported && !isTouchEventSupported) {
      this.close();
    }
  }

  handlePointerEnter = (e) => {
    safeCall(this.getChildProps().onPointerEnter, e);
    if (e.pointerType === 'mouse') {
      this.open();
    }
  }

  handlePointerLeave = (e) => {
    safeCall(this.getChildProps().onPointerLeave, e);
    if (e.pointerType === 'mouse') {
      this.close();
    }
  }

  handleClick = (e) => {
    safeCall(this.getChildProps().onClick, e);
    if (this.state.visible) {
      this.close();
    } else {
      this.open();
    }
  }

  handleFocus = (e) => {
    safeCall(this.getChildProps().onFocus, e);
    this.open();
  }

  handleBlur = (e) => {
    safeCall(this.getChildProps().onBlur, e);
    this.close();
  }

  getTriggerProps = () => {
    const { trigger } = this.props;
    const triggerProps = {};
    if (trigger.indexOf('hover') !== -1) {
      triggerProps.onMouseEnter = this.handleMouseEnter;
      triggerProps.onMouseLeave = this.handleMouseLeave;
      triggerProps.onPointerEnter = this.handlePointerEnter;
      triggerProps.onPointerLeave = this.handlePointerLeave;
    }
    if (trigger.indexOf('focus') !== -1) {
      triggerProps.onFocus = this.handleFocus;
      triggerProps.onBlur = this.handleBlur;
    }
    if (trigger.indexOf('click') !== -1) {
      triggerProps.onClick = this.handleClick;
    }
    return triggerProps;
  }

  open = () => {
    const { onVisibleChange } = this.props;
    if (onVisibleChange) {
      onVisibleChange(true);
    } else {
      this.setState({ visible: true });
    }
  }

  close = () => {
    const { onVisibleChange } = this.props;
    if (onVisibleChange) {
      onVisibleChange(false);
    } else {
      this.setState({ visible: false });
    }
  }

  getTrigger = () => {
    return this.triggerRef.current;
  }

  scheduleUpdate = () => {
    const { current: overlayInstance } = this.overlayRef;
    if (overlayInstance) {
      overlayInstance.adjustPosition();
    }
  };

  render() {
    const { visible } = this.state;
    const { children, forwardRef, container, overlay, arrowProps, placement } = this.props;
    const child = React.Children.only(children);
    return (
      <React.Fragment>
        <DomObserver ref={combineRef(this.triggerRef, forwardRef)} onMeasure={this.scheduleUpdate}>
          {(child != null && child !== false) && React.cloneElement(child, this.getTriggerProps())}
        </DomObserver>
        {visible &&
          <Overlay
            arrowProps={arrowProps}
            container={container()}
            placement={placement}
            getTrigger={this.getTrigger}
            ref={this.overlayRef}
          >
            {overlay}
          </Overlay>
        }
      </React.Fragment>
    )
  }
}

Popover.defaultProps = {
  arrowProps: {
    size: 0,
  },
}

export default forwardRef((props, ref) => {
  return <Popover {...props} forwardRef={ref} />
});
