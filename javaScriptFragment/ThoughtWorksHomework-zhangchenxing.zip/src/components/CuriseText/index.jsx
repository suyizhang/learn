import React from 'react';
import './index.less';

const CuriseText = (props) => {
  const { icon, text, color, className } = props;
  return (
    <span className={`${className} curise-text-view`}>
      <i className={`${icon} curise-text-icon`} />
      <span className='curise-text-message' style={{ color: color }}>{text}</span>
    </span>
  );
};
CuriseText.defaultProps = {
  icon: 'icon-desktop',
  text: '',
  color: '#000',
  className: ''
}

export default CuriseText;