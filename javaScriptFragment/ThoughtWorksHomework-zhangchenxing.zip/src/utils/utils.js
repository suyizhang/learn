export function throttle(func, delay) {
  let previous = Date.now();
  return function () {
    const now = Date.now();
    const context = this;
    const args = [...arguments];
    if (now - previous > delay) {
      func.apply(context, args);
      previous = now;
    }
  };
}

export function debounce(func, wait) {
  let timeout = null;
  return function () {
    const context = this;
    const args = [...arguments];
    if (timeout) {
      clearTimeout(timeout);
    }
    timeout = setTimeout(() => {
      func.apply(context, args);
    }, wait);
  };
}
