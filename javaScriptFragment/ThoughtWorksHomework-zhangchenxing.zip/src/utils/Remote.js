import Axios from 'axios';
import _forEach from 'lodash.foreach';
import _isEmpty from 'lodash.isempty';
import Config from './remote.config';

class Remote {
  static METHOD = {
    GET: 'GET',
    POST: 'POST',
    PUT: 'PUT',
  };

  constructor() {
    this.axios = Axios.create();
    this.initInterceptors();
  }

  initInterceptors = () => {
    this.axios.interceptors.response.use(
      (response) => {
        return response;
      },
      (error) => {
        try {
          return Promise.reject(error.response.data);
        } catch (e) {
          // 处理超时
          if (error.code === 'ECONNABORTED' && error.message.indexOf('timeout') >= 0) {
            // 覆盖超时信息
            error.message = '请求超时，请刷新页面';
          }
          // 处理取消请求等错误
          return Promise.reject(error);
        }
      }
    );
  };

  /**
   * 获取当前所处环境。
   * 通过配置node环境变量来获取
   * 暂定
   * 开发环境： development
   * 线上环境： production
   * @return string
   */
  getEnv = () => {
    return process.env.NODE_ENV || 'production';
  };

  /**
   *  依照环境生成域名
   *  @return string
   */
  genDomainForEnv = (type) => {
    const env = this.getEnv();
    const typeJson = {
      default: `${Config[env].apiUrl}${Config[env].apiUrlFilter}`,
      auth: `${Config[env].authUrl}${Config[env].authUrlFilter}`,
      qiniu: `${Config[env].qiniuUrl}`,
      im: `${Config[env].imUrl}`,
      invoice: `${Config[env].targetInvoiceUrl}`,
      map: `${Config[env].tenxunMapUrl}`,
    };
    return typeJson[type];
  };

  genQuery = (queryData) => {
    if (_isEmpty(queryData)) return '';
    let ret = '';
    // if (Device.isIE()) queryData.timestamp = new Date().getTime();
    _forEach(queryData, (val, key) => {
      if (typeof val !== 'undefined') {
        ret += `&${key}=${encodeURIComponent(val)}`;
      }
    });
    return ret.replace(/&/, '?');
  };

  getHttpConfig = (method, url, data, type, header) => {
    let sendURL = url;
    const config = Object.assign(
      {},
      {
        url: sendURL,
        withCredentials: true,
        method,
      }
    );
    if (method === Remote.METHOD.GET) {
      sendURL += this.genQuery(data);
      config.url = sendURL;
    } else {
      let contentType = '';
      let cfgData = data;
      switch (type) {
        case 'json':
          contentType = 'application/json';
          cfgData = JSON.stringify(data || {});
          break;
        default:
          break;
      }
      config.headers = { 'Content-Type': contentType };
      config.data = cfgData;
    }
    return config;
  };

  http = async ({ method, url, header, type = 'json', data = {} }) => {
    Object.keys(data).forEach((v) => {
      if (data[v] === undefined) {
        delete data[v];
      }
    });
    const options = this.getHttpConfig(method, url, data, type, header);
    try {
      const res = await this.axios.request(options);
      return res;
    } catch (error) {
      console.error(error);
      return error;
    }
  };

  get = async (url, data, urlType) => {
    const options = {
      data,
      url: `${this.genDomainForEnv(urlType || 'default')}${url}`,
      method: Remote.METHOD.GET,
    };
    const res = await this.http(options);
    return res;
  };

  post = async (url, data, urlType) => {
    const options = {
      data,
      url: `${this.genDomainForEnv(urlType || 'default')}${url}`,
      method: Remote.METHOD.POST,
      header: {
        'content-type': 'application/x-www-form-urlencoded;charset=UTF-8',
      },
    };
    const res = await this.http(options);
    return res;
  };

  put = async (url, data, urlType) => {
    const options = {
      data,
      url: `${this.genDomainForEnv(urlType || 'default')}${url}`,
      method: Remote.METHOD.PUT,
    };
    const res = await this.http(options);
    return res;
  };
}

const remote = new Remote();

const Request = {
  remote,
  get: remote.get,
  post: remote.post,
  put: remote.put,
};

export default Request;
