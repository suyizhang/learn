const url = {
  development: {
      apiUrl: 'http://localhost:3001',
      apiUrlFilter: '/',
      proxyFilter: '/',
      port: 8017,
      autoOpenBrowser: true,
  },
  production: {
      apiUrl: 'http://localhost:3001',
      apiUrlFilter: '/',
      proxyFilter: '/',
  },
};

module.exports = url;
