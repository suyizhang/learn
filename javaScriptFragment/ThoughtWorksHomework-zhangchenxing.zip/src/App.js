import React from 'react';
import { BrowserRouter, Route, Switch, Redirect } from 'react-router-dom';
import PrivateRoute from './components/PrivateRoute';
import Layout from './view/Layout';
import Login from './view/Login';

function App() {
  return (
    <BrowserRouter>
      <Switch>
        <PrivateRoute path='/' exact component={Layout} />
        <Route path='/login' exact component={Login} />
        <Redirect from='/' to='/' />
      </Switch>
    </BrowserRouter>
  );
}

export default App;
