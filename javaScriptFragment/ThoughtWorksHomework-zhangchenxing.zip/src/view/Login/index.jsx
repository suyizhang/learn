import React, { useEffect } from 'react';
import { Form, Button, Input } from 'antd';
import { withRouter } from 'react-router-dom';
import './index.less';

const Login = (props) => {
  const { history } = props;

  useEffect(() => {
    // 判断是否登录  已登录则跳转至首页
    const isLogin = window.localStorage.getItem('login') === 'true';
    if (isLogin) {
      history.push({
        pathname: '/'
      });
    }
  }, [history]);

  const onFinish = values => {
    window.localStorage.setItem('login', true);
    history.push({
      pathname: '/'
    });
  }

  return (
    <div className='login-view'>
      <div className='login-header'>ThoughtWorks</div>
      <div className='login-content'>
        <Form labelCol={{ span: 6 }} wrapperCol={{ span: 18 }} onFinish={onFinish}>
          <Form.Item
            label='Username'
            name='username'
            rules={[{ required: true, message: 'Please input your username!' }]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            label='Password'
            name='password'
            rules={[{ required: true, message: 'Please input your password!' }]}
          >
            <Input type='password' />
          </Form.Item>
          <Button type='primary' htmlType='submit'>
            Login
          </Button>
        </Form>
      </div>
    </div>
  );
};

export default withRouter(Login);
