import React, { useEffect, useState, useMemo } from 'react';
import CruiseSearch from './components/CruiseSearch';
import CruiseList from './components/CruiseList';
import Service from './Services';
import './index.less';

const Cruise = () => {
  const [searchData, setSearchData] = useState({
    status: '',
    type: '',
    q: '',
  });
  const [list, setList] = useState([]);
  const listLen = list.length;
  let virtualLen = 0, buildLen = 0;

  list.forEach((v) => {
    if (v.status === 'building') {
      buildLen++;
    }
    if (v.type === 'virtual') {
      virtualLen++;
    }
  });

  useEffect(() => {
    const getCruiseList = async () => {
      const option = {
        status: searchData.status || undefined,
        type: searchData.type || undefined,
        q: searchData.q || undefined,
      };
      try {
        const res = await Service.getCruiseList(option);
        setList(res.data);
      } catch (error) {

      }
    };
    getCruiseList();
  }, [searchData]);

  const cruiseList = useMemo(() => {
    return <CruiseList
      data={list}
      setSearchData={setSearchData}
      searchData={searchData}
    />;
  }, [list, searchData, setSearchData]);

  return (
    <div className='suyi-cruise-view'>
      <div className='suyi-cruise-header'>
        <div className='cruise-header-card build'>
          <div className='header-text'>Building</div>
          <i className='headr-icon icon-cog'></i>
          <span className='header-total'>{buildLen}</span>
        </div>
        <div className='cruise-header-card idle'>
          <div className='header-text'>Idle</div>
          <i className='headr-icon icon-coffee'></i>
          <span className='header-total'>{listLen - buildLen}</span>
        </div>
        <div className='cruise-header-card total'>
          <div className='total-info'>
            <div className='info'>ALL</div>
            <div className='number'>{listLen}</div>
          </div>
          <div className='total-info'>
            <div className='info'>PHYSICAL</div>
            <div className='number'>{listLen - virtualLen}</div>
          </div>
          <div className='total-info'>
            <div className='info'>VIRTUAL</div>
            <div className='number'>{virtualLen}</div>
          </div>
        </div>
      </div>
      <div className='suyi-cruise-content'>
        <CruiseSearch searchData={searchData} setSearchData={setSearchData} />
        {cruiseList}
      </div>
    </div>
  );
};

Cruise.defaultProps = {

};

export default Cruise;
