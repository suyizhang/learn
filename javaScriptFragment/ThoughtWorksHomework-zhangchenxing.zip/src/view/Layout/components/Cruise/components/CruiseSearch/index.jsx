import React, { useState, useEffect } from 'react';
import { Input } from 'antd';
import './index.less';

const itemList = [
  { text: 'All', code: '' },
  { text: 'Physical', code: 'physical' },
  { text: 'Virtual', code: 'virtual' },
]

const CruiseSearch = (props) => {
  const { searchData, setSearchData } = props;
  const [inputValue, setInputValue] = useState(searchData.q);
  const [cardType, setCardType] = useState(1);
  const { type } = searchData;

  const inputChange = (event) => {
    setInputValue(event.target.value.trim());
  };

  useEffect(() => {
    setInputValue(searchData.q);
  }, [searchData.q]);

  const onPressEnter = () => {
    setSearchData({ ...searchData, q: inputValue });
  };

  return (
    <div className='cruise-search-view'>
      <div className='search-left'>
        <div className='search-tabs'>
          {itemList.map(v => {
            return (<div
              key={v.code}
              onClick={() => setSearchData({ ...searchData, type: v.code })}
              className={`${type === v.code ? 'active' : ''} search-tabs-item`}
            >
              {v.text}
            </div>);
          })}
        </div>
        <div className='search-input'>
          <Input
            type="text"
            value={inputValue}
            placeholder='Enter'
            prefix={<i className='icon-search' />}
            onChange={inputChange}
            onPressEnter={onPressEnter}
          />
        </div>
      </div>
      <div className='search-right'>
        <i
          className={`${cardType === 0 ? 'active' : ''} search-icon icon-th-card`}
          onClick={() => setCardType(0)}
        />
        <i
          className={`${cardType === 1 ? 'active' : ''} search-icon icon-th-list`}
          onClick={() => setCardType(1)}
        />
      </div>
    </div>
  )
};

CruiseSearch.defaultProps = {
  searchData: {
    type: '',
  }
};

export default CruiseSearch;