import React from 'react';
import CruiseListCard from '../../../../../../components/Card/CruiseListCard';
import './index.less';
import Services from '../../Services';


const CruiseList = (props) => {
  const { data, setSearchData, searchData } = props;

  const updateCruise = async (id, params) => {
    try {
      await Services.updateCruise(id, params);
      setSearchData({...searchData});
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className='cruise-list-view'>
      { data.map(v => {
        return (<CruiseListCard key={v.id} data={v} updateCruise={updateCruise} />);
      })}
    </div>
  );
};

CruiseList.defaultProps = {
  data: [],
};

export default CruiseList;