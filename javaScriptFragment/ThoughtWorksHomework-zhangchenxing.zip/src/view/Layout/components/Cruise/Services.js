import Remote from '../../../../utils/Remote';

class CruiseService {
  getCruiseList = (params) => {
    return Remote.get('agents', params);
  };

  updateCruise = (id, params) => {
    return Remote.put(`agents/${id}`, params);
  };
  
}

export default new CruiseService();
