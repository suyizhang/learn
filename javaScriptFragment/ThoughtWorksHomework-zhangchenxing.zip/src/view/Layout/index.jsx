import React, { useState, useCallback } from 'react';
import { withRouter } from 'react-router-dom';
import Popover from '../../components/Popover';
import Tabs from '../../components/Tabs';
import Cruise from './components/Cruise';
import './index.less';

const menuList = [
  { text: 'DASHBOARD', code: '10001', icon: 'icon-dashboard' },
  { text: 'AGENT', code: '10002', icon: 'icon-sitemap' },
  { text: 'MY CRUISE', code: '10003', icon: 'icon-boat' },
  { text: 'HELP', code: '10004', icon: 'icon-life-bouy' },
];

const Layout = (props) => {
  const { history } = props;
  const layoutRef = React.useRef(null);
  const [loginVisible, setLoginVisible] = useState(false);
  const [menuCurrent, setMenuCurrent] = useState('10003');

  // 退出登录
  const signOut = () => {
    window.localStorage.setItem('login', false);
    handleVisibleChange(false);
    history.push({
      pathname: '/login'
    });
  };

  const overlay = () => {
    return <div className='overlay-login-view'>
      <div className='overlay-login-item'>
        <i className='icon-id-card login-icon' />
        Profile
      </div>
      <div className='overlay-login-item' onClick={signOut}>
        <i className='icon-sign-in login-icon' />
        Sign Out
      </div>
    </div>;
  };

  const handleVisibleChange = (value) => {
    setLoginVisible(value);
  };

  const tabsRender = useCallback(() => {
    let render = null;
    switch (menuCurrent) {
      case '10001':
        render = <div>DASHBOARD</div>;
        break;
      case '10002':
        render = <div>AGENT</div>;
        break;
      case '10003':
        render = <Cruise />;
        break;
      case '10004':
        render = <div>HELP</div>;
        break;
      default:
        render = null;
    };
    return render;
  }, [menuCurrent]);

  return (
    <div className="layout-view">
      <div className="layout-header">
        <div />
        <div className="header-logo" />
        <div className="header-sign" ref={layoutRef}>
          <Popover
            placement="bottom"
            trigger="click"
            overlay={overlay()}
            onVisibleChange={handleVisibleChange}
            visible={loginVisible}
            arrowProps={{ size: 10 }}
            container={() => layoutRef.current}
          >
            <img className='sign-image' src="https://picsum.photos/40/40" alt="" />
          </Popover>
        </div>
      </div>
      <div className="layout-content">
        <Tabs
          list={menuList}
          current={menuCurrent}
          onChange={setMenuCurrent}
        >
          {tabsRender()}
        </Tabs>
      </div>
      <div className="layout-footer">Copyright:Thoughtworks Inc.</div>
    </div>
  );
};

export default withRouter(Layout);
