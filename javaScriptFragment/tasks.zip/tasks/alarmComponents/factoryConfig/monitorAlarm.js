import { handleMonitorTaskSource } from '../utils';
const { Service } = window;
/**
 * tips: 查询任务列表的数据来源后台字段不一致
 * 包含如下模块:
 * 人员入侵, 重点人员，外来人员
 */

export default {
  queryListAction: async searchData => {
    try{
      const { taskSource, taskStatus, keywords, ...options } = searchData;
      let res = await Service.monitorTask.queryMonitorTasks({ 
        ...options, 
        name: keywords,
        taskStatuses: taskStatus === -1 ? undefined : [taskStatus],
        queryType: handleMonitorTaskSource(taskSource)
      }, true);
      const list = res.data.list || [];
      if(list.length > 0){
        const taskIds = list.map(v => v.id);
        let countResult = await Service.monitorTask.countTaskUnhandledNum(taskIds);
        const countData = countResult.data || {};
        list.forEach(item => {
          // 是否忽略布控告警
          item.isPush = item.ignoreStatus;
          if (countData[item.id]) {
            item.unhandledAlarmCount = countData[item.id]
          }
        })
      }
      return list;
    }catch(err){
      console.log('出错信息：',err);
    }
    
  },
  // 忽略订阅任务的实时推送
  setIgnoreAction: options => {
    const { id, isPush } = options;
    return Service.monitorTask.setWhetherIgnoreAlarm({
      taskId: id, ignore: isPush
    });
  },
  queryAlarmListAction: searchData => {
    const { taskTypeCode, offset, limit, ...options } = searchData;
    return Promise.all([
      Service.alarmResult.queryAlarmResults({
        offset, 
        limit, 
        ...options,
      }),
      Service.alarmResult.countAlarmResults({
        ...options
      })
    ]).then(res => {
      const [listData, countData] = res;
      listData.data.total = countData.data.total || 0;
      return listData;
    })
  },
  // 处理任务
  handleAlarmAction: ({item, isEffective}, alarmProps) => {
    const { libType } = alarmProps;
    let param = {
      id: item.id,
      isEffective
    }
    return Service.alarmResult.handleAlarmResult(param, { libType });
  }
}