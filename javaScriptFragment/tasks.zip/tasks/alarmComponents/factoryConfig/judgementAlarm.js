import { handleAssessmentTaskSource, handleAssessmentTaskStatus } from '../utils';
const { Service } = window;
export default {
  queryListAction: async searchData => {
    try{
      // 查询任务列表
      const { taskSource, taskStatus, ...rest } = searchData;
      let res = await Service.intelligentJudgement.queryTasks({
        source: handleAssessmentTaskSource(taskSource),
        status: handleAssessmentTaskStatus(taskStatus) ? [handleAssessmentTaskStatus(taskStatus)] : [],
        ...rest
      });
      const list = res.data.list || [];
      if(list.length > 0){
        const taskIds = list.map(v => v.id);
        // 查询任务对应的告警数量
        const options = {
          assessmentType: searchData.types[0],
          taskIds
        }
        let countResult = await Service.intelligentJudgement.countTaskWarnings(options);
        const countData = countResult.data || {};
        list.forEach(item => {
          // 相关字段兼容组件
          let taskStatus = handleAssessmentTaskStatus(item.status);
          item.taskStatus = taskStatus;
          item.isPush = item.ignoreStatus === 0 ? 1 : 0;
          if (countData[item.id]) {
            item.unhandledAlarmCount = countData[item.id];
          }
        })
      }
      return list;
    }catch(err){
      console.log('出错信息：',err);
    }
    
  },
  // 忽略订阅任务的实时推送
  setIgnoreAction: options => {
    const { id, isPush } = options;
    return Service.intelligentJudgement.setIgnoreAlarm({
      id, ignore: isPush === 0 ? 1 : 0
    });
  },
  queryAlarmListAction: searchData => {
    const { taskTypeCode, ...options } = searchData;
    return Service.intelligentJudgement.houseQueryWarnings({
      assessmentTypes: [taskTypeCode],
      ...options
    });
  }
}