const { Service } = window;
export default {
  queryListAction: async searchData => {
    try{
      // 查询任务列表
      const { taskSource, taskStatus, ...options } = searchData;
      let res = await Service.subscription.queryTasks({ 
        ...options, 
        status: taskStatus === -1 ? undefined : taskStatus,
        source: taskSource
      });
      const list = res.data.list || [];
      if(list.length > 0){
        const taskIds = list.map(v => v.id);
        // 查询任务对应的告警数量
        const options = {
          eventType: searchData.types[0],
          taskIds
        }
        let countResult = await Service.subscription.countTaskUnhandledNum(options);
        const countData = countResult.data || {};
        list.forEach(item => {
          // 相关字段兼容组件
          item.name = item.taskName;
          if (countData[item.id]) {
            item.unhandledAlarmCount = countData[item.id]
          }
        })
      }
      return list;
    }catch(err){
      console.log('出错信息：',err);
    }
    
  },
  // 忽略订阅任务的实时推送
  setIgnoreAction: options => {
    return Service.subscription.setIgnoreAlarm(options);
  },
  queryAlarmListAction: searchData => {
    const { taskTypeCode, ...options } = searchData;
    return Service.intelligentJudgement.queryXJGatherResults({
      ...options
    });
  }
}