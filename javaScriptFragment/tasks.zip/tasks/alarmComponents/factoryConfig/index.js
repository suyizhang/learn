import judgementAlarm from './judgementAlarm'; // 研判任务
import subscribeAlarm from './subscribeAlarm'; // 订阅（包括研判下的xj聚集）
import monitorAlarm from './monitorAlarm'; // 人员入侵
import vehicleAlarm from './vehicleAlarm'; // 布控中心下的车辆

export default {
  judgementAlarm,
  subscribeAlarm,
  monitorAlarm,
  vehicleAlarm
}