/**
 * tips: 这里是刚哥的接口
 * 包含如下模块：
 * 重点车辆布控，外来车辆布控，车辆标签布控
 */

import moment from 'moment';
// import _ from 'lodash';
const { Service } = window;

export default {
  queryListAction: async searchData => {
    try{
      const { taskSource, taskStatus, keywords, ...options } = searchData;
      let res = await Service.monitorTask.getTasks({ 
        ...options, 
        taskName: keywords,
        taskStatus: taskStatus === -1 ? undefined : taskStatus,
        source: taskSource
      }, true);
      const list = res.data.list || [];
      if(list.length > 0){
        const taskIds = list.map(v => v.id);
        let countResult = await Service.monitorTask.countAlarmByTaskId({ taskIds, isHandle: 0 });
        const countData = countResult.data || {};
        list.forEach(item => {
         // 相关字段兼容组件
          item.name = item.taskName;
          if (countData[item.id]) {
            item.unhandledAlarmCount = countData[item.id]
          }
        })
      }
      return list;
    }catch(err){
      console.log('出错信息：',err);
    }
    
  },
  // 忽略订阅任务的实时推送
  setIgnoreAction: options => {
    const { id, isPush } = options;
    return Service.monitorTask.updateTaskPush({
      taskId: id, isPush
    });
  },
  queryAlarmListAction: searchData => {
    let { 
      taskIds, offset, limit, installationSites,
      startTime, endTime, alarmOperationType
    } = searchData;
    // 时间处理，车辆告警的时间必传，默认给一年
    if(!startTime && !endTime){
      startTime = moment()
      .subtract(1, 'year')
      .set({ hour: 0, minute: 0, second: 0 })
      .valueOf();
      endTime = moment().valueOf();
    }
    const options = {
      placeTags: installationSites,
      alarmOperationType: alarmOperationType === -1 ? undefined : alarmOperationType,
      startTime,
      endTime,
      taskIds,
      alarmType: 2
    }
    return Promise.all([
      Service.alarmResult.getTaskAlarmsResult({
        offset, 
        limit,
        ...options,
      }),
      Service.alarmResult.countTaskAlarmsResult({
        ...options
      })
    ]).then(res => {
      const [listData, countData] = res;
      listData.data.total = countData.data.total || 0;
      return listData;
    })
  },
  // 处理任务
  handleAlarmAction: ({item, isEffective}, alarmProps) => {
    const { libType } = alarmProps;
    let param = {
      id: item.id,
      isEffective
    }
    return Service.alarmResult.updateTaskAlarm(param, { libType });
  }
}