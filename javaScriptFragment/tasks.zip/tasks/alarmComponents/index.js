/**
 * tips: 2020/5/25 10:29
 * 新增在所有的factoryAction操作中，加入第二个参数alarmconfig,用于不同告警，
 * 相同逻辑的告警的简单的判断处理，如果逻辑差别较大的情况下，建议新建factory自行处理
 */
import React, { useState, useEffect, useMemo } from 'react';
import taskListComps from './taskList'; // 布控任务列表
import AlarmList from './alarmList';
import alarmConfig from './alarmConfig';
import { message } from 'antd';
import _ from 'lodash';
const { Loader, SocketEmitter } = window;
const TwoColumnLayout = Loader.loadBaseComponent('Layout', 'TwoColumnLayout');
// 初始列表的搜索条件 -- 后期需要更改就通过alarmConfig去覆盖
const initSearchData = {
  taskSource: 0,
  taskStatus: 1, // 默认告警列表都是展示运行中
  limit: 500,
  offset: 0
};

function Alarm(props) {
  const { type } = props;
  // 告警的相关配置
  const alarmProps = useMemo(() => alarmConfig[type], [type]);
  const [taskList, setTaskList] = useState([]);
  const [taskIds, setTaskIds] = useState([]);
  const [searchData, setSearchData] = useState(() => {
    let searchData = alarmProps.searchData || {};
    return { ...initSearchData, ...searchData }
  });
  // 查询任务列表
  useEffect(() => {
    const { queryListAction } = alarmProps.factory;
    queryListAction(searchData, alarmProps).then(list => {
      let taskIds = list.map(v => v.id);
      setTaskIds(taskIds);
      setTaskList(list);
    }).catch(() => {
      message.error('任务查询失败');
    })
  }, [searchData, alarmProps]);

  // socket监听处理告警
  useEffect(() => {
    function updateUnhandledAlarmCount(data){
      let taskListData = _.cloneDeep(taskList);
      let item = taskListData.find(v => v.id === data.taskId);
      if (item) {
        item.unhandledAlarmCount = item.unhandledAlarmCount - 1;
        setTaskList(taskListData);
      }
    }
    SocketEmitter.on(SocketEmitter.eventName.handleAlarmSuccess, updateUnhandledAlarmCount);
    return () => {
      SocketEmitter.off(SocketEmitter.eventName.handleAlarmSuccess, updateUnhandledAlarmCount);
    }
  }, [taskList])

  // 查询任务列表的参数修改
  function changeSearchData(options){
    let searchDataNew = { ...searchData, ...options};
    setSearchData(searchDataNew);
  }

  // 设置当前选择任务
  function changeAlarmTask(taskId){
    setTaskIds([taskId]);
  }

  // 修改选中的状态
  function changeCheckAllStatus(e){
    let value = e.target.checked;
    setTaskIds(value ? taskList.map(v => v.id) : []);
  }

  // 任务告警状态设置后的回调
  function changeTaskIgnore(id){
    let taskListNew = taskList.map(v => {
      if(v.id === id){
        v.isPush = v.isPush === 0 ? 1 : 0
      }
      return v;
    })
    setTaskList(taskListNew);
  }
  // 任务列表选择
  const { taskListType='BaseList' } = alarmProps;
  const TaskList = useMemo(() => taskListComps[taskListType] || null, [taskListType]);
  return (
    <TwoColumnLayout
      leftContent={
        <TaskList
          taskIds={taskIds}
          searchData={searchData}
          taskList={taskList}
          changeSearchData={changeSearchData}
          alarmProps={alarmProps}
          changeAlarmTask={changeAlarmTask}
          changeCheckAllStatus={changeCheckAllStatus}
          changeTaskIgnore={changeTaskIgnore}
        />
      }
    >
      <AlarmList alarmProps={alarmProps} {...props} taskIds={taskIds} />
    </TwoColumnLayout>
  );
}

export default Alarm;
