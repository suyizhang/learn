import BaseList from './components/baseList';

// 任务列表组件集合
export default {
  BaseList
}