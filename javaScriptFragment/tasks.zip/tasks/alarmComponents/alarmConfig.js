/**
 * @author tlzj
 * @createTime 2020/5/20
 * 基础参数相关
 * @param alarmType 告警类型（自定义）
 * @param taskTypeCode 任务类型对应的code
 * @param detailModuleName 告警详情
 * @param privName 告警处理权限 (暂时没用到，因为卡片里面之前已经做了判断)
 * @param searchData 任务列表查询的相关默认参数
 * @param factory 接口和参数相关处理(service集合, 和一些方法集合)
 * @param alarmSearchData 告警列表自定义搜索条件(初始条件)
 * @param alarmComponents protal + 筛选条件 + 告警列表
 * @param (*) 其他参数可以自定义
 * 比如如下：
 * @param cardListParams 如果卡片模块使用baseCardList组件，这个配置需要提供
 * @param hasRefresh protal组件是否有刷新按钮
 * @param libType 当前代码用不到，兼容跳转详情的代码，以及卡片层面，日志记录的相关判断
 * 
 */

import factoryConfig from './factoryConfig'; // 接口参数处理集合

export default {
  idlehousehasPerson: { 
    alarmType: 'idlehousehasPerson',
    taskTypeCode: '101551',
    factory: factoryConfig['judgementAlarm'],
    detailModuleName: 'personRecord',
    searchData: {
      types: ['101551'],
    }, // 任务列表搜索条件
    alarmSearchData: {}, // 告警列表自定义搜索条件(初始条件)
  },
  xjPersonGathered: {
    alarmType: 'xjPersonGathered',
    taskTypeCode: '101558',
    factory: factoryConfig['subscribeAlarm'],
    searchData: {
      types: ['101558'],
    },
  },
  // 重点人员告警
  focusMonitor: {
    alarmType: 'focusMonitor',
    taskTypeCode: '101501',
    detailModuleName: 'focusDetail',
    privName: 'focusHandle',
    libType: 1, // 用在卡片，日志，详情
    factory: factoryConfig['monitorAlarm'],
    searchData: {
      taskTypes: ['101501'],
    },
    alarmSearchData: {
      sort: ["captureTime|desc"], // 默认按时间排序
      alarmOperationType: -1, // 默认为全部
      alarmTypes: ['1'], 
    },
    alarmComponents: ['PortalTotal', 'FocusFilter', 'BaseCardList'],
    cardListParams: {
      itemHeight: 340, // 卡片的高度
      offsetOptions: {
        xxl: 2, // ≥1600px
        xl: 1, // ≥1200px
        lg: 2, // ≥992px
        md: 1, // ≥768px
        sm: 0, // ≥576px
        xs: 4, // <576px 
      }, //ListBox组件的配置
      gutter: 10, // 卡片的间距
      itemGrid: {
        xxl: 6, // ≥1600px
        xl: 8, // ≥1200px
        lg: 12, // ≥992px
        md: 12, // ≥768px
        sm: 12, // ≥576px
        xs: 24, // <576px 
      }, // InfiniteScrollLayout的配置
      cardType: 'focusMonitor', // 列表使用的什么卡片
    }, // 告警卡片的相关配置
  },
  outsiderMonitor: {
    alarmType: 'outsiderMonitor', // 外来人员
    taskTypeCode: '101502',
    detailModuleName: 'outsiderDetail',
    privName: 'outsiderHandle',
    libType: 2, // 用在卡片，日志，详情
    factory: factoryConfig['monitorAlarm'],
    searchData: {
      taskTypes: ['101502'],
    },
    alarmSearchData: {
      sort: ["captureTime|desc"], // 默认按时间排序
      alarmOperationType: -1, // 默认为全部
      alarmTypes: ['2'], 
    },
    alarmComponents: ['PortalTotal', 'VehicleFilter', 'BaseCardList'],
    cardListParams: {
      itemHeight: 300, // 卡片的高度
      offsetOptions: {
        xxl: 0, // ≥1600px
        xl: 2, // ≥1200px
        lg: 0, // ≥992px
        md: 1, // ≥768px
        sm: 0, // ≥576px
        xs: 2, // <576px 
      }, //ListBox组件的配置
      gutter: 10, // 卡片的间距
      itemGrid: {
        xxl: 3, // ≥1600px
        xl: 4, // ≥1200px
        lg: 6, // ≥992px
        md: 8, // ≥768px
        sm: 8, // ≥576px 
        xs: 12, // <576px 
      }, // InfiniteScrollLayout的配置
      cardType: 'outsiderMonitor', // 列表使用的什么卡片
    }, // 告警卡片的相关配置
  },
  // 人员入侵(卡片盒子自定义，没有使用BaseCardList,卡片相关配置可以直接在组件内实现)
  eventMonitor: {
    alarmType: 'eventMonitor',
    taskTypeCode: '101503',
    detailModuleName: 'eventDetail',
    privName: 'eventHandle',
    libType: 3, // 用在卡片，日志，详情
    factory: factoryConfig['monitorAlarm'],
    searchData: {
      taskTypes: ['101503'],
    },
    alarmComponents: ['PortalTotal', 'AlarmFilter', 'MonitorCardList'],
    alarmOperationType: {
      sort: ["captureTime|desc"],
      alarmTypes: ["3"]
    }
  },
  // 重点车辆
  vehicleMonitor: {
    alarmType: 'vehicleMonitor',
    taskTypeCode: '101520',
    detailModuleName: 'vehicleDetail',
    libType: 5, // 当前代码用不到，兼容跳转详情的代码，以及卡片层面的相关判断
    factory: factoryConfig['vehicleAlarm'],
    searchData: {
      taskTypes: ['101520'],
      type: 1, // 车辆相关
    },
    privName: 'vehicleHandle',
    alarmComponents: ['PortalTotal', 'VehicleFilter', 'BaseCardList'],
    alarmSearchData: {
      alarmOperationType: -1, // 状态为全部
    }, // 告警搜索相关参数
  },
  // 外来车辆告警
  vehicleTempMonitor: {
    alarmType: 'vehicleTempMonitor',
    taskTypeCode: '101521',
    detailModuleName: 'vehicleTempDetail',
    libType: 6, // 当前代码用不到，兼容跳转详情的代码，以及卡片层面的相关判断
    factory: factoryConfig['vehicleAlarm'],
    searchData: {
      taskTypes: ['101521'],
      type: 1, // 车辆相关参数
    },
    privName: 'vehicleTempHandle',
    alarmComponents: ['PortalTotal', 'VehicleFilter', 'BaseCardList'],
    alarmSearchData: {
      alarmOperationType: -1, // 状态为全部
    }, // 告警搜索相关参数
  }
};
