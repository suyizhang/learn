import React, { useEffect, useState, useRef, useCallback } from 'react';
import { message } from 'antd';
import './index.less';
import { componentModule, defaultComponents } from './alarmComponents';
const { Loader, SocketEmitter } = window;
const Progress = Loader.loadBaseComponent('Progress');
const Notice = Loader.loadBusinessComponent('Modal', 'Notice');
const initSearchData = {
  isLoadMore: false, // 是否加载更多
  limit: 60,
  offset: 0,
}

const AlarmList = (props) => {
  const { alarmProps={}, taskIds=[] } = props;
  const { alarmComponents = defaultComponents, taskTypeCode, alarmSearchData={} } = alarmProps;
  const [loadingType, setLoadingType] = useState('over')
  // 查询条件
  const [searchData, setSearchData] = useState(() => ({
    ...initSearchData, // 默认的搜索条件
    taskTypeCode, // 类型
    taskIds,
    ...alarmSearchData, // 配置项里的搜索条件
  }));
  // 列表数据
  const [data, setData] = useState({ list: [], total: 0 });
  // 是否继续加载更多
  const hasLoadMore = useRef(true);
  // 弹框操作
  const [modalData, setModalData] = useState({
    visible: false
  });
  // taskIds单独处理，改变时需要重置offset
  useEffect(() => {
    changeSearchData({ taskIds });
  }, [taskIds]);

  useEffect(() => {
    async function getList() {
      const { isLoadMore, limit, offset, taskIds, ...rest } = searchData;
      if(taskIds.length === 0) {
        setData({ total: 0, list: [] });
        return;
      }
      try {
        setLoadingType('loading');
        const { queryAlarmListAction } = alarmProps.factory;
        let listRes = await queryAlarmListAction({ limit, offset, taskIds, ...rest }, alarmProps);
        const { total = 0, list = [] } = listRes.data;
        if (offset + limit >= +total) {
          hasLoadMore.current = false; // 已经拿到所有数据
        }
        // isLoadeMore的必要性？可以通过offset是否为0判断当前是否在新增！
        setData(oldData => isLoadMore ? { total, list: oldData.list.concat(list) } : { total, list });
        setLoadingType('over');
      } catch(err){
        setLoadingType('error');
        console.log('错误信息: ', err);
      }
    }
    getList();
  }, [searchData, alarmProps])

  const changeSearchData = useCallback((options) => {
    // 默认要重置isLoadMore为false offset: 0
    let searchDataNew = { ...searchData, offset: 0, isLoadMore: false, ...options };
    if(searchDataNew.offset === 0){
      hasLoadMore.current = true; // 重置
    }
    setSearchData(searchDataNew);
  }, [searchData])

  function loadMore(){
    if (!hasLoadMore.current) {
      return;
    }
    const { limit, offset } = searchData;
    changeSearchData({ isLoadMore: true, offset: offset + limit });
  }

  // 告警处理相关操作
  function handleCancel() {
    setModalData({ ...modalData, visible: false });
  }

  // 处理确认
  function handleEffective() {
    const { handleAlarmAction } = alarmProps.factory;
    handleAlarmAction(modalData, alarmProps).then(res => {
      message.success('操作成功');
      handleCancel(); // 关闭弹框
      changeSearchData({}); // 刷新列表
      SocketEmitter.emit(SocketEmitter.eventName.handleAlarmSuccess, modalData.item); // 左侧任务告警数刷新
      // 刷新列表
    }).catch(err => {
      console.log('错误信息: ', err);
      message.error('操作失败');
    })
  }
  
  return (
    <div className="lm-tl-alarm-list-container">
      <Progress status={loadingType} />
      {alarmComponents.map(v => {
        let Module = componentModule[v] ? componentModule[v] : null;
        return (
          <Module 
            key={v} 
            {...props} // 用在protal组件
            data={data} 
            loading={loadingType} 
            loadMore={loadMore}
            searchData={searchData}
            changeSearchData={changeSearchData}
            setModalData={setModalData} // 入口提供的基础弹框数据
          />
        );
      })}
      <Notice 
        confirmText={''}
        endMark={''}
        onCancel={handleCancel}
        onOk={handleEffective}
        {...modalData} 
      />
    </div>
  );
};
export default AlarmList;
