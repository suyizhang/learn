import React from 'react';
import { message } from 'antd';
const { Loader, Utils, BaseStore, LM_DB } = window;
const InfiniteScrollLayout = Loader.loadBaseComponent('List', 'InfiniteScrollLayout');
const ListBox = Loader.loadBaseComponent('Box', 'ListBox');
const AlarmOneImgCard = Loader.loadBaseComponent('Card', 'AlarmOneImgCard');

const MonitorCardList = (props) => {
  const { data, loading, loadMore, setModalData, base, history } = props;
  const { list = [] } = data;
  // 跳转详情
  async function handlePageJump(item) {
    let searchData = {
      offset: 0,
      limit: 80,
      alarmOperationType: 2,
      sortType: 1,
      logTypes: '3'
    };
    let detailModuleName = 'eventDetail'
    let libType=3
    if(BaseStore.menu.getInfoByName(detailModuleName)){
      await LM_DB.put({
        id: item.id.toString(),
        libType,
        list,
        type:detailModuleName,
        isHistoryAlarm:false,
        isRealAlarm:false,
        searchData,
        handelAuthName: 'eventHandle',
        detailModuleName,
        alarmData:item
    })
    const pathname = `${base}/${detailModuleName}/${BaseStore.tab.createTabKey()}/${item.id}`
    history.push(pathname)
    }else{
      message.warn("暂无告警详情查看权限")
    }
  }
  // 弹框
  function handleChangeYN(item, isEffective, e) {
    e && e.stopPropagation(e);
    setModalData({
      visible: true,
      item,
      isEffective,
      confirmTitle: isEffective === 1 ? `有效提醒确认` : `无效提醒确认`,
      desc: `点击“确定”将其标注为${+isEffective === 1 ? '有' : '无'}效提醒？`,
      iconType: +isEffective === 1 ? 'icon-S_Photo_ThumbEffective' : 'icon-S_Photo_ThumbInvalid',
    });
  }

  return (
    <ListBox
      className="lm-tl-alarm-card-list-container"
      offsetOptions={{
        xxl: 1, // ≥1600px
        xl: 1, // ≥1200px
        lg: 0, // ≥992px
        md: 1, // ≥768px
        sm: 0, // ≥576px
        xs: 2, // <576px
      }}
    >
      <InfiniteScrollLayout
        gutter={15}
        isNoData={(loading === 'over' || loading === 'error') && list.length === 0}
        itemGrid={{
          xxl: 3, // ≥1600px
          xl: 5, // ≥1200px
          lg: 6, // ≥992px
          md: 8, // ≥768px
          sm: 8, // ≥576px
          xs: 12, // <576px
        }}
        loadMore={loadMore}
        itemHeight={300}
        // hasLoadMore={hasLoadMore}
        hasBackTop={true}
        data={list}
        renderItem={(item) => (
          <AlarmOneImgCard
            sourceData={item}
            alarmType={'event'}
            isActual={true}
            click={handlePageJump}
            imgUrl={item.faceUrl}
            actionName="eventHandle"
            handleChangeYN={handleChangeYN}
            data={[
              { info: item.deviceName || '暂无', icon: 'icon-S_Bar_Add' },
              { info: Utils.formatTimeStamp(item.captureTime) || '暂无', icon: 'icon-S_Edit_ClockEnd' },
              { info: item.taskName || '暂无', icon: 'icon-S_Bar_Layer' },
            ]}
          />
        )}
      />
    </ListBox>
  );
};
export default MonitorCardList;
