import React from 'react';
const { Loader, Utils } = window;
const InfiniteScrollLayout = Loader.loadBaseComponent('List', 'InfiniteScrollLayout');
// const OwnerCard = Loader.loadBaseComponent('Card', 'OwnerCard');
const ListBox = Loader.loadBaseComponent('Box', 'ListBox');
// const SubscriptionCard = Loader.loadBaseComponent('Card', 'SubscriptionCard');
const AlarmOneImgCard = Loader.loadBaseComponent('Card', 'AlarmOneImgCard')

const AlarmCardList = props => {
  const { data, loading, loadMore } = props;
  const { list = [] } = data;
  console.log(data.list, '====列表');
  return (
    <ListBox 
      className='lm-tl-alarm-card-list-container'
      offsetOptions={
        {
          xxl: 1, // ≥1600px
          xl: 1, // ≥1200px
          lg: 2, // ≥992px
          md: 1, // ≥768px
          sm: 0, // ≥576px
          xs: 4, // <576px 
        }
      }
      >
      <InfiniteScrollLayout
        gutter={20}
        isNoData={(loading === 'over' || loading === 'error') && list.length === 0}
        itemGrid={{ xxl: 6, xl: 8, lg: 12, md: 12, sm: 24, xs: 24 }}
        loadMore={loadMore}
        // hasLoadMore={hasLoadMore}
        hasBackTop={true}
        data={list}
        renderItem={item =>(
        //   props.alarmProps.taskTypeCode !== '101558' ?
        //   <OwnerCard
        //   data={item}
        //   // click={() => that.handlePageJump(item)}
        //   footerContent={`闲置房业主${item.taskRule.days || 0}天内,抓拍记录超过${item.taskRule.captureCount || 0}次`}
        // /> :
        // <SubscriptionCard
        //   data={item}
        //   moduleName={'abnormalGroupsList'}
        //   height={300}
        //   // handlePageJump={that.handlePageJump}
        //   relativeIcon={false}
        // />
          <AlarmOneImgCard 
          sourceData={item}
          alarmType={'event'}
          isActual={true}
          // click={this.handlePageJump.bind(this)}
          imgUrl={item.faceUrl}
          actionName='eventHandle'
          // handleJumPage={this.handlePageJump} 
          // handleChangeYN={this.handleChangeYN.bind(this)}
          data={[
            { info: item.deviceName || '暂无', icon: 'icon-S_Bar_Add' },
            { info: Utils.formatTimeStamp(item.captureTime) || '暂无', icon: 'icon-S_Edit_ClockEnd' },
            { info: item.taskName || '暂无', icon: 'icon-S_Bar_Layer' }
          ]}
          />
        )}
        itemHeight={232}
      />
    </ListBox>
  )
}
export default AlarmCardList;