import React from 'react';
import { StatusFilter, SiteSelect, TimeSelect } from '../filterComponents';
import './index.less';

const VehicleFilter = props => {
  const { searchData, changeSearchData } = props;
  return (
    <div className="lm-tl-vehicle-filter-container">
      <StatusFilter searchData={searchData} onChange={changeSearchData} />
      <SiteSelect searchData={searchData} onChange={changeSearchData} />
      <TimeSelect searchData={searchData} onChange={changeSearchData} />
    </div>
  );
}
export default VehicleFilter;