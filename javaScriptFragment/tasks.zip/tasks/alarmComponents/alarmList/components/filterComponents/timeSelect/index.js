import React from 'react';
import moment from 'moment';
import './index.less';
const { Loader } = window;
const RangePickerFilter = Loader.loadBaseComponent('Filter', 'RangePickerFilter');

const TimeSelect = (props) => {
  const { searchData, onChange } = props;
  const { startTime, endTime } = searchData;
  const timeOnChange = (date) => {
    let [startTime, endTime] = date;
    let param = {};
    if (!startTime || !endTime) {
      param = { startTime: undefined, endTime: undefined };
    } else {
      param = { startTime: moment(startTime).valueOf(), endTime: moment(endTime).valueOf() };
    }
    onChange && onChange(param);
  };
  return (
    <div className="lm-tl-time-select-box">
      <RangePickerFilter value={[startTime && moment(startTime), endTime && moment(endTime)]} onChange={timeOnChange} />
    </div>
  );
};

export default TimeSelect;
