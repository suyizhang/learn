import React from 'react';
import { Select } from 'antd';
const { Loader } = window;
const IconFont = Loader.loadBaseComponent('IconFont');
const Option = Select.Option;

const SortType = props => {
  const { searchData={}, onChange, paramName='sort' } = props;
  return (
    <Select
      style={{ width: 134 }}
      value={searchData[paramName]}
      onChange={value => onChange({ [paramName]: value })}
      defaultValue={'captureTime|desc'}
      suffixIcon={<IconFont type='icon-S_Arrow_BigDown' />}
    >
      <Option value={'captureTime|desc'}>按时间排序</Option>
      <Option value={'score|desc'}>按相似度排序</Option>
    </Select>
  )
}

export default SortType;