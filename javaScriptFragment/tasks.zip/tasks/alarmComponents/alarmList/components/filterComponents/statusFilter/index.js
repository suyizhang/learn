import React from 'react';
import { Select } from 'antd';
const { Loader } = window;
const IconFont = Loader.loadBaseComponent('IconFont');
const Option = Select.Option;

const StatusFilter = (props) => {
  const { searchData = {}, paramName = 'alarmOperationType', onChange } = props;
  return (
    <Select
      style={{ width: 110 }}
      value={searchData[paramName]}
      onChange={value => onChange({ [paramName]: value })}
      defaultValue={-1}
      suffixIcon={<IconFont type="icon-S_Arrow_BigDown" />}
    >
      <Option value={-1}>全部状态</Option>
      <Option value={1}>已处理</Option>
      <Option value={2}>未处理</Option>
      <Option value={3}>有效</Option>
      <Option value={4}>无效</Option>
    </Select>
  );
};

export default StatusFilter;
