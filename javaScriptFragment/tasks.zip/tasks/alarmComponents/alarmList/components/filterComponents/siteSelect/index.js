import React, { useMemo } from 'react';
import { Select } from 'antd';
import './index.less';
const { Dict } = window;
const { placeType } = Dict.map;
const Option = Select.Option;

const SiteSelect = (props) => {
  const { searchData = {}, paramName = 'installationSites', paramName1='noInstallationSites', onChange } = props;
  function handleHomeChange(value){
    // 不知道为啥这样处理，但是老代码，不敢动！！！
    let arr = [
      '119101',
      '119102',
      '119103',
      '119104',
      '119105',
      '119106',
      '119107',
      '119108',
      '119109',
      '119110',
      '119111',
      '119112',
      '119113',
      '119114',
      '119115',
    ];
    if (value.indexOf('119115') > -1) {
      arr = arr.filter(v => value.indexOf(v) === -1);
      onChange({
        [paramName1]: arr,
        [paramName]: undefined
      });
    } else {
      onChange({
        [paramName]: value,
        [paramName1]: undefined
      });
    }
  }
  const dataAll = useMemo(() => placeType.sort((a,b) => a.value - b.value), [placeType]);
  return (
    <Select
      className='lm-tl-alarm-site-select'
      style={{ width: '120px' }}
      onChange={handleHomeChange}
      value={searchData[paramName]}
      placeholder="场所筛选"
      mode="multiple"
    >
      {dataAll.map((item) => {
        return <Option value={item.value}>{item.label}</Option>;
      })}
    </Select>
  );
};

export default SiteSelect;
