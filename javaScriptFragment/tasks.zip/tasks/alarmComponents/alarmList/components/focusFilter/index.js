import React from 'react';
import { SortType, StatusFilter, SiteSelect, TimeSelect } from '../filterComponents';
import './index.less';
const { Loader } = window;
const SearchInput = Loader.loadBaseComponent('Form', 'SearchInput');

const FocusFilter = (props) => {
  const { changeSearchData, searchData } = props;
  return (
    <div className="lm-tl-focus-filter-container">
      <div className="focus-filter-left">
        <SortType searchData={searchData} onChange={changeSearchData} />
        <StatusFilter searchData={searchData} onChange={changeSearchData} />
        <SiteSelect searchData={searchData} onChange={changeSearchData} />
        <TimeSelect searchData={searchData} onChange={changeSearchData} />
      </div>
      <div className="focus-filter-right">
        <SearchInput 
          style={{ width: '230px' }} 
          onChange={value => changeSearchData({ monitorPersonKeywords: value })} 
          placeholder="请输入姓名或身份证号搜索" 
        />
      </div>
    </div>
  );
};

export default FocusFilter;
