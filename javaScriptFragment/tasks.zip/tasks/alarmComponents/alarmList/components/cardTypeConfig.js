import React from 'react';
import moment from 'moment';
const { Loader, BaseStore, Utils } = window;
const VehicleCard = Loader.loadBaseComponent('Card', 'VehicleCard');
const AlarmOneImgCard = Loader.loadBaseComponent('Card', 'AlarmOneImgCard');
const AlarmTwoImgCard = Loader.loadBaseComponent('Card', 'AlarmTwoImgCard');

const vehicleMonitor = (props) => {
  const { item, handlePageJump, setModalData, base, list, alarmProps } = props;
  const { detailModuleName, libType } = alarmProps;
  const goPageDetail = (item) => {
    let searchData = {
      startTime: moment().subtract(1, 'years').valueOf(),
      endTime: moment().valueOf(),
      cids: [],
      taskIds: [],
      offset: 0,
      limit: 40,
      alarmType: 2,
    };
    let alarmType = 2;
    const findIndex = list.findIndex((v) => v.id === item.id);
    if (findIndex > -1) {
      const number = Math.floor(findIndex / searchData.limit);
      searchData.offset = number * searchData.limit;
    }
    let indexedDBData = {
      id: item.id.toString(),
      libType,
      list,
      alarmType,
      isRealAlarm: false,
      alarmData: list[findIndex],
      searchData,
    };
    const pathname = `${base}/${detailModuleName}/${BaseStore.tab.createTabKey()}/${item.id}`;
    handlePageJump(indexedDBData, pathname);
  };

  // 弹框
  function handleChangeYN(item, isEffective, e) {
    e && e.stopPropagation(e);
    setModalData({
      visible: true,
      item,
      isEffective,
      confirmTitle: isEffective === 1 ? `有效告警确认` : `无效告警确认`,
      desc: `点击“确定”将其标注为${+isEffective === 1 ? '有' : '无'}效告警？`,
      iconType: +isEffective === 1 ? 'icon-S_Photo_ThumbEffective' : 'icon-S_Photo_ThumbInvalid',
    });
  }

  return <VehicleCard libType={libType} data={item} height={352} key={item.id} handleChangeYN={handleChangeYN} handlePageJump={goPageDetail} />;
};

const focusMonitor = (props) => {
  const { item, handlePageJump, setModalData, base, list, alarmProps, searchData } = props;
  const { detailModuleName, libType, privName } = alarmProps;
  const goPageDetail = (item) => {
    const findIndex = list.findIndex((v) => v.id === item.id);
    if (findIndex > -1) {
      const number = Math.floor(findIndex / searchData.limit);
      searchData.offset = number * searchData.limit;
    }
    let indexedDBData = {
      id: item.id.toString(),
      libType,
      list,
      isRealAlarm: false,
      alarmData: list[findIndex],
      searchData,
    };
    const pathname = `${base}/${detailModuleName}/${BaseStore.tab.createTabKey()}/${item.id}`;
    handlePageJump(indexedDBData, pathname);
  };

  // 弹框
  function handleChangeYN(item, isEffective, e) {
    e && e.stopPropagation(e);
    setModalData({
      visible: true,
      item,
      isEffective,
      confirmTitle: isEffective === 1 ? `有效告警确认` : `无效告警确认`,
      desc: `点击“确定”将其标注为${+isEffective === 1 ? '有' : '无'}效告警？`,
      iconType: +isEffective === 1 ? 'icon-S_Photo_ThumbEffective' : 'icon-S_Photo_ThumbInvalid',
    });
  }
  return (
    <AlarmTwoImgCard
      sourceData={item}
      alarmType={libType}
      isActual={true}
      actionName={privName}
      click={goPageDetail}
      handleChangeYN={handleChangeYN}
      className="lm-tl-focus-monitor-card-box"
    />
  );
};

const outsiderMonitor = (props) => {
  const { item, handlePageJump, setModalData, base, list, alarmProps, searchData } = props;
  const { detailModuleName, libType, privName } = alarmProps;
  const goPageDetail = (item) => {
    const findIndex = list.findIndex((v) => v.id === item.id);
    if (findIndex > -1) {
      const number = Math.floor(findIndex / searchData.limit);
      searchData.offset = number * searchData.limit;
    }
    let indexedDBData = {
      id: item.id.toString(),
      libType,
      list,
      isRealAlarm: false,
      alarmData: list[findIndex],
      searchData,
    };
    const pathname = `${base}/${detailModuleName}/${BaseStore.tab.createTabKey()}/${item.id}`;
    handlePageJump(indexedDBData, pathname);
  };

  // 弹框
  function handleChangeYN(item, isEffective, e) {
    e && e.stopPropagation(e);
    setModalData({
      visible: true,
      item,
      isEffective,
      confirmTitle: isEffective === 1 ? `有效告警确认` : `无效告警确认`,
      desc: `点击“确定”将其标注为${+isEffective === 1 ? '有' : '无'}效告警？`,
      iconType: +isEffective === 1 ? 'icon-S_Photo_ThumbEffective' : 'icon-S_Photo_ThumbInvalid',
    });
  }
  return (
    <AlarmOneImgCard
      sourceData={item}
      alarmType={libType}
      isActual={true}
      click={goPageDetail}
      imgUrl={item.faceUrl}
      actionName={privName}
      score={item.score}
      handleChangeYN={handleChangeYN}
      data={[
        { info: item.deviceName || '暂无', icon: 'icon-S_Bar_Add' },
        { info: Utils.formatTimeStamp(item.captureTime) || '暂无', icon: 'icon-S_Edit_ClockEnd' },
        { info: item.taskName || '暂无', icon: 'icon-S_Bar_Layer' },
      ]}
    />
  );
};

export default {
  vehicleMonitor,
  focusMonitor,
  outsiderMonitor
};
