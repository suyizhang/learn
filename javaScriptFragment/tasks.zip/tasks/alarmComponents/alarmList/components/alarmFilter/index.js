import React from 'react';
import moment from 'moment';
import './index.less';
const { Loader } = window;
const RangePickerFilter = Loader.loadBaseComponent('Filter', 'RangePickerFilter');

const AlarmFilter = (props) => {
  const { searchData, changeSearchData } = props;
  const { startTime, endTime } = searchData;
  const onChange = (date) => {
    let [startTime, endTime] = date;
    let param = {};
    if (!startTime || !endTime) {
      param = { startTime: undefined, endTime: undefined };
    } else {
      param = { startTime: moment(startTime).valueOf(), endTime: moment(endTime).valueOf() };
    }
    changeSearchData && changeSearchData(param);
  };
  return (
    <div className="lm-tl-alarm-filter-container">
      <RangePickerFilter value={[startTime && moment(startTime), endTime && moment(endTime)]} onChange={onChange} />
    </div>
  );
};

export default AlarmFilter;
