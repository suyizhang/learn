import React from 'react';
import CardConfig from '../cardTypeConfig';
import { message } from 'antd';
const { Loader, BaseStore, LM_DB } = window;
const InfiniteScrollLayout = Loader.loadBaseComponent('List', 'InfiniteScrollLayout');
const ListBox = Loader.loadBaseComponent('Box', 'ListBox');
const offsetOptionsDefault = {
  xxl: 0, // ≥1600px
  xl: 2, // ≥1200px
  lg: 0, // ≥992px
  md: 1, // ≥768px
  sm: 0, // ≥576px
  xs: 2, // <576px
}
const itemGridDefault = {
  xxl: 3, // ≥1600px
  xl: 6, // ≥1200px
  lg: 6, // ≥992px
  md: 8, // ≥768px
  sm: 8, // ≥576px
  xs: 12, // <576px
}

const BaseCardList = (props) => {
  const { data, searchData, loading, changeSearchData, loadMore, setModalData, history, alarmProps, base } = props;
  const { list = [] } = data;
  // 跳转详情
  const { detailModuleName, cardListParams={} } = alarmProps;
  const { 
    offsetOptions = offsetOptionsDefault, gutter=10, itemGrid = itemGridDefault,
    itemHeight = 352 , cardType='vehicleMonitor'
  } = cardListParams;

  async function handlePageJump(indexedDBData, pathname) {
    if (BaseStore.menu.getInfoByName(detailModuleName)) {
      await LM_DB.put(indexedDBData);
      history.push(pathname);
    } else {
      message.warn('暂无告警详情查看权限');
    }
  }
  const CardType = CardConfig[cardType];
  return (
    <ListBox
      className="lm-tl-alarm-card-list-container"
      offsetOptions={offsetOptions}
    >
      <InfiniteScrollLayout
        gutter={gutter}
        isNoData={(loading === 'over' || loading === 'error') && list.length === 0}
        itemGrid={itemGrid}
        loadMore={loadMore}
        itemHeight={itemHeight}
        hasBackTop={true}
        data={list}
        renderItem={(item) => (
          <CardType 
            base={base} 
            list={list} 
            item={item} 
            alarmProps={alarmProps}
            setModalData={setModalData} 
            handlePageJump={handlePageJump} 
            searchData={searchData}
            changeSearchData={changeSearchData} // 用于卡片功能相关扩展，主要用来刷新列表
          />
        )}
      />
    </ListBox>
  );
};
export default BaseCardList;
