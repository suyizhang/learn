import React, { useMemo } from 'react';
import './index.less';
const { Loader, Utils } = window;
const Portal = Loader.loadBaseComponent('Portal');
const Button = Loader.loadBaseComponent('Form', 'Button')
const IconFont = Loader.loadBaseComponent('IconFont');

const PortalTotal = (props) => {
  const { getHeaderRightExtContent, data, changeSearchData, alarmProps } = props;
  const { hasRefresh = true } = alarmProps;
  const getButtonContent = useMemo(
    () => (
      <div className="lm-tl-history-alarm-top-right">
        <span className="header-text">
          共显示
          <b className="text-red"> {data.total && Utils.thousand(+data.total)} </b>
          条资源
        </span>
        { hasRefresh && <Button className="refresh_btn" onClick={() => changeSearchData({})}>
          <IconFont type="icon-S_Edit_Refresh1" /> 刷新
        </Button>}
      </div>
    ),
    [data.total, hasRefresh, changeSearchData]
  );
  return <Portal getContainer={getHeaderRightExtContent} content={getButtonContent} />;
};

export default PortalTotal;