import React from 'react';
import moment from 'moment';
import { message } from 'antd';
const { Loader, BaseStore, LM_DB } = window;
const InfiniteScrollLayout = Loader.loadBaseComponent('List', 'InfiniteScrollLayout');
const ListBox = Loader.loadBaseComponent('Box', 'ListBox');
const VehicleCard = Loader.loadBaseComponent('Card', 'VehicleCard');

const VehicleCardList = (props) => {
  const { data, loading, loadMore, setModalData, base, history, alarmProps } = props;
  const { list = [] } = data;
  // 跳转详情
  const { detailModuleName, libType } = alarmProps;
  async function handlePageJump(item) {
    let searchData = {
      startTime: moment().subtract(1, 'years').valueOf(),
      endTime: moment().valueOf(),
      cids: [],
      taskIds: [],
      offset: 0,
      limit: 40,
      alarmType: 2,
    };
    let alarmType = 2;
    const findIndex = list.findIndex((v) => v.id === item.id);
    if (findIndex > -1) {
      const number = Math.floor(findIndex / searchData.limit);
      searchData.offset = number * searchData.limit;
    }
    if (BaseStore.menu.getInfoByName('vehicleDetail')) {
      await LM_DB.put({
        id: item.id.toString(),
        libType,
        list,
        alarmType,
        isRealAlarm: false,
        alarmData: list[findIndex],
        searchData,
      });
      const pathname = `${base}/${detailModuleName}/${BaseStore.tab.createTabKey()}/${item.id}`;
      history.push(pathname);
    } else {
      message.warn('暂无告警详情查看权限');
    }
  }
  // 弹框
  function handleChangeYN(item, isEffective, e) {
    e && e.stopPropagation(e);
    setModalData({
      visible: true,
      item,
      isEffective,
      confirmTitle: isEffective === 1 ? `有效告警确认` : `无效告警确认`,
      desc: `点击“确定”将其标注为${+isEffective === 1 ? '有' : '无'}效告警？`,
      iconType: +isEffective === 1 ? 'icon-S_Photo_ThumbEffective' : 'icon-S_Photo_ThumbInvalid',
    });
  }

  return (
    <ListBox
      className="lm-tl-alarm-card-list-container"
      offsetOptions={{
        xxl: 0, // ≥1600px
        xl: 2, // ≥1200px
        lg: 0, // ≥992px
        md: 1, // ≥768px
        sm: 0, // ≥576px
        xs: 2, // <576px
      }}
    >
      <InfiniteScrollLayout
        gutter={10}
        isNoData={(loading === 'over' || loading === 'error') && list.length === 0}
        itemGrid={{
          xxl: 3, // ≥1600px
          xl: 6, // ≥1200px
          lg: 6, // ≥992px
          md: 8, // ≥768px
          sm: 8, // ≥576px
          xs: 12, // <576px
        }}
        loadMore={loadMore}
        itemHeight={352}
        hasBackTop={true}
        data={list}
        renderItem={(item) => (
          <VehicleCard 
            libType={libType} 
            data={item} 
            height={352} 
            key={item.id} 
            handleChangeYN={handleChangeYN} 
            handlePageJump={handlePageJump} 
          />
        )}
      />
    </ListBox>
  );
};
export default VehicleCardList;
