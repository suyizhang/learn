import AlarmFilter from './components/alarmFilter';
import AlarmCardList from './components/alarmCardList';
import PortalTotal from './components/portal';
import MonitorCardList from './components/monitorCardList';
import VehicleFilter from './components/vehicleFilter';
import VehicleCardList from './components/vehicleCardList';
import BaseCardList from './components/baseCardList';
import FocusFilter from './components/focusFilter';
// 编辑组件集合
export const componentModule = {
  PortalTotal,
  AlarmFilter,
  AlarmCardList,
  MonitorCardList,
  VehicleFilter,
  VehicleCardList,
  BaseCardList,
  FocusFilter
}

// 默认渲染组件
export const defaultComponents = ['PortalTotal', 'AlarmFilter', 'MonitorCardList'];