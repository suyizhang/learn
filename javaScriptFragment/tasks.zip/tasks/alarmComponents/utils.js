/**
 * @desc 用于研判任务接口数据兼容
 * @param {研判任务状态} status 
 */
export const handleAssessmentTaskStatus = status => {
  const statusObj = {
    paused: 0,
    running: 1,
    notStarted: 2,
    expired: 3,
    deleted: 4,
    0: 'paused',
    1: 'running',
    2: 'notStarted',
    3: 'expired',
    4: 'deleted',
  };
  return statusObj[status];
}

/**
 * @desc 用于研判任务接口数据兼容
 * @param {任务来源} source 
 */
export const handleAssessmentTaskSource = source => {
  const sourceObj = {
    0: 'all',
    1: 'local',
    2: 'assign'
  };
  return sourceObj[source];
}

/**
 * @desc 用于人员入侵数据来源字段兼容
 * @param {任务来源} source 
 */
export const handleMonitorTaskSource = source => {
  const sourceObj = {
    0: 1,
    1: 4,
    2: 3
  };
  return sourceObj[source];
}