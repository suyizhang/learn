import React from 'react';
import { Tag } from 'antd';
import './index.less';
const { Loader } = window;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const noticeTypeDict = [
  { value: '1', label: '声音提示' },
  { value: '2', label: '弹框提醒' },
]
const NoticeType = ({ data = {} }) => {
  const {  noticeType= [] } = data;
  return (
    <BoxDesc title="提醒方式" className="task-detail-target-vehicle-notice-type">
      {
        noticeType.map(v => {
          let item = noticeTypeDict.find(k => k.value === v) || {};
          return (
          <Tag color="var(--primary)" title={item.label} className="type-item" key={item.value}>
            {item.label}
          </Tag>
          )
        })
      }
    </BoxDesc>
  )
}
export default NoticeType;