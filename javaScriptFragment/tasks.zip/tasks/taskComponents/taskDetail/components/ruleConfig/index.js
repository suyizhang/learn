import React from 'react';

const { Loader, Dict } = window;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const LabelValue = Loader.loadBaseComponent('LabelValue');
const SingleTag = Loader.loadBusinessComponent('Tags', 'SingleTag');

const RuleConfig = ({ data }) => {
  const { personCount, triggerDuration, taskType } = data;
  let eventInfo = '';
  if(taskType === 101565){
    eventInfo = <div className="rule-tip">
      近 <span className="highlight">{triggerDuration}</span> 小时内，<span className="highlight">{personCount}</span> 人及以上
    </div>;
  }else {
    eventInfo = <div className="rule-tip">
      近 <span className="highlight">{triggerDuration}</span>天内，出现 <span className="highlight">{personCount}</span> 人及以上的地点
    </div>;
  }
  return (
    <BoxDesc title="任务规则" className="tasks-detail-info">
      <div className="info-item">
        <LabelValue label="人员标签" value={
          <SingleTag
            item={{
              label: '吸毒',
              tagColor: 'var(--danger-dark)',
            }}
            isActive={true}
        />
        } />
      </div>
      {taskType === 101565 && <div className="info-item">
        <LabelValue label="地点范围" value='范围不限' />
      </div>}
      <div className="info-item">
        <LabelValue label="触发事件" value={eventInfo} />
      </div>
    </BoxDesc>
  );
};

export default RuleConfig;
