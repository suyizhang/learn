import React from 'react';
import { Tag } from 'antd';
import './index.less';
const { Loader } = window;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const LabelValue = Loader.loadBaseComponent('LabelValue');
const IconFont = Loader.loadBaseComponent('IconFont');

const TasksReceive = ({ data }) => {
  const { acceptAlarmUserNames = [] } = data;
  return (
    <BoxDesc title="任务接收" className="lm-tl-task-view-receive-box">
      <div className="info-item">
        <LabelValue
          label="告警接收人员"
          value={acceptAlarmUserNames.map((v, k) => (
            <Tag color="var(--primary)" title={v} className="person-tag-item" key={k}>
              <IconFont type="icon-S_Edit_Avatar" style={{ marginRight: '4px' }} />
              {v}
            </Tag>
          ))}
        />
      </div>
    </BoxDesc>
  );
};
export default TasksReceive;
