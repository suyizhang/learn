import React from 'react';
import { useGetVehicleBranch } from '../../../hooks';
import { getVehicleColor, getVehicleClasses, getVehicleBrand } from '../../../utils';
import './index.less';
const { Loader } = window;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');

const TargetVehicle = ({ data = {} }) => {
  const [ vehicleSourceData ] = useGetVehicleBranch();
  const { vehicles = [] } = data;
  return (
    <BoxDesc title="布控车辆" className="task-detail-target-vehicle-box">
      <div className="vehicle-box">
        <div className="vehicle-table-title">
          <div>车牌号码</div>
          <div>车牌颜色</div>
          <div>车辆颜色</div>
          <div>车辆类型</div>
          <div>车辆品牌</div>
        </div>
        <div className="vehicle-table-content">
          {vehicles.map((v) => {
            let plateColorLabel = getVehicleColor(v.plateColors, 'plateColor');
            let vehicleColorLabel = getVehicleColor(v.vehicleColors, 'vehicleColor');
            let vehicleClasses = getVehicleClasses(v.vehicleClasses);
            let vehicleBranch = getVehicleBrand(vehicleSourceData, v.vehicleBrands);
            return (
              <div className="vehicle-item">
                <div title={v.plateNo}>{v.plateNo}</div>
                <div title={plateColorLabel}>{plateColorLabel}</div>
                <div title={vehicleColorLabel}>{vehicleColorLabel}</div>
                <div title={vehicleClasses}>{vehicleClasses}</div>
                <div title={vehicleBranch}>{vehicleBranch}</div>
              </div>
            );
          })}
        </div>
      </div>
    </BoxDesc>
  );
};
export default TargetVehicle;
