import React from 'react';
import './index.less';
const { Loader } = window;
const Button = Loader.loadBaseComponent("Form", "Button");
const AuthComponent = Loader.loadBaseComponent('AuthComponent');
const IconFont = Loader.loadBaseComponent('IconFont');

const TaskEditBtn = ({data, showDrawerChange, taskProps}) => {
  const { privName, taskType } = taskProps;
  // 车辆标签的做一些特殊处理
  let hasEditBtn = true;
  if(taskType === 'vehicelTags' && data.taskStatus === 4){
    hasEditBtn = false; // 已经撤销
  }
  return (
    <div className='lm-tl-task-view-btn-box'>
      <span title={data.name} className="title">{data.name}</span>
      {hasEditBtn && data.canOperate !== 0 && <AuthComponent actionName={privName}>
        <Button onClick={() => showDrawerChange(true, data, false, data.taskType)}><IconFont type="icon-S_Edit_Edit"/>编辑</Button>
      </AuthComponent>}
    </div>
  )
}
export default TaskEditBtn;