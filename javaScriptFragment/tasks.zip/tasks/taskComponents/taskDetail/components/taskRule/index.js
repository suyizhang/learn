import React from 'react';
import { 
  idlehousehasPersonRuleTips, accompanyRuleTips, suspectedRentalHousingRuleTips, 
  abnormalChargeRuleTips, astrayPersonRuleTips, notAppearRuleTips,
  nocturnal, outsidePreConvictionsRuleTips, xjPersonGatheredRuleTips
 } from '../../../taskRuleTips';
import { getTagLabel } from '../../../utils';

const { Loader, Dict } = window;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const LabelValue = Loader.loadBaseComponent('LabelValue');
const { preConvictionsTags, identity } = Dict.map;
const modelArray={
  relationsArray:[
    { value: 0, label: '且' },
    { value: 1, label: '或' },
  ],
  statisticalModeArray:[
    { value: 0, label: '累计' },
    { value: 1, label: '平均' },
  ]
}
const getLabel = (value,type) => {
  let item = modelArray[`${type}Array`].find((v) => v.value === value) || {}
  return item.label
}

const TaskRule = ({ taskProps, data }) => {
  const { taskType } = taskProps;
  const { taskRule={}, context } = data;
  const { 
    hours, appearCount, relations, 
    days, accessCardCount, captureCount, statisticalMode,
    villageName, ageRange, censusRegisterTagInfos=[]
 } = taskRule;
 
  let ruleContent = null;
  switch (taskType) {
    case 'astrayPerson':
      const [ageRangeStrat, ageRangeEnd] = ageRange;
      let censusRegisterLabels = censusRegisterTagInfos.map(v => {
        let str = v.name;
        if(v.parentName){
          str = v.parentName + '/' + str;
        }
        return str;
      })
      censusRegisterLabels = censusRegisterLabels.join('、');
      ruleContent = astrayPersonRuleTips({ villageName, ageRangeStrat, ageRangeEnd, censusRegisterLabels, isEdit: false });
      break;
    case 'outsidePreConvictions' :
      const rules = JSON.parse(context);
      const { foreignPersonActivity={} } = rules;
      const { personTags=[] } = foreignPersonActivity;
      ruleContent = outsidePreConvictionsRuleTips({ villageName: rules.villageName, personTagLabels: getTagLabel(personTags, preConvictionsTags), isEdit: false });
      break;
    case 'speciallyAccompany':
      let specialTags = taskRule.personTags.map(v => v + '');
      ruleContent = accompanyRuleTips({ villageName, hours, appearCount, personTagLabels: getTagLabel(specialTags, [...preConvictionsTags, ...identity]), isEdit: false });
      break;
    case 'psychoticNotAppear' :
      ruleContent = notAppearRuleTips({ days, villageName, tagLabel: '精神病', isEdit: false });
      break;
    case 'xjPersonNotAppear' :
      ruleContent = notAppearRuleTips({ days, villageName, tagLabel: 'XJ人员', isEdit: false });
      break;
    case 'xjPersonGathered' :
      const xjPersonGatheredRules = JSON.parse(context);
      const { abnormalPopulationActivity={} } = xjPersonGatheredRules;
      const { triggerDuration, personCount } = abnormalPopulationActivity;
      ruleContent = xjPersonGatheredRuleTips(
        { triggerDuration: triggerDuration / 3600, 
          personCount, villageName: 
          xjPersonGatheredRules.villageName, 
          isEdit: false 
        });
      break;
    case 'xjPersonContacted' :
      ruleContent = accompanyRuleTips({ hours, personTagLabels: 'XJ人员', appearCount, villageName, isEdit: false });
      break;
    case 'nocturnal' :
      ruleContent = nocturnal({ villageName, isEdit: false });
      break;
    case 'addict' :
      ruleContent = notAppearRuleTips({ days, villageName, tagLabel: '吸毒人员', isEdit: false }); 
      break;
    case 'idlehousehasPerson':
      ruleContent = idlehousehasPersonRuleTips({villageName:villageName, days, captureCount, label:getLabel(relations,'relations'), accessCardCount, isEdit: false});
      break;
    case 'suspectedRentalHousing':
      ruleContent = suspectedRentalHousingRuleTips({villageName:villageName, days, captureCount,label: getLabel(relations,'relations'), accessCardCount, isEdit: false});
      break;
    case 'abnormalCharge':
      ruleContent = abnormalChargeRuleTips({villageName:villageName, days, label:getLabel(statisticalMode,'statisticalMode'), accessCardCount, isEdit: false});
      break;
    case 'youngNotAppear' :
      ruleContent = notAppearRuleTips({ days, villageName, tagLabel: '青年和壮年', isEdit: false }); 
      break;
    default:
      break;
  }

  return (
    <BoxDesc title="任务规则" className="tasks-detail-info">
      <div className="info-item">
        <LabelValue label="规则设置" value={ruleContent} />
      </div>
    </BoxDesc>
  );
};

export default TaskRule;
