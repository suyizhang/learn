import React from 'react';
import _ from 'lodash';
import './index.less';
const { Loader, BaseStore, Dict } = window;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const LabelValue = Loader.loadBaseComponent("LabelValue");
const IconFont = Loader.loadBaseComponent('IconFont');

const LibsList = ({ data, taskProps }) => {
  const { 
    alarmThreshold, libs
  } = data;
  const { libType = 1 } = taskProps;
  // 布控任务关联布控库title
  const sceneCode = BaseStore.user.appInfo.sceneCode;
  const monitorLabel = Dict.map.monitorLabel[sceneCode];
  let titleLibs = [
    monitorLabel.keyPerson.libLabel,
    monitorLabel.outsider.libLabel,
    '',
    '布控库',
    '重点车辆库',
    '合规车辆库'
  ];
  const BoxTitle = [
    monitorLabel.keyPerson.label,
    monitorLabel.outsider.label,
    '布控人员',
    '布控人员',
    '布控车辆',
    '合规车辆'
  ]
  // 布控库列表处理
  let libNameArr=[]
  if(libType !== 4){
    libs && libs.forEach(v => {
      libNameArr.push(v.name)
    })
  }else{
    libNameArr = _.groupBy(libs,'machineName'); // 专网布控任务特殊处理
  }
  function getLibList(){
    return (
      <React.Fragment>
        {libNameArr && (libType !== 4 ? libNameArr.map((v,k) => <span key={k} title={v}><IconFont type='icon-S_Bar_Layer'/>{v}</span>) :
          _.map(libNameArr,(v,k) => <div className="libs-item" key={k}>{v[0].machineName}：<br style={{lineHeight: '21px'}}/>{v.map((x,i) => <span key={i} title={x.name}><IconFont type='icon-S_Bar_Layer'/>{x.name}</span>)}</div>)
        )} 
      </React.Fragment>
    )
  }
  return (
    <BoxDesc title={BoxTitle[libType - 1]} className='lm-tl-task-view-libs-box'>
      {!([5,6].includes(libType)) && <div className='info-item'>
        <LabelValue label='告警阈值' value={`${alarmThreshold}%`} />
      </div>}
      <div className='info-item'>
      <LabelValue className='info-libs' label={titleLibs[libType - 1]} value={getLibList()} />
      </div>
    </BoxDesc>
  )
}

export default LibsList;