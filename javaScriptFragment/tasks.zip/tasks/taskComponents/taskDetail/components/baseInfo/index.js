import React from 'react';
const { Loader, Utils } = window;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const LabelValue = Loader.loadBaseComponent("LabelValue");
const BaseInfo = ({ data={} }) => {
  const { 
    name, creatorName, createTime, startTime, endTime, 
    captureStartTime, captureEndTime, description,
  } = data;
  return (
    <BoxDesc title='基本信息' className='tasks-detail-info'>
      <div className='info-item'>
        <LabelValue label="任务名称" value={name} />
      </div>
      <div className='info-item'>
        <LabelValue label="创建人" value={creatorName} />
      </div>
      <div className='info-item'>
        {createTime && <LabelValue label="创建时间" value={Utils.formatTimeStamp(createTime * 1)} />}
      </div>
      <div className='info-item'>
        <LabelValue label="任务有效期" value={startTime && endTime && `${Utils.formatTimeStamp(startTime * 1)} ~ ${Utils.formatTimeStamp(endTime * 1)}`} />
      </div>
      <div className='info-item'>
        {captureStartTime && captureEndTime && <LabelValue label="任务执行时间" value={captureStartTime && captureEndTime && `${captureStartTime} ~ ${captureEndTime}`} />}
      </div>
      <div className='info-item'>
        <LabelValue label="任务说明" value={description} />
      </div>
    </BoxDesc>
  )
}

export default BaseInfo;