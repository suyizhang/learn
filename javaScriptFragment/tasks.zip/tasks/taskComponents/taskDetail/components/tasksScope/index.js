import React, { Component } from 'react';
import SelectBtn from '../../../selectBtn';
import './index.less';
const { Loader } = window;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const ClusterMap = Loader.loadBusinessComponent("LMap", "ClusterMap");
const DeviceIcon = Loader.loadBaseComponent('DeviceIcon');
const Pagination = Loader.loadBaseComponent('Form', 'Pagination');

class TasksScope extends Component {
  constructor(props){
    super(props);
    this.state = {
      type: 1, // 地图模式：1  列表模式：2
      pageSize: 60,
      current: 1,
    }
  }

  // tab切换
  changeType = type => {
    this.setState({ type });
  }

  // 前端分页处理
  changePage = (current, pageSize) => {
    this.setState({
      current,
      pageSize
    })
  }

  showTotal = total => {
    const { current, pageSize } = this.state;
    const totalPage = Math.ceil(total / pageSize);
    return `第${current}页 | 共${totalPage}页 / 共${total}条记录`;
  }
  
  render(){
    const { type, pageSize, current } = this.state;
    const { deviceArr=[] } = this.props.data
    let devices = [];
    if(type === 2 && deviceArr.length > 0){
      devices = deviceArr.slice((current - 1) * pageSize, current * pageSize);
    }
    return (
      <BoxDesc title='任务范围'>
        <SelectBtn style={{ marginBottom: '16px' }} type={type} changeType={this.changeType} />
        { type === 1 && <div className='lm-tl-tasks-view-scope-map-box' style={{ height: '538px'}}>
          <ClusterMap points={deviceArr} />
        </div>}
        { type === 2 && <div className='lm-tl-tasks-view-scope-list-box'>
          <div className='devices-list'>
            {devices.map(item => (
              <span key={item.id} title={item.deviceName}>
                <DeviceIcon 
                  type={item.deviceType}
                  status={item.deviceStatus}
                /> 
              {item.deviceName}
              </span>
            ))}
          </div>
          {deviceArr.length > 60 && <Pagination 
            style={{ textAlign: 'center', paddingTop: '16px' }}
            total={deviceArr.length}
            pageSize={pageSize}
            current={current}
            onShowSizeChange={this.changePage}
            onChange={this.changePage}
            showSizeChanger
            showQuickJumper
            pageSizeOptions={['60','120','180']}
            size="small"
            showTotal={this.showTotal}
          />}
        </div>}
      </BoxDesc>
    )
  }
}
export default TasksScope;