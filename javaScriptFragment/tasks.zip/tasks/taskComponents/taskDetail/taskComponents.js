import BaseInfo from './components/baseInfo';
import LibList from './components/libsList';
import TasksReceive from './components/tasksReceive';
import TasksScope from './components/tasksScope';
import TaskRule from './components/taskRule';
import NoticeType from './components/noticeType';
import TargetVehicle from './components/targetVehicle';
import VehicleTasksScope from './components/vehicleTasksScope';
import RuleConfig from './components/ruleConfig';

// 查看组件集合
export const componentModule = {
  BaseInfo, // 基本信息
  LibList, // 人员库选择
  TaskRule, // 任务规则
  TasksScope, // 任务范围
  TasksReceive, // 任务接收
  NoticeType, // 提醒方式
  TargetVehicle, // 目标车辆
  VehicleTasksScope, // 布控范围
  RuleConfig, // 研判中心任务规则
}

// 默认渲染组件
export const defaultComponents = ['BaseInfo', 'TaskRule', 'TasksReceive'];
