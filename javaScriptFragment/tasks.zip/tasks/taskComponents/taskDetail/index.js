import React from 'react';
import './index.less';
import TaskEditBtn from './components/taskeditBtn';
import { componentModule, defaultComponents } from './taskComponents';

const { Loader } = window;
const Box = Loader.loadBaseComponent('Box', 'Box');

const TaskDetail = props => {
  const { viewComponents = defaultComponents } = props.taskProps;
  return (
    <Box className='lm-tl-task-detail-view-box'>
      <TaskEditBtn {...props} />
      {
        viewComponents.map(v => {
          let Module = componentModule[v];
          return <Module key={v} {...props} />
        })
      }
    </Box>
  )
}
export default TaskDetail;