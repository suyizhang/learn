import BaseList from './components/base';
import VehicleTags from  './components/vehicleTags';
import AnalysisRules from './components/analysisRules';
// 任务列表组件集合
export default {
  BaseList,
  VehicleTags,
  AnalysisRules
}