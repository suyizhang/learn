import React, { Component } from "react";
import "./index.less";
const { Loader } = window;
const IconFont = Loader.loadBaseComponent("IconFont");
const Button = Loader.loadBaseComponent("Form", "Button");
const SearchInput = Loader.loadBaseComponent("Form", "SearchInput");
const AuthComponent = Loader.loadBusinessComponent("AuthComponent");
const SimpleList = Loader.loadBaseComponent("List", "SimpleList");
const statusMap = {
  0: { clsStr: 'be-paused', statusLabel: '已暂停' },
  1: { clsStr: 'be-running', statusLabel: '运行中' },
  2: { clsStr: 'out-of-date', statusLabel: '未开始' },
  3: { clsStr: 'out-of-date', statusLabel: '已过期' },
  4: { clsStr: 'be-deleted', statusLabel: '已删除' },
}

class TaskList extends Component {
  constructor(props){
    super(props);
    this.listRef = React.createRef();
  }

  UNSAFE_componentWillReceiveProps(nextProps){
    if(nextProps.activeItem.id && this.props.activeItem.id !== nextProps.activeItem.id){
      this.listRef.current && this.listRef.current.forceUpdateGrid();
    }
  }

  /**
   * @desc 布控任务列表
   */
  renderItem = (item, index) => {
    const { activeItem, queryMonitorTaskDetail, privName, delTasksModal, onStartPauseBtnClick } = this.props;
    const cls = index === 0 ? 'task-item-first' : '';
    const statusObj = statusMap[item.taskStatus] || {};
    return (
      <div
        className={`${item.id === activeItem.id ? "active" : ""} task-item ${cls}`}
        onClick={() => queryMonitorTaskDetail(item)}
      >
        <div className="title-name">
          <span className="title-tl" title={item.name}>
            {item.name}
          </span>
        </div>
        <div className="btn-message">
          <span className={`state ${statusObj.clsStr}`}></span>
          <span>{statusObj.statusLabel}</span>
          {+item.taskStatus !== 4 && item.canOperate !== 0 && <AuthComponent actionName={privName}>
            <IconFont
              type="icon-S_Edit_Delete"
              className="del_task"
              title="删除任务"
              onClick={e => delTasksModal(e, item)}
            />
          </AuthComponent>}

          {(item.taskStatus === 0 || item.taskStatus === 1) &&
            item.canOperate !== 0 && (
              <AuthComponent actionName={privName}>
                <IconFont
                  type={
                    (item.taskStatus === 1)
                      ? "icon-S_View_PlayerPause"
                      : "icon-S_View_PlayerPlay"
                  }
                  title={(item.taskStatus === 1) ? "暂停任务" : "开启任务"}
                  onClick={e => onStartPauseBtnClick(e, item)}
                  className="stop_or_play_icon"
                />
              </AuthComponent>
            )}
        </div>
      </div>
    );
  };

  render() {
    const { data, changeSearchData, keywords, showDrawerChange, privName } = this.props;
    return (
      <div className="lm-tl-task-list-container">
        <AuthComponent actionName={privName}>
          <Button
            type="primary"
            onClick={showDrawerChange}
            style={{ width: "50%", margin: "16px auto" }}
          >
            <IconFont type="icon-S_Edit_LinePlus" />
            新建任务
          </Button>
        </AuthComponent>
        <div style={{padding:15}}>
        <SearchInput
          onChange={keywords => changeSearchData({ keywords })}
          isEnterKey={true}
          value={keywords}
          placeholder="请输入任务名称搜索"
        />
        </div>
        <div className="task-list-box">
          <SimpleList renderItem={this.renderItem} data={data} rowHeight={68} ref={this.listRef} />
        </div>
      </div>
    );
  }
}
export default TaskList;
