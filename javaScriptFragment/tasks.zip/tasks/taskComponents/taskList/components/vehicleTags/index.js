import React, { useState, useRef, useEffect } from 'react';
import CancelForm from './cancelForm';
import './index.less';
const { Loader } = window;
const IconFont = Loader.loadBaseComponent('IconFont');
const Button = Loader.loadBaseComponent('Form', 'Button');
const SearchInput = Loader.loadBaseComponent('Form', 'SearchInput');
const SelectOption = Loader.loadBaseComponent('Form', 'SelectOption');
const AuthComponent = Loader.loadBusinessComponent('AuthComponent');
const SimpleList = Loader.loadBaseComponent('List', 'SimpleList');

const statusMap = {
  0: { clsStr: 'be-paused', statusLabel: '已暂停' },
  1: { clsStr: 'be-running', statusLabel: '运行中' },
  2: { clsStr: 'out-of-date', statusLabel: '未开始' },
  3: { clsStr: 'out-of-date', statusLabel: '已过期' },
  4: { clsStr: 'be-deleted', statusLabel: '已撤销' },
};

const statusOptions = [
  {
    value: -1,
    statusLabel: '全部'
  },
  {
    value: 1,
    statusLabel: '运行中',
  },
  {
    value: 2,
    statusLabel: '未开始',
  },
  {
    value: 0,
    statusLabel: '已暂停',
  },
  {
    value: 3,
    statusLabel: '已过期',
  },
  {
    value: 4,
    statusLabel: '已撤销',
  }
]

/**
 * @param {*} changeSearchData 
 * tips: 可以使用这个方法刷新列表
 */

const VehicleTags = (props) => {
  const { data, changeSearchData, keywords, showDrawerChange, 
    privName, activeItem, searchData, taskProps
  } = props;
  const listRef = useRef(null);
  const [visible, setVisible] = useState(false);
  const [cancelItem, setCancelItem] = useState({});
  useEffect(() => {
    // 刷新列表
    listRef.current && listRef.current.forceUpdateGrid();
  }, [activeItem.id]);

  function cancelTasksModal(e, item) {
    e.stopPropagation();
    setVisible(true);
    setCancelItem(item);
  }

  function onCancel(isUpdate=false){
    setVisible(false);
    // 刷新任务列表
    isUpdate && changeSearchData({});
  }
  // 任务列表
  const renderItem = (item, index) => {
    const { queryMonitorTaskDetail, onStartPauseBtnClick } = props;
    const cls = index === 0 ? 'task-item-first' : '';
    const statusObj = statusMap[item.taskStatus] || {};
    return (
      <div className={`${item.id === activeItem.id ? 'active' : ''} task-item ${cls}`} onClick={() => queryMonitorTaskDetail(item)}>
        <div className="title-name">
          <span className="title-tl" title={item.name}>
            {item.name}
          </span>
        </div>
        <div className="btn-message">
          <span className={`state ${statusObj.clsStr}`}></span>
          <span>{statusObj.statusLabel}</span>
          {+item.taskStatus !== 4 && item.canOperate !== 0 && (
            <AuthComponent actionName={privName}>
              <IconFont type="icon-S_Arrow_Back" className="del_task" title="撤销任务" onClick={(e) => cancelTasksModal(e, item)} />
            </AuthComponent>
          )}

          {(item.taskStatus === 0 || item.taskStatus === 1) && item.canOperate !== 0 && (
            <AuthComponent actionName={privName}>
              <IconFont
                type={item.taskStatus === 1 ? 'icon-S_View_PlayerPause' : 'icon-S_View_PlayerPlay'}
                title={item.taskStatus === 1 ? '暂停任务' : '开启任务'}
                onClick={(e) => onStartPauseBtnClick(e, item)}
                className="stop_or_play_icon"
              />
            </AuthComponent>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="lm-tl-vehicle-tags-task-list-container">
      <AuthComponent actionName={privName}>
        <Button type="primary" onClick={showDrawerChange} style={{ width: '50%', margin: '20px auto' }}>
          <IconFont type="icon-S_Edit_LinePlus" />
          新建任务
        </Button>
      </AuthComponent>
      {/* <div className='task-type-change-btn'>
        <Button type={listType === "running" ? "primary" : undefined} onClick={() => setListType('running')} style={{ width: '30%' }}>
          运行状态
        </Button>
        <Button type={listType === "approval" ? "primary" : undefined} onClick={() => setListType('approval')} style={{ width: '30%', marginLeft: '8px' }}>
          审批状态
        </Button>
      </div> */}
      <div style={{ padding: 15 }}>
        <SearchInput onChange={(keywords) => changeSearchData({ keywords })} isEnterKey={true} value={keywords} placeholder="请输入任务名称搜索" />
      </div>
      <div className='task-status-select-box'>
        <div className='title'>状态：</div>
        <div className='select-box'>
          <SelectOption 
            value={searchData.taskStatus}
            onChange={taskStatus => changeSearchData({ taskStatus })}
            options={statusOptions}
            itemKey='value'
            labelKey='statusLabel'
            style={{ width: '100%' }}
          />
        </div>
      </div>
      <div className="task-list-box">
        <SimpleList renderItem={renderItem} data={data} rowHeight={68} ref={listRef} />
      </div>
      <CancelForm visible={visible} onCancel={onCancel} taskProps={taskProps} cancelItem={cancelItem} />
    </div>
  );
};
export default VehicleTags;
