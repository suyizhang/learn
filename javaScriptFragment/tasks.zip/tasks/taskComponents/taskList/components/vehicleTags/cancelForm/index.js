import React from 'react';
import { Form, message } from 'antd';
const { Loader } = window;
const FormItem = Form.Item;
const BaseModal = Loader.loadBaseComponent('Modal', 'Base');

const Input = Loader.loadBaseComponent('Form', 'Input');
const CancelForm = (props) => {
  const { onCancel, visible, form, taskProps, cancelItem } = props;
  const { getFieldDecorator, validateFields } = form;
  function onOk(){
    validateFields((err, values) => {
      if(err){
        message.error('表单校验失败');
        return;
      }
      const { reason } = values;
      const { factory } = taskProps;
      factory.cancelAction({ ...cancelItem, reason }).then(res => {
        message.success('撤销成功');
        onCancel(true);
      }).catch(err => {
        console.log('error: ', err);
        message.error('撤销失败');
      })
    })
  }
  return (
    <BaseModal
      visible={visible}
      title='撤销布控'
      width='600px'
      onCancel={onCancel}
      destroyOnClose={true}
      onOk={onOk}
    >
      <div className="lm-tl-vehicle-tags-cancle-form" style={{ margin: '28px 0' }}>
        <Form labelCol={{ span: 3 }} wrapperCol={{ span: 21 }}>
          <FormItem label="撤控原因">
            {getFieldDecorator('reason', {
              rules: [{ required: true, message: '请填写您的撤控原因' }],
            })(<Input placeholder="请填写您的撤控原因" />)}
          </FormItem>
        </Form>
      </div>
    </BaseModal>
  );
};
export default Form.create()(CancelForm);
