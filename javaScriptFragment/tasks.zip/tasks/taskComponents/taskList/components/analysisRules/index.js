import React, { useRef, useEffect } from 'react';
import BaseListFilter from '../baseListFilter';
import './index.less';
const { Loader } = window;
const IconFont = Loader.loadBaseComponent('IconFont');
const Button = Loader.loadBaseComponent('Form', 'Button');
const SearchInput = Loader.loadBaseComponent('Form', 'SearchInput');
const AuthComponent = Loader.loadBusinessComponent('AuthComponent');
const SimpleList = Loader.loadBaseComponent('List', 'SimpleList');
const statusMap = {
  0: { clsStr: 'be-paused', statusLabel: '已暂停' },
  1: { clsStr: 'be-running', statusLabel: '运行中' },
  2: { clsStr: 'out-of-date', statusLabel: '未开始' },
  3: { clsStr: 'out-of-date', statusLabel: '已过期' },
  4: { clsStr: 'be-deleted', statusLabel: '已删除' },
};

const ruleType = {
  101565: '吸毒人员聚集',
  101564: '销毒地点'
}

const AnalysisRules = (props) => {
  const { data, changeSearchData, keywords, showDrawerChange, privName, activeItem, searchData } = props;
  const listRef = useRef(null);
  useEffect(() => {
    // 刷新列表
    listRef.current && listRef.current.forceUpdateGrid();
  }, [activeItem.id]);
  // 任务列表
  const renderItem = (item, index) => {
    const { queryMonitorTaskDetail, onStartPauseBtnClick, delTasksModal } = props;
    const cls = index === 0 ? 'task-item-first' : '';
    const statusObj = statusMap[item.taskStatus] || {};
    const ruleTypeLabel = ruleType[item.taskType];
    return (
      <div className={`${item.id === activeItem.id ? 'active' : ''} task-item ${cls}`} onClick={() => queryMonitorTaskDetail(item)}>
        <div className="title-name">
          <span className="title-tl" title={item.name}>
            {item.name}
          </span>
        </div>
        <div className='task-mode-type'>
          <span>分析模型：</span>
          <span>{ruleTypeLabel}</span>
        </div>
        <div className="btn-message">
          <span className={`state ${statusObj.clsStr}`}></span>
          <span>{statusObj.statusLabel}</span>
          {+item.taskStatus !== 4 && item.canOperate !== 0 && (
            <AuthComponent actionName={privName}>
              <IconFont type="icon-S_Edit_Delete" className="del_task" title="删除任务" onClick={(e) => delTasksModal(e, item)} />
            </AuthComponent>
          )}
          {(item.taskStatus === 0 || item.taskStatus === 1) && item.canOperate !== 0 && (
            <AuthComponent actionName={privName}>
              <IconFont
                type={item.taskStatus === 1 ? 'icon-S_View_PlayerPause' : 'icon-S_View_PlayerPlay'}
                title={item.taskStatus === 1 ? '暂停任务' : '开启任务'}
                onClick={(e) => onStartPauseBtnClick(e, item)}
                className="stop_or_play_icon"
              />
            </AuthComponent>
          )}
        </div>
      </div>
    );
  };
  return (
    <div className="lm-tl-judgement-center-task-list-container">
      <Button type="primary" onClick={() => showDrawerChange(true, undefined, false, '101565')} style={{ width: '220px', margin: '16px auto 0' }}>
        <IconFont type="icon-S_Edit_LinePlus" />
        新建吸毒人员聚集分析任务
      </Button>
      <Button type="primary" onClick={() => showDrawerChange(true, undefined, false, '101564')} style={{ width: '220px', margin: '16px auto' }}>
        <IconFont type="icon-S_Edit_LinePlus" />
        新建销毒地点分析任务
      </Button>
      <div style={{ padding: 15 }}>
        <SearchInput onChange={(keywords) => changeSearchData({ keywords })} isEnterKey={true} value={keywords} placeholder="请输入任务名称搜索" />
      </div>
      <BaseListFilter searchData={searchData} changeSearchData={changeSearchData} />
      <div className="task-list-box">
        <SimpleList renderItem={renderItem} data={data} rowHeight={88} ref={listRef} />
      </div>
    </div>
  );
};

export default AnalysisRules;
