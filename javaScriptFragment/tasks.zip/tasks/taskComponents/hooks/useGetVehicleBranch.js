import { useState, useEffect } from 'react';
const { Service, Dict, Shared } = window;

function useGetVehicleBranch(){
  const [vehicleBranch, setSourceData] = useState([]);
  useEffect(() => {
    const memoVehicleBrands = Shared.memoryCache.vehicleBrands;
    if (memoVehicleBrands && memoVehicleBrands.length) {
      return setSourceData(memoVehicleBrands)
    }
    // 处理车辆品牌子品牌
    async function fetchVehicleBrand() {
      const code = 117100;
      const result = await Service.dict.findTreeDic({ code });
      const { vehicleBrands } = Dict.map;
      vehicleBrands.forEach(v => {
        let item = result.data.find(x => x.code === v.code) || {};
        v.childDictionary = item.childDictionary;
      })
      const vehicleBrandsData = vehicleBrands.sort((x, y) => x.pinyin.localeCompare(y.pinyin));
      Shared.memoryCache.vehicleBrands = vehicleBrandsData;
      Dict.map.vehicleBrands = vehicleBrandsData;
      setSourceData(vehicleBrandsData)
    }
    fetchVehicleBrand()
  }, []);
  return [ vehicleBranch ];
}
export default useGetVehicleBranch;