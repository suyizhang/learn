import moment from 'moment';
import factoryUtils from './factoryUtils.js';
const { Service } = window;
export default {
  ...factoryUtils.judgementCommon,
  addOrEditAction: (values, taskProps) => {
    let { id, type, name, validTime, village, description, days, acceptAlarmUserIds } = values;
    let personTags = [];
    switch(type){
      case '101556':
        personTags = ['120501']; // 精神病
        break;
      case '101557':
        personTags = ['120505']; // xj人员
        break;
      case '101561' :
        personTags = ['120508']; // 吸毒人员
        break;
      case '101563' :
        personTags = ['100802', '100803']; // 青壮年
        break;
      default :
        break;
    }
    let options = {
      id,
      name,
      description,
      type,
      startTime: validTime[0].valueOf(),
      endTime: validTime[1].valueOf(),
      acceptAlarmUser: acceptAlarmUserIds,
      taskRule: {
        days,
        placeId: village.placeId,
        villageId: village.id,
        personTags
      },
    };
    let serName = id ? 'updateTask' : 'addTask';
    return Service.assessmentTask[serName](options, taskProps);
  },
  prevHandleData: data => {
    const { name, description, startTime, endTime, acceptAlarmUser=[], taskRule={} } = data;
    let { placeId, villageName, days, villageId } = taskRule;
    return {
      name, // 布控任务名称
      description, // 布控任务描述
      validTime:  moment(startTime * 1), // 开始时间
      invalidTime: moment(endTime * 1), // 结束时间
      acceptAlarmUserIds: acceptAlarmUser, // 告警接收人员
      // 以下为任务规则相关参数
      days,
      village: {
        placeId,
        villageName,
        id: villageId
      }
    }
  }
}