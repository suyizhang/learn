import moment from 'moment';
import factoryUtils from './factoryUtils.js';
const { Service } = window;
export default {
  ...factoryUtils.judgementCommon,
  addOrEditAction: (values, taskProps) => {
    let { 
      id, type, name, validTime, description, village,acceptAlarmUserIds,
      days, accessCardCount,statisticalMode
    } = values;
    let options = {
      id,
      type,
      name, description, 
      startTime: validTime[0].valueOf(),
      endTime: validTime[1].valueOf(),
      acceptAlarmUser: acceptAlarmUserIds,
      taskRule: {
        placeId:village.placeId,
        villageId: village.id,
        statisticalMode,
        accessCardCount,
        days
      }
    }
    let serName = id ? 'updateTask' : 'addTask';
    return Service.assessmentTask[serName](options, taskProps);
  },
  prevHandleData: data => {
    const { name, description, startTime, endTime, acceptAlarmUser=[], taskRule={} } = data;
    let { placeId, villageName, accessCardCount,days,statisticalMode, villageId} = taskRule;
    return {
      name, // 布控任务名称
      description, // 布控任务描述
      validTime:  moment(startTime * 1), // 开始时间
      invalidTime: moment(endTime * 1), // 结束时间
      acceptAlarmUserIds: acceptAlarmUser, // 告警接收人员
      // 以下为任务规则相关参数
      accessCardCount,
      statisticalMode,
      days,
      village: {
        placeId,
        villageName,
        id: villageId
      },
    }
  }
}