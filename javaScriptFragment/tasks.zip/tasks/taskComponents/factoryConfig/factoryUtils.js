import { handleAssessmentTaskStatus } from '../utils';
const { Service } = window;
export default {
  // 研判任务公共factory
  judgementCommon: {
    queryListAction: (searchData) => {
      return Service.assessmentTask.queryTasks(searchData).then((res) => {
        let list = res.data.list || [];
        list.map((v) => {
          // 任务详情数据兼容到当前组件需要
          let taskStatus = handleAssessmentTaskStatus(v.status);
          v.taskStatus = taskStatus;
          v.canOperate = v.manage;
          return v;
        });
        return list;
      });
    },
    queryDetailAction: (item) => {
      return Service.assessmentTask.queryTasksDetail({ id: item.id }).then((res) => {
        let taskDetail = res.data || {}; // 布控任务详情
        // 将任务的操作权限传递到详情
        if(item.manage === 0 || item.manage === 1){
          taskDetail.canOperate = item.manage;
        }
        const { acceptAlarmUsers } = taskDetail;
        return {
          acceptAlarmUserNames: acceptAlarmUsers.map((v) => v.name),
          ...taskDetail,
        };
      });
    },
    deleteAction: (item, taskProps) => {
      return Service.assessmentTask.deleteTask(item, taskProps);
    },
    updateStatusAction: (item, taskProps) => {
      return Service.assessmentTask.updateTaskStatus(item, taskProps);
    },
  },
  // 订阅任务公共factory
  subscribeCommon: {
    queryListAction: searchData => {
      return Service.subscription.queryTasks(searchData).then(res => {
        let list = res.data.list || [];
        return list.map(v => {
          const { taskName, ...rest } = v;
          return { ...rest, name: taskName };
        })
      })
    },
    queryDetailAction: item => {
      return Service.subscription.subscribeTaskDetail({ id: item.id }).then(res => {
        let taskDetail = res.data || {}; // 布控任务详情
        const { taskName, createTimeStamp, userName, alarmAcceptUserNames, ...rest } = taskDetail;
        // 将任务的操作权限传递到详情(待处理)
        return {
          name: taskName,
          creatorName: userName,
          createTime: createTimeStamp,
          acceptAlarmUserNames: alarmAcceptUserNames,
          ...rest
        };
      });
    },
    deleteAction: (item, taskProps) => {
      let options = {
        id: item.id
      };
      return Service.subscription.subscribeTaskDel(options, {
        type: taskProps.taskTypeCode,
        name: item.name
      })
    },
    updateStatusAction: (item, taskProps) => {
      let options = {
        id: item.id,
        suspend: item.taskStatus === 1 ? 0 : 1
      };
      return Service.subscription.subscribeTaskStatus(options, {
        // 日志相关，后期添加
        type: `status_${taskProps.taskTypeCode}`,
        name: item.name
      })
    },
  }
};
