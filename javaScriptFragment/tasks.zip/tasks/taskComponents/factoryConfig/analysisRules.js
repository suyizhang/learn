import moment from 'moment';
import _ from 'lodash';

const { Service } = window;
export default {
  queryListAction: (searchData) => {
    const { keywords, taskStatus, ...options } = searchData;
    return Service.poison.queryTasks({
      taskName: keywords,
      taskStatus: taskStatus === -1 ? undefined : taskStatus,
      ...options
    }).then((res) => {
      let list = res.data.list || [];
      list.map((v) => {
        v.name = v.taskName;
        return v;
      });
      return list;
    });
  },
  queryDetailAction: (item) => {
    return Service.poison.getTaskById({id: item.id}).then((res) => {
      let taskDetail = res.data || {}; // 布控任务详情
      const { taskName, createTimeStamp, userName, alarmAcceptUserNames, context, ...rest } = taskDetail;
      const taskOtherData = context ? JSON.parse(context) : {};
      let { personCount, triggerDuration } = taskOtherData.poisons;
      if(taskDetail.taskType === 101565){
        triggerDuration = Math.ceil(triggerDuration / 60 / 60); // 把秒转为毫秒
      }
      return {
        name: taskName,
        creatorName: userName,
        createTime: createTimeStamp,
        acceptAlarmUserNames: alarmAcceptUserNames,
        personCount, 
        triggerDuration,
        canOperate: item.canOperate, // 将任务的操作权限传递到详情
        ...rest
      };
    });
  },
  deleteAction:(item) => {
    return Service.poison.deteleTaskByCondition(item)
  },
  updateStatusAction: (item) => {
    let options = {
      id: item.id,
      isStop: item.taskStatus === 1 ? 1 : 0,
    };
    let logOption = {
      taskType: item.taskType + '',
      taskName: item.taskName,
    }
    return Service.monitorTask.updateTaskStop(options, logOption);
  },
  addOrEditAction: (values, taskProps, taskCode) => {
    let { 
      id, name, validTime, description, acceptAlarmUserIds, 
      triggerDuration, personCount
    } = values;
    let options = {
      id,
      taskName: name,
      description,
      taskType: taskCode,
      startTime: validTime[0].valueOf(),
      endTime: validTime[1].valueOf(),
      alarmAcceptUsers: acceptAlarmUserIds,
      poisons: {
        personTag: '120508',
        triggerDuration: taskCode === '101565' ? triggerDuration * 60 * 60 : triggerDuration,
        personCount
      }
    };

    let serName = id ? 'updateTaskById' : 'createTask';
    return Service.poison[serName](options, taskCode);
  },
  prevHandleData: data => {
    const { name, description, startTime, endTime, alarmAcceptUsers=[], personCount, triggerDuration } = data;
    return {
      name, // 布控任务名称
      description, // 布控任务描述
      validTime:  moment(startTime * 1), // 开始时间
      invalidTime: moment(endTime * 1), // 结束时间
      acceptAlarmUserIds: alarmAcceptUsers, // 告警接收人员
      personCount, 
      triggerDuration,
    }
  }
}