import moment from 'moment';
import factoryUtils from './factoryUtils.js';
const { Service } = window;
export default {
  ...factoryUtils.judgementCommon,
  addOrEditAction: (values, taskProps) => {
    let { id, type, name, validTime, village, description, censusRegisterTags, acceptAlarmUserIds, ageRangeStrat, ageRangeEnd } = values;
    let options = {
      id,
      name,
      description,
      type,
      startTime: validTime[0].valueOf(),
      endTime: validTime[1].valueOf(),
      acceptAlarmUser: acceptAlarmUserIds,
      taskRule: {
        censusRegisterTags: censusRegisterTags.map((v) => v[v.length - 1]),
        placeId: village.placeId,
        villageId: village.id,
        ageRange: [ageRangeStrat, ageRangeEnd].sort((a, b) => a - b),
      },
    };
    let serName = id ? 'updateTask' : 'addTask';
    return Service.assessmentTask[serName](options, taskProps);
  },
  prevHandleData: data => {
    const { name, description, startTime, endTime, acceptAlarmUser=[], taskRule={} } = data;
    let { placeId, villageName, ageRange, censusRegisterTagInfos=[], villageId } = taskRule;
    let censusRegisterTags = censusRegisterTagInfos.map(v => {
      let arr = [v.code];
      if(v.parentCode){
        arr.unshift(v.parentCode);
      }
      return arr;
    })
    return {
      name, // 布控任务名称
      description, // 布控任务描述
      validTime:  moment(startTime * 1), // 开始时间
      invalidTime: moment(endTime * 1), // 结束时间
      acceptAlarmUserIds: acceptAlarmUser, // 告警接收人员
      // 以下为任务规则相关参数
      ageRange,
      village: {
        placeId,
        villageName,
        id: villageId
      },
      censusRegisterTags
    }
  }
}