import moment from 'moment';
import _ from 'lodash';

const { Service } = window;
export default {
  queryListAction: (searchData) => {
    // TODO: 这个true后期想办法把service改掉
    const { keywords, ...options } = searchData;
    return Service.monitorTask
      .getTasks(
        {
          taskName: keywords,
          ...options,
        },
        true
      )
      .then((res) => {
        let list = res.data.list || [];
        list.map((v) => {
          v.name = v.taskName;
          return v;
        });
        return list;
      });
  },
  queryDetailAction: (item) => {
    return Service.monitorTask.getTaskById(item.id).then((res) => {
      let taskDetail = res.data || {}; // 布控任务详情
      const { BaseStore } = window;
      const { taskName, createTimeStamp, userName, cids, alarmAcceptUserNames, context, ...rest } = taskDetail;
      const deviceArr = _.intersectionBy(
        BaseStore.device.cameraList,
        cids.map((v) => ({ cid: v })),
        'cid'
      );
      const taskOtherData = context ? JSON.parse(context) : {};
      const { noticeType, vehicles } = taskOtherData;
      return {
        name: taskName,
        creatorName: userName,
        createTime: createTimeStamp,
        acceptAlarmUserNames: alarmAcceptUserNames,
        deviceArr,
        cids,
        noticeType,
        vehicles,
        canOperate: item.canOperate, // 将任务的操作权限传递到详情
        ...rest,
      };
    });
  },
  cancelAction: (item) => {
    const { context } = item;
    let options = { reason: item.reason };
    if (context) {
      let contextObj = JSON.parse(context);
      options = { ...options, ...contextObj };
    }
    return Service.monitorTask.cancelTask({
      id: item.id,
      context: JSON.stringify(options),
    });
  },
  updateStatusAction: (item) => {
    let options = {
      id: item.id,
      isStop: item.taskStatus === 1 ? 1 : 0,
    };
    return Service.monitorTask.updateTaskStop(options);
  },
  addOrEditAction: (values, taskProps,isApproval=false) => {
    let { id, type, name, validTime, description, acceptAlarmUserIds, tasksScope, noticeType, vehicles } = values;
    const { BaseStore } = window;
    const deviceArr = _.intersectionBy(
      BaseStore.device.cameraList,
      tasksScope.deviceIds.map((v) => ({ id: v })),
      'id'
    );
    let options = {
      id,
      taskName: name,
      description,
      type,
      startTime: validTime[0].valueOf(),
      endTime: validTime[1].valueOf(),
      alarmAcceptUsers: acceptAlarmUserIds,
      vehicles,
      cids: deviceArr.map((v) => v.cid),
      extensionMap: {
        noticeType,
      },
    };
    //判断是否走审批流
    if (isApproval) { 
      //发起审批流
      let senceName = id ? 'updateDeployControl' : 'saveDeployControl';
      return Service.approval.launchProcess({
        applyContent:options.taskName,
        senceName,
        callbackInterface: JSON.stringify(options),
      });
    } else {
      let serName = id ? 'updateVehicleLabelTask' : 'saveVehicleLabelTask';
      return Service.monitorTask[serName](options, taskProps);
    }
  },
  prevHandleData: (data) => {
    const { name, description, startTime, endTime, alarmAcceptUsers = [], deviceArr, noticeType, vehicles } = data;
    return {
      name, // 布控任务名称
      description, // 布控任务描述
      validTime: moment(startTime * 1), // 开始时间
      invalidTime: moment(endTime * 1), // 结束时间
      acceptAlarmUserIds: alarmAcceptUsers, // 告警接收人员
      noticeType,
      deviceIds: deviceArr.map((v) => v.id),
      vehicles,
    };
  },
};
