/**
 * tip: 各个任务相关Service参数处理集合
 */
import astrayPerson from './astrayPerson';
import outsidePreConvictions from './outsidePreConvictions';
import speciallyAccompany from './speciallyAccompany';
import notAppear from './notAppear';
import xjPersonContacted from './xjPersonContacted';
import idlehousehasPerson from './idlehousehasPerson';
import suspectedRentalHousing from './suspectedRentalHousing';
import abnormalCharge from './abnormalCharge';
import nocturnal from './nocturnal';
import xjPersonGathered from './xjPersonGathered';
import vehicelTags from './vehicelTags'; // 车辆标签布控任务
import analysisRules from './analysisRules'; // 研判中心下的任务规则
export default {
  astrayPerson,
  outsidePreConvictions,
  speciallyAccompany,
  notAppear,
  xjPersonContacted,
  idlehousehasPerson,
  suspectedRentalHousing,
  abnormalCharge,
  nocturnal,
  xjPersonGathered,
  vehicelTags,
  analysisRules
}