import moment from 'moment';
import factoryUtils from './factoryUtils.js';
const { Service } = window;
export default {
  ...factoryUtils.subscribeCommon,
  addOrEditAction: (values, taskProps) => {
    let { 
      id, type, name, validTime, description, village, 
      personTags, acceptAlarmUserIds
    } = values;
    let options = {
      id,
      name, description, 
      type,
      startTime: validTime[0].valueOf(),
      endTime: validTime[1].valueOf(),
      acceptAlarmUser: acceptAlarmUserIds,
      foreignPersonActivity: {
        personTags,
        triggerDuration: 3 * 60 * 60,
        pidAppearCount: 8,
        placeIds: [village.placeId],
        villageId: village.id
      },
      extensionMap: {
        // 以下数据只是用于任务回显
        villageName: village.villageName,
      }
    }
    let serName = id ? 'subscribeTaskUpdate' : 'subscribeTaskAdd';
    return Service.subscription[serName](options, taskProps);
  },
  prevHandleData: data => {
    const { name, description, startTime, endTime, alarmAcceptUsers=[], context } = data;
    const taskRule = JSON.parse(context) || {};
    const { foreignPersonActivity={}, villageName } = taskRule;
    const { personTags=[], pidAppearCount, placeIds, villageId } = foreignPersonActivity;
    return {
      name, // 布控任务名称
      description, // 布控任务描述
      validTime:  moment(startTime * 1), // 开始时间
      invalidTime: moment(endTime * 1), // 结束时间
      acceptAlarmUserIds: alarmAcceptUsers, // 告警接收人员
      // 以下为任务规则相关参数
      village: {
        placeId: placeIds[0],
        villageName,
        id: villageId
      },
      pidAppearCount,
      personTags
    }
  }
}