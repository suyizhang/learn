/**
 * @desc 任务配置相关集合
 * @time 2020/4/14 16:47
 * 参数相关
 * @param taskType 任务类型（自定义）
 * @param taskTypeCode 任务类型对应的code
 * @param taskTypeLabel 任务名称(string, object 如果是一个页面建多种任务时用对象形式)
 * @param privName 任务的操作权限
 * @param viewComponents 任务查看的组件集合
 * @param editComponents 任务编辑和新建时的组件集合
 * @param searchData 任务列表查询的相关默认参数
 * @param initTaskParams 任务新增时相关参数的默认值
 * @param factory 接口和参数相关处理(service集合, 和一些方法集合)
 * @param taskListType 任务列表类型(默认为baseList)
 * @param (*) 其他参数可以自定义
 */

import factoryConfig from './factoryConfig'; // 接口参数处理集合
const { BaseStore } = window;

export default {
  idlehousehasPerson: {
    taskType: 'idlehousehasPerson',
    taskTypeCode: '101551',
    taskTypeLabel: '闲置房屋疑似住人研判', // 任务的名称
    privName: 'idlehousehasPersonTaskManage', // 权限
    viewComponents: ['BaseInfo', 'TaskRule', 'TasksReceive'],
    editComponents: ['BaseInfo', 'IdlehousehasPersonRule', 'TasksReceive'],
    searchData: {
      types: ['101551'],
      status: ['paused', 'running', 'notStarted', 'expired'],
    },
    initTaskParams: {
      days: 7,
      captureCount: 14,
      relations: 1,
      accessCardCount: 14,
      acceptAlarmUserIds: [BaseStore.user.userInfo.id],
    },
    factory: factoryConfig['idlehousehasPerson']
  },
  suspectedRentalHousing: {
    taskType: 'suspectedRentalHousing',
    taskTypeCode: '101552',
    taskTypeLabel: '疑似租赁房研判', // 任务的名称
    privName: 'suspectedRentalHousingTaskManage', // 权限
    viewComponents: ['BaseInfo', 'TaskRule', 'TasksReceive'],
    editComponents: ['BaseInfo', 'SuspectedRentalHousingRule', 'TasksReceive'],
    searchData: {
      types: ['101552'],
      status: ['paused', 'running', 'notStarted', 'expired'],
    },
    initTaskParams: {
      days: 7,
      captureCount: 2,
      relations: 0,
      accessCardCount: 14,
      acceptAlarmUserIds: [BaseStore.user.userInfo.id],
    },
    factory: factoryConfig['suspectedRentalHousing']
  },
  astrayPerson: {
    taskType: 'astrayPerson',
    taskTypeCode: '101553',
    taskTypeLabel: '疑似失足人员研判', // 任务的名称
    // libSelectLabel: , // 布控库选择的label名称( 场景自定义使用 )
    privName: 'astrayPersonTaskManage', // 权限
    viewComponents: ['BaseInfo', 'TaskRule', 'TasksReceive'],
    editComponents: ['BaseInfo', 'AstrayPersonTaskRule', 'TasksReceive'],
    searchData: {
      types: ['101553'],
      status: ['paused', 'running', 'notStarted', 'expired'],
    },
    initTaskParams: {
      ageRange: [18, 35],
      acceptAlarmUserIds: [BaseStore.user.userInfo.id],
    },
    factory: factoryConfig['astrayPerson']
  },
  outsidePreConvictions: {
    taskType: 'outsidePreConvictions',
    taskTypeCode: '101554',
    taskTypeLabel: '外来前科人员研判', // 任务的名称
    privName: 'outsidePreConvictionsTaskManage', // 权限
    viewComponents: ['BaseInfo', 'TaskRule', 'TasksReceive'],
    editComponents: ['BaseInfo', 'OutsidePreConvictionsRule', 'TasksReceive'],
    searchData: {
      source: 0, // 外来前科 0：全部 1：本地任务，2：指派任务
      types: ['101554'],
      status: 5,
    },
    initTaskParams: {
      acceptAlarmUserIds: [BaseStore.user.userInfo.id],
    },
    factory: factoryConfig['outsidePreConvictions']
  },
  speciallyAccompany: {
    taskType: 'speciallyAccompany',
    taskTypeCode: '101555',
    taskTypeLabel: '特殊人员同行研判', // 任务的名称
    privName: 'speciallyAccompanyTaskManage', // 权限
    viewComponents: ['BaseInfo', 'TaskRule', 'TasksReceive'],
    editComponents: ['BaseInfo', 'SpeciallyAccompanyRule', 'TasksReceive'],
    searchData: {
      types: ['101555'],
      status: ['paused', 'running', 'notStarted', 'expired'],
    },
    initTaskParams: {
      hours: 8,
      appearCount: 3,
      acceptAlarmUserIds: [BaseStore.user.userInfo.id],
    },
    factory: factoryConfig['speciallyAccompany']
  },
  psychoticNotAppear: {
    taskType: 'psychoticNotAppear',
    taskTypeCode: '101556',
    taskTypeLabel: '精神病长期未出现研判', // 任务的名称
    privName: 'psychoticNotAppearTaskManage', // 权限
    viewComponents: ['BaseInfo', 'TaskRule', 'TasksReceive'],
    editComponents: ['BaseInfo', 'PsychoticNotAppearRule', 'TasksReceive'],
    searchData: {
      types: ['101556'],
      status: ['paused', 'running', 'notStarted', 'expired'],
    },
    initTaskParams: {
      acceptAlarmUserIds: [BaseStore.user.userInfo.id],
      days: 5,
    },
    factory: factoryConfig['notAppear']
  },
  xjPersonNotAppear: {
    taskType: 'xjPersonNotAppear',
    taskTypeCode: '101557',
    taskTypeLabel: 'XJ人员长期未出现研判', // 任务的名称
    privName: 'xjPersonNotAppearTaskManage', // 权限
    viewComponents: ['BaseInfo', 'TaskRule', 'TasksReceive'],
    editComponents: ['BaseInfo', 'XjPersonNotAppearRule', 'TasksReceive'],
    searchData: {
      types: ['101557'],
      status: ['paused', 'running', 'notStarted', 'expired'],
    },
    initTaskParams: {
      acceptAlarmUserIds: [BaseStore.user.userInfo.id],
      days: 5,
    },
    factory: factoryConfig['notAppear']
  },
  xjPersonGathered: {
    taskType: 'xjPersonGathered',
    taskTypeCode: '101558',
    taskTypeLabel: 'XJ人员聚集研判', // 任务的名称
    privName: 'xjPersonGatheredTaskManage', // 权限
    viewComponents: ['BaseInfo', 'TaskRule', 'TasksReceive'],
    editComponents: ['BaseInfo', 'XjPersonGatheredRule', 'TasksReceive'],
    searchData: {
      source: 0, // 外来前科 0：全部 1：本地任务，2：指派任务
      types: ['101558'],
      status: 5,
    },
    initTaskParams: {
      triggerDuration: 1,
      personCount: 5, 
      acceptAlarmUserIds: [BaseStore.user.userInfo.id],
    },
    factory: factoryConfig['xjPersonGathered'],
  },
  xjPersonContacted: {
    taskType: 'xjPersonContacted',
    taskTypeCode: '101559',
    taskTypeLabel: 'XJ人员串联研判', // 任务的名称
    privName: 'xjPersonContactedTaskManage', // 权限
    viewComponents: ['BaseInfo', 'TaskRule', 'TasksReceive'],
    editComponents: ['BaseInfo', 'XjPersonContactedRule', 'TasksReceive'],
    searchData: {
      types: ['101559'],
      status: ['paused', 'running', 'notStarted', 'expired'],
    },
    initTaskParams: {
      hours: 8,
      appearCount: 3,
      acceptAlarmUserIds: [BaseStore.user.userInfo.id],
    },
    factory: factoryConfig['xjPersonContacted']
  },
  nocturnal: {
    taskType: 'nocturnal',
    taskTypeCode: '101560',
    taskTypeLabel: '人员昼伏夜出研判', // 任务的名称
    privName: 'nocturnalTaskManage', // 权限
    viewComponents: ['BaseInfo', 'TaskRule', 'TasksReceive'],
    editComponents: ['BaseInfo', 'NocturnalRule', 'TasksReceive'],
    searchData: {
      types: ['101560'],
      status: ['paused', 'running', 'notStarted', 'expired'],
    },
    initTaskParams: {
      acceptAlarmUserIds: [BaseStore.user.userInfo.id],
    },
    factory: factoryConfig['nocturnal']
  },
  addict: {
    taskType: 'addict',
    taskTypeCode: '101561',
    taskTypeLabel: '吸毒人员长期未出现研判', // 任务的名称
    privName: 'focusTaskManage', // 权限
    viewComponents: ['BaseInfo', 'TaskRule', 'TasksReceive'],
    editComponents: ['BaseInfo', 'AddictRule', 'TasksReceive'],
    searchData: {
      types: ['101561'],
      status: ['paused', 'running', 'notStarted', 'expired'],
    },
    initTaskParams: {
      days: 5,
      acceptAlarmUserIds: [BaseStore.user.userInfo.id],
    },
    factory: factoryConfig['notAppear']
  },
  abnormalCharge: {
    taskType: 'abnormalCharge',
    taskTypeCode: '101562',
    taskTypeLabel: '异常刷卡研判', // 任务的名称
    privName: 'abnormalChargeTaskManage', // 权限
    viewComponents: ['BaseInfo', 'TaskRule', 'TasksReceive'],
    editComponents: ['BaseInfo', 'AbnormalChargeRule', 'TasksReceive'],
    searchData: {
      types: ['101562'],
      status: ['paused', 'running', 'notStarted', 'expired'],
    },
    initTaskParams: {
      days: 7,
      statisticalMode: 0,
      accessCardCount: 28,
      acceptAlarmUserIds: [BaseStore.user.userInfo.id],
    },
    factory: factoryConfig['abnormalCharge']
  },
  youngNotAppear: {
    taskType: 'youngNotAppear',
    taskTypeCode: '101563',
    taskTypeLabel: '青壮年长期未出现研判', // 任务的名称
    privName: 'youngNotAppearTaskManage', // 权限
    viewComponents: ['BaseInfo', 'TaskRule', 'TasksReceive'],
    editComponents: ['BaseInfo', 'YoungNotAppearRule', 'TasksReceive'],
    searchData: {
      types: ['101563'],
      status: ['paused', 'running', 'notStarted', 'expired'],
    },
    initTaskParams: {
      days: 5,
      acceptAlarmUserIds: [BaseStore.user.userInfo.id],
    },
    factory: factoryConfig['notAppear']
  },
  // ---------- 以下为布控相关任务 -----------------------
  vehicelTags: {
    taskType: 'vehicelTags',
    taskTypeCode: '101526',
    taskTypeLabel: '车辆标签布控', // 任务的名称
    privName: 'vehicleTagsTaskManage', // 权限(后期对应)
    taskListType: 'VehicleTags', // 任务列表
    viewComponents: ['BaseInfo', 'NoticeType', 'TargetVehicle', 'VehicleTasksScope', 'TasksReceive'],
    editComponents: ['BaseInfo', 'NoticeSet', 'TargetVehicle', 'VehicleTasksScope', 'TasksReceive'],
    searchData: {
      taskTypes: ["101526"],
      source: 0,
      taskStatus: -1,
      type: 1, // 车相关任务
    },
    initTaskParams: {
      acceptAlarmUserIds: [BaseStore.user.userInfo.id],
      noticeType: ['2'], // 这个字段自己玩
    }, 
    factory: factoryConfig['vehicelTags']
  },
  // ---------------- 扩展之后的研判规则（一个界面新建两种任务） -------------------
  analysisRules: {
    taskType: 'analysisRules',
    taskTypeCode: 'all',
    taskTypeLabel: {
      '101565': '吸毒人员聚集分析',
      '101564': '销毒地点分析'
    }, // 任务的名称
    privName: 'addictThemeApplication', // 权限(后期对应)
    taskListType: 'AnalysisRules', // 任务列表
    viewComponents: ['BaseInfo', 'RuleConfig', 'TasksReceive'],
    editComponents: ['BaseInfo', 'RuleConfig', 'TasksReceive'],
    searchData: {
      taskTypes: ["101564", "101565"], // 列表上有两种数据
      source: 0,
      taskStatus: -1,
    },
    initTaskParams: {
      acceptAlarmUserIds: [BaseStore.user.userInfo.id],
      triggerDuration: 5,
      personCount: 3,
      description: '多个涉毒人员近一段时间内进入同一个场所'
    }, 
    factory: factoryConfig['analysisRules']
  }
};
