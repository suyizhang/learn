import React from 'react';
import './index.less';
const { Loader } = window;
const IconFont = Loader.loadBaseComponent('IconFont');

export const AgeLabel = ({ label, iconType='icon-S_Photo_Subscription', ...rest }) => (
  <div {...rest} className='lm-tl-type-label'>
    {label}
    <IconFont type={iconType} />
  </div>
)
