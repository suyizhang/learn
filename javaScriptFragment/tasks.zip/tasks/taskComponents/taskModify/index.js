import React, { Component } from 'react';
import moment from 'moment';
import { Form, message } from 'antd';
import { inject } from 'mobx-react';
import './index.less';
import { componentModule, defaultComponents } from './taskComponents';

const { Loader } = window;
const FormContent = Loader.loadBaseComponent('Drawer', 'FormContent');
const Progress = Loader.loadBaseComponent('Progress');

// tips:
// 布控任务相关form字段应该以当前组件的字段为主，
// 使用该布控组件的布控任务字段要转换为当前组件需要的字段
// 否则copy一份代码自己实现

@inject('device')
class TaskModify extends Component {
  constructor(props) {
    super(props);
    let itemData = this.handleData(props.data); // 数据统一处理
    this.state = {
      httpStatus: 'over', // 模拟数据请求
      itemData, // 当前编辑的布控任务
      taskCode: (props.data.taskType || props.taskCode) + '', // 默认取编辑的数据.同时转为字符串
    };
    this.isSubmiting = false;
  }

  // 数据进入编辑添加组件时的差异化处理
  handleData = data => {
    const { initTaskParams = {}, factory } = this.props.taskProps;
    // 数据处理
    let options = {
      validTime: moment(), // 开始时间
      invalidTime: moment().add('days', 3), // 结束时间
    };
    if(!data.id){
      // 新增任务处理
      return { ...options, ...initTaskParams };
    }
    // 编辑任务抛到相关配置自行处理
    return factory.prevHandleData(data);
  };

  // 添加编辑成功后的处理
  handleSave = () => {
    const { form, data , onClose } = this.props;
    if (this.isSubmiting) {
      return; // 正在提交时不能再次提交
    }
    form.validateFields((err, values) => {
      if (err) {
        console.log(err);
        message.error('表单验证失败');
        return;
      }
      this.setState({ httpStatus: 'loading' }); 
      this.isSubmiting = true; // 开始提交
      this.submitService(values).then(res => {
        message.success(`${data.id ? '编辑' : '新建'}成功`);
        this.isSubmiting = false; // 提交完成
        onClose && onClose(true);
        this.setState({ httpStatus: 'over' });
      }).catch(err => {
        this.setState({ httpStatus: 'error' });
        this.isSubmiting = false; // 提交失败
        message.error(`${data.id ? '编辑' : '新建'}失败`);
      });
    })
  }

  // 提交代码的差异处理
  submitService = values => {
    // taskCode 当前新建或者编辑的布控任务，默认从taskTypeCode中取，
    // 如果出现同一个页面新建不同任务时使用，正常情况下为undefined,不需要使用
    const { taskCode } = this.state;
    const { data, taskProps } = this.props;
    const { taskTypeCode, factory } = taskProps;
    return factory.addOrEditAction({ id: data.id, type: taskTypeCode, ...values}, taskProps, taskCode);
  }

  render() {
    const { httpStatus, itemData, taskCode } = this.state;
    const { form, onClose, taskProps } = this.props;
    const { getFieldDecorator, getFieldsValue } = form;
    const { editComponents = defaultComponents } = taskProps;
    return (
      <FormContent className='lm-tl-task-modify-style' onOk={this.handleSave} onCancel={() => onClose(false)} labelCol={{ span: 3 }} wrapperCol={{ span: 21 }}>
        <Progress status={httpStatus} />
        {
          editComponents.map(v => {
            let Module = componentModule[v] ? componentModule[v] : null;
            return (
              <Module 
                key={v} 
                getFieldDecorator={getFieldDecorator} 
                getFieldsValue={getFieldsValue} 
                itemData={itemData}
                taskProps={taskProps}
                taskCode={taskCode} // 用于一个页面新建多种任务的场景
              />    
            )
          })
        }
      </FormContent>
    );
  }
}
export default Form.create()(TaskModify);
