import React from 'react';
import { Form } from 'antd';
import CommunitySelect from '../../formComponents/communitySelect';
import { nocturnal } from '../../../taskRuleTips';

const { Loader } = window;
const FormItem = Form.Item;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');

class NocturnalRule extends React.Component {
  getTips = () => {
    const { getFieldsValue, itemData } = this.props;
    const tipValue = getFieldsValue() || {};
    const { village=itemData.village ? itemData.village : {} } = tipValue;
    return nocturnal({ villageName: village.villageName });
  };
  render() {
    const { getFieldDecorator, itemData } = this.props;
    const { village } = itemData;
    return (
      <BoxDesc title="任务规则" style={{ paddingBottom: 0 }} className="rule-panel">
        {this.getTips()}
        <FormItem label="居住小区">
          {getFieldDecorator('village', {
            initialValue: village,
            rules: [{ required: true, message: '请选择居住小区' }]
          })(<CommunitySelect />)}
        </FormItem>
        <FormItem label="触发规则">
          <div>人员出现规律符合<span style={{ fontWeight: 600 }}> 昼伏夜出 </span></div>
        </FormItem>
      </BoxDesc>
    );
  }
}

export default NocturnalRule;
