import React from 'react';
import { Form } from 'antd';
import InputNumberRule from '../../formComponents/inputNumber';
import ResidenceSelect from '../../formComponents/residenceSelect';
import CommunitySelect from '../../formComponents/communitySelect';
import { astrayPersonRuleTips } from '../../../taskRuleTips';

const { Loader, Service } = window;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const FormItem = Form.Item;

class AstrayPersonTaskRule extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      locationData: [], // 城市
    }
  }
  componentDidMount(){
    Service.administrativeDivision.queryAdministrativeDivision({ level: 2 })
    .then(res => {
      this.setState({ locationData: res.data });
    })
  }
  getTips = () => {
    const tipValue = this.props.getFieldsValue() || {};
    const { ageRangeStrat, ageRangeEnd, censusRegisterTags, village={} } = tipValue;
    const { locationData } = this.state;
    // 户籍处理
    let censusRegisterLabels = [];
    if(Array.isArray(locationData) && locationData.length > 0){
      censusRegisterLabels = censusRegisterTags.map(v => {
        let label = '';
        v.forEach(k => {
          let item = locationData.find(m => m.code === k) || {};
          label = label + item.name + '/';
        })
        label = label.substr(0, label.length - 1);
        return label;
      })
    }
    return astrayPersonRuleTips({
      censusRegisterLabels: censusRegisterLabels.join('、'),
      ageRangeStrat,
      ageRangeEnd,
      villageName: village.villageName
    });
  };

  render() {
    const { getFieldDecorator, itemData } = this.props;
    const { censusRegisterTags=[], village, ageRange=[], sexTag } = itemData;
    const [ ageRangeStrat, ageRangeEnd ] = ageRange;
    const { locationData } = this.state;
    return (
      <BoxDesc title="任务规则" style={{ paddingBottom: 0 }} className="rule-panel">
        {this.getTips()}
        <FormItem label="户籍">
          {getFieldDecorator('censusRegisterTags', {
            initialValue: censusRegisterTags,
            rules: [{ required: true, message: '请选择户籍' }]
          })(<ResidenceSelect locationData={locationData}/>)}
        </FormItem>
        <FormItem label="居住小区">
          {getFieldDecorator('village', {
            initialValue: village,
            rules: [{ required: true, message: '请选择居住小区' }]
          })(<CommunitySelect />)}
        </FormItem>
        <FormItem label="年龄" required={true}>
          <InputNumberRule
            labelTwo=" 岁 至 "
            labelThree=" 岁"
            getFieldDecorator={getFieldDecorator}
            inputNumberOne={{
              formValue: 'ageRangeStrat',
              formParams: {
                initialValue: ageRangeStrat
              },
              formProps: {
                min: 1
              }
            }}
            inputNumberTwo={{
              formValue: 'ageRangeEnd',
              formParams: {
                initialValue: ageRangeEnd
              },
              formProps: {
                min: 1
              }
            }}
          />
        </FormItem>
        <FormItem label="性别">
          {getFieldDecorator('sexTag', {
            initialValue: sexTag
          })(<div>女</div>)}
        </FormItem>
        <FormItem label="时间" required={true}>
          <div>每天 7:00 至 21:00</div>
        </FormItem>
        <FormItem label="触发规则" required={true}>
          <div>连续7天，抓拍次数每天均小于2次</div>
        </FormItem>
      </BoxDesc>
    );
  }
}

export default AstrayPersonTaskRule;
