import React from 'react';
import { Form, InputNumber, Select } from 'antd';
import CommunitySelect from '../../formComponents/communitySelect';
import { abnormalChargeRuleTips } from '../../../taskRuleTips';

const { Loader } = window;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const FormItem = Form.Item;
const Option = Select.Option;
const statisticalModeArray = [
  { value: 0, label: '累计' },
  { value: 1, label: '平均' },
]

class AbnormalChargeRule extends React.Component {
  getTips = () => {
    const tipValue = this.props.getFieldsValue() || {};
    const itemData = this.props.itemData;
    const { statisticalMode=itemData.statisticalMode, days=itemData.days, accessCardCount=itemData.accessCardCount,village=itemData.village||{} } = tipValue;
    let itemObj = statisticalModeArray.find(v => v.value === statisticalMode) || {};

    return abnormalChargeRuleTips( {villageName:village.villageName, days,label:itemObj.label, accessCardCount });
  };
  render() {
    const { getFieldDecorator, itemData } = this.props;
    const { days, statisticalMode, accessCardCount, village } = itemData;
    return (
      <BoxDesc title="任务规则" style={{ paddingBottom: 0 }} className="rule-panel">
        {this.getTips()}
        <FormItem label="居住小区">
          {getFieldDecorator('village', {
            initialValue: village,
            rules: [{ required: true, message: '请选择居住小区' }]
          })(<CommunitySelect />)}
        </FormItem>
        <FormItem label="触发规则" required={true}>
          <InputNumberRule 
            getFieldDecorator={getFieldDecorator} 
            days={days}
            accessCardCount={accessCardCount}
            statisticalMode={statisticalMode}
          />
        </FormItem>
      </BoxDesc>
    );
  }
}

const InputNumberRule = ({ getFieldDecorator, days, statisticalMode, accessCardCount }) => (
  <div>
    <span>单张门禁卡 </span>
    {getFieldDecorator('days', {
      initialValue: days 
    })(<InputNumber min={1} max={30} />)}
    <span> 天内，刷卡次数 </span>
    {
      getFieldDecorator('statisticalMode', {
        initialValue: statisticalMode 
      })(
        <Select style={{ width: '100px' }}>
          {
            statisticalModeArray.map(v => (
              <Option value={v.value} key={v.value}>{v.label}</Option>
            ))
          }
        </Select>
      )
    }
    <span> 大于 </span>
    {getFieldDecorator('accessCardCount', {
      initialValue: accessCardCount 
    })(<InputNumber min={1}/>)}
    <span> 次</span>
  </div>
);

export default AbnormalChargeRule;
