import React from 'react';
import { Form } from 'antd';
import InputNumberRule from '../../formComponents/inputNumber';
import CommunitySelect from '../../formComponents/communitySelect';
import { notAppearRuleTips } from '../../../taskRuleTips';
import { getVillageName } from '../../../utils';

const { Loader } = window;
const FormItem = Form.Item;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const SingleTag = Loader.loadBusinessComponent("Tags", "SingleTag");

class XjPersonNotAppearRule extends React.Component {
  getTips = () => {
    const { itemData, getFieldsValue } = this.props;
    const tipValue = getFieldsValue() || {};
    // 设置默认值的原因是antd的form第一次捕获的值存在问题，后续捕获正常
    const { days=itemData.days, village=itemData.village ? itemData.village : {} } = tipValue;
    return notAppearRuleTips({ days, villageName: village.villageName, tagLabel: 'XJ人员' }); 
  };
  render() {
    const { getFieldDecorator, itemData, getFieldsValue } = this.props;
    const { village, days } = itemData;
    const villageName = getVillageName(village, getFieldsValue);
    return (
      <BoxDesc title="任务规则" style={{ paddingBottom: 0 }} className="rule-panel">
        {this.getTips()}
        <FormItem label="居住小区">
          {getFieldDecorator('village', {
            initialValue: village,
            rules: [{ required: true, message: '请选择居住小区' }]
          })(<CommunitySelect />)}
        </FormItem>
        <FormItem label="人员标签">
          <SingleTag item={{
            label: 'XJ',
            tagColor: 'var(--danger-dark)'
          }} isActive={true} />
        </FormItem>
        <FormItem label="触发规则" required={true}>
        <InputNumberRule
            labelTwo={<span> 天内，在 <span style={{ fontWeight: 600 }}>{villageName}</span> 抓拍为 0</span>}
            getFieldDecorator={getFieldDecorator}
            inputNumberOne={{
              formValue: 'days',
              formParams: {
                initialValue: days
              },
              formProps: {
                min: 1,
                max: 30
              }
            }}
          />
        </FormItem>
      </BoxDesc>
    );
  }
}

export default XjPersonNotAppearRule;
