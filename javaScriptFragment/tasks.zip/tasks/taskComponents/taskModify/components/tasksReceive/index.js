import React from 'react';
import { Form } from 'antd';

const { Loader } = window;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const SelctUser = Loader.loadBaseComponent('List', 'SelectUser');
const FormItem = Form.Item;

const TasksReceive = props => {
  const { getFieldDecorator, taskProps, itemData } = props;
  const { privilegeName=[] } = taskProps;
  const { acceptAlarmUserIds } = itemData;
  return (
    <BoxDesc title="任务接收" style={{ paddingBottom: 0 }}>
      <FormItem label="接收报警人员">
        {getFieldDecorator('acceptAlarmUserIds', {
          initialValue: acceptAlarmUserIds,
          rules: [{ required: true, message: '请选择接收人员' }]
        })(<SelctUser privilegeName={privilegeName} />)}
      </FormItem>
    </BoxDesc>
  );
};
export default TasksReceive;
