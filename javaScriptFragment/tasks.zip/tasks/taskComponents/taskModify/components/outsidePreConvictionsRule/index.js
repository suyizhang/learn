import React from 'react';
import { Form } from 'antd';
import PersonTags from '../../formComponents/personTags';
import CommunitySelect from '../../formComponents/communitySelect';
import { outsidePreConvictionsRuleTips } from '../../../taskRuleTips';
import { getVillageName, getTagLabel } from '../../../utils';

const { Loader, Dict } = window;
const { preConvictionsTags } = Dict.map;
preConvictionsTags.map(v => {
  v.tagColor = 'var(--danger-dark)';
  return v;
})
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const FormItem = Form.Item;

class OutsidePreConvictionsRule extends React.Component {
  getTips = () => {
    const { getFieldsValue, itemData } = this.props;
    const tipValue = getFieldsValue() || {};
    const { 
      village=itemData.village || {}, 
      personTags=itemData.personTags || [] 
    } = tipValue;
    return outsidePreConvictionsRuleTips({ villageName: village.villageName, personTagLabels: getTagLabel(personTags, preConvictionsTags) });
  }; 
  render() {
    const { getFieldDecorator, itemData, getFieldsValue } = this.props;
    const { personTags=[], village } = itemData;
    const villageName = getVillageName(village, getFieldsValue);
    return (
      <BoxDesc title="任务规则" style={{ paddingBottom: 0 }} className="rule-panel">
        {this.getTips()}
        <FormItem label="所属小区">
          {getFieldDecorator('village', {
            initialValue: village,
            rules: [{ required: true, message: '请选择所属小区' }]
          })(<CommunitySelect label='排除' />)}
        </FormItem>
        <FormItem label="人员标签">
          {getFieldDecorator('personTags', {
            initialValue: personTags,
            rules: [{ required: true, message: '请选择人员标签' }]
          })(<PersonTags tagList={preConvictionsTags}/>)}
        </FormItem>
        <FormItem label="触发规则" >
          <div>在 <span style={{ fontWeight: 600 }}>{villageName}</span> 出现</div>
        </FormItem>
      </BoxDesc>
    );
  }
}

export default OutsidePreConvictionsRule;
