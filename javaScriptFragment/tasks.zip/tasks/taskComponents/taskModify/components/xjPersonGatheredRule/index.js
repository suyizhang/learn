import React from 'react';
import { Form } from 'antd';
import InputNumberRule from '../../formComponents/inputNumber';
import CommunitySelect from '../../formComponents/communitySelect';
import { xjPersonGatheredRuleTips } from '../../../taskRuleTips';

const { Loader } = window;
const FormItem = Form.Item;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const SingleTag = Loader.loadBusinessComponent('Tags', 'SingleTag');

class XjPersonGatheredRule extends React.Component {
  getTips = () => {
    const { itemData, getFieldsValue } = this.props;
    const tipValue = getFieldsValue() || {};
    // 设置默认值的原因是antd的form第一次捕获的值存在问题，后续捕获正常
    const { triggerDuration=itemData.triggerDuration, personCount=itemData.personCount, village=itemData.village || {} } = tipValue;
    return xjPersonGatheredRuleTips({ triggerDuration, personCount, villageName: village.villageName }); 
  };
  render() {
    const { getFieldDecorator, itemData } = this.props;
    const { village, triggerDuration, personCount } = itemData;
    return (
      <BoxDesc title="任务规则" style={{ paddingBottom: 0 }} className="rule-panel">
        {this.getTips()}
        <FormItem label="居住小区">
          {getFieldDecorator('village', {
            initialValue: village,
            rules: [{ required: true, message: '请选择居住小区' }],
          })(<CommunitySelect />)}
        </FormItem>
        <FormItem label="人员标签">
          <SingleTag
            item={{
              label: 'XJ',
              tagColor: 'var(--danger-dark)',
            }}
            isActive={true}
          />
        </FormItem>
        <FormItem label="触发规则" required={true}>
          <InputNumberRule
            labelTwo=" 小时以内，超过 "
            labelThree=" 人及以上，出现在同一场所 "
            getFieldDecorator={getFieldDecorator}
            inputNumberOne={{
              formValue: 'triggerDuration',
              formParams: {
                initialValue: triggerDuration,
              },
              formProps: {
                min: 1,
              },
            }}
            inputNumberTwo={{
              formValue: 'personCount',
              formParams: {
                initialValue: personCount,
              },
              formProps: {
                min: 1,
              },
            }}
          />
        </FormItem>
      </BoxDesc>
    );
  }
}

export default XjPersonGatheredRule;
