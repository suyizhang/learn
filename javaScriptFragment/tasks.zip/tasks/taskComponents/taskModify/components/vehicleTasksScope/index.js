import React from 'react';
import VehicleTasksScope from '../../formComponents/vehicleDeviceSelect';
import { Form } from 'antd'

const { Loader } = window;
const FormItem = Form.Item;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
function validateDevices(rule, value, callback) {
  const { deviceIds, isAll } = value;
  if(!isAll && deviceIds.length === 0){
    return callback('请选择布控范围');
  }
  if(!isAll && deviceIds.length > 1000){
    return callback('选中的设备不能超过1000路');
  }
  callback();
};

const TasksScope = props => {
  const { getFieldDecorator, itemData } = props;
  const { deviceIds=[] } = itemData;
  return (
    <BoxDesc title='任务范围' >
      <FormItem labelCol={{ span: 0 }} wrapperCol={{ span: 24 }}>
        {getFieldDecorator('tasksScope', {
          rules: [
            { validator: validateDevices }
          ],
          initialValue: {
            deviceIds,
            isAll: deviceIds.length === 0 ? true : false
          }
        })( <VehicleTasksScope /> )}
      </FormItem>
    </BoxDesc>
  )
}
export default TasksScope;