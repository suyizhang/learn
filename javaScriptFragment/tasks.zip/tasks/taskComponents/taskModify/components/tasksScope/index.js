import React from 'react';
import DevicesSelect from '../../formComponents/devicesSelect';
import { Form } from 'antd'

const { Loader } = window;
const FormItem = Form.Item;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');

const TasksScope = props => {
  const { getFieldDecorator, itemData } = props;
  const { deviceIds=[] } = itemData;
  return (
    <BoxDesc title='任务范围' >
      <FormItem labelCol={{ span: 0 }} wrapperCol={{ span: 24 }}>
        {getFieldDecorator('deviceIds', {
          rules: [
            { required: true, message: '请选择布控范围' },
          ],
          initialValue: deviceIds
        })( <DevicesSelect /> )}
      </FormItem>
    </BoxDesc>
  )
}
export default TasksScope;