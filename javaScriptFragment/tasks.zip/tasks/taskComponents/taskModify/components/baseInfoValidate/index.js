import React, { useRef } from 'react'
import CaptureTime from '../../formComponents/captureTime'
import { Form, DatePicker } from 'antd'

const { Loader, Service } = window
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc')
const Input = Loader.loadBaseComponent('Form', 'Input')
const TextArea = Loader.loadBaseComponent('Form', 'TextArea')
const FormItem = Form.Item
const RangePicker = DatePicker.RangePicker

const BaseInfoValidate = props => {
  const { getFieldDecorator, taskProps, itemData } = props
  const { taskType } = taskProps; // 布控任务参数集合
  const { name, description, validTime, invalidTime, captureStartTime, captureEndTime } = itemData
  const timer = useRef(null);
  function validateName(rule, value, callback){
    if(timer.current){
      clearTimeout(timer.current);
    }
    timer.current = setTimeout(() => {
      Service.dict.queryAll().then(res => {
        callback('任务名称重复')
      })
    }, 2000)
  }
  return (
    <BoxDesc title="基本信息" style={{ paddingBottom: 0 }}>
      <FormItem label="任务名称">
        {getFieldDecorator('name', {
          initialValue: name,
          rules: [
            { required: true, message: '请输入任务名称' },
            { max: 50, message: `任务名称不超过${50}个字` },
            { validator: validateName }
          ]
        })(<Input placeholder="请输入任务名称" style={{ width: '440px' }} />)}
      </FormItem>
      <FormItem label="任务有效期">
        {getFieldDecorator('validTime', {
          initialValue: [validTime, invalidTime],
          rules: [{ required: true, message: '请选择任务有效期' }]
        })(<RangePicker format="YYYY-MM-DD HH:mm:ss" style={{ width: '440px' }} showTime allowClear={false} />)}
      </FormItem>
      {taskType === 'eventMonitor' && (
        <FormItem label="任务执行时间">
          {getFieldDecorator('captureTime', {
            initialValue: {
              captureStartTime,
              captureEndTime
            },
            rules: [{ required: true, message: '请选择任务执行时间' }]
          })(<CaptureTime />)}
        </FormItem>
      )}
      <FormItem label="任务说明">
        {getFieldDecorator('description', {
          initialValue: description,
          rules: [{ max: 200, message: `任务说明不超过200个字` }]
        })(<TextArea placeholder="请输入任务说明文字" />)}
      </FormItem>
    </BoxDesc>
  )
}
export default BaseInfoValidate;
