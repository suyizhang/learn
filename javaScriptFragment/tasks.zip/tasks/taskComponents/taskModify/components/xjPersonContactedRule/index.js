import React from 'react';
import { Form } from 'antd';
import InputNumberRule from '../../formComponents/inputNumber';
import CommunitySelect from '../../formComponents/communitySelect';
import { accompanyRuleTips } from '../../../taskRuleTips';
import { getVillageName } from '../../../utils';

const { Loader } = window;
const FormItem = Form.Item;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const SingleTag = Loader.loadBusinessComponent("Tags", "SingleTag");

class XjPersonContactedRule extends React.Component {
  getTips = () => {
    const tipValue = this.props.getFieldsValue() || {};
    const itemData = this.props.itemData;
    const { 
      hours=itemData.hours, 
      appearCount=itemData.appearCount, 
      village=itemData.village ? itemData.village : {}
    } = tipValue;
    return accompanyRuleTips({
      hours: hours, personTagLabels: 'XJ人员', appearCount, villageName: village.villageName
    })
  };
  render() {
    const { getFieldDecorator, itemData, getFieldsValue } = this.props;
    const { village, hours, appearCount } = itemData;
    const villageName = getVillageName(village, getFieldsValue);
    return (
      <BoxDesc title="任务规则" style={{ paddingBottom: 0 }} className="rule-panel">
        {this.getTips()}
        <FormItem label="居住小区">
          {getFieldDecorator('village', {
            initialValue: village,
            rules: [{ required: true, message: '请选择居住小区' }]
          })(<CommunitySelect />)}
        </FormItem>
        <FormItem label="人员标签">
          <SingleTag item={{
            label: 'XJ',
            tagColor: 'var(--danger-dark)'
          }} isActive={true} />
        </FormItem>
        <FormItem label="其他人员">
          <div>排除居住在 <span style={{ fontWeight: 600 }}>{villageName}</span> 且标签符合上述规则的</div>
        </FormItem>
        <FormItem label="触发规则" required={true}>
          <InputNumberRule
              labelTwo=' 小时内，两类人员同出现次数大于 '
              labelThree=' 次'
              getFieldDecorator={getFieldDecorator}
              inputNumberOne={{
                formValue: 'hours',
                formParams: {
                  initialValue: hours
                },
                formProps: {
                  min: 1
                }
              }}
              inputNumberTwo={{
                formValue: 'appearCount',
                formParams: {
                  initialValue: appearCount
                },
                formProps: {
                  min: 1
                }
              }}
            />
        </FormItem>
      </BoxDesc>
    );
  }
}

export default XjPersonContactedRule;
