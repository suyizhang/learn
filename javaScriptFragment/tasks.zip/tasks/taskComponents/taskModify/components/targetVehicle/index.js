import React from 'react';
import AddVehicle from '../../formComponents/addVehicle';
import { Form } from 'antd';
import './index.less';
const { Loader } = window;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const FormItem = Form.Item;

const TargetVehicle = (props) => {
  const { getFieldDecorator, itemData } = props;
  const { vehicles=[] } = itemData;
  return (
    <BoxDesc title="目标车辆" style={{ paddingTop: '0px' }}>
      <FormItem labelCol={{ span: 0 }} wrapperCol={{ span: 24 }}>
        {getFieldDecorator('vehicles', {
          rules: [
            { required: true, message: '请添加目标车辆' },
            { validator: (rule, value, callback) => callback(value.length > 20 ? '布控目标不能超过20个' : undefined)}
          ],
          initialValue: vehicles
        })( <AddVehicle /> )}
      </FormItem>
    </BoxDesc>
  );
};

export default TargetVehicle;
