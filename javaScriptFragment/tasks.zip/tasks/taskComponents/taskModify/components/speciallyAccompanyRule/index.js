import React from 'react';
import { Form } from 'antd';
import InputNumberRule from '../../formComponents/inputNumber';
import PersonTags from '../../formComponents/personTags';
import CommunitySelect from '../../formComponents/communitySelect';
import { accompanyRuleTips } from '../../../taskRuleTips';
import { getVillageName, getTagLabel } from '../../../utils';
const { Loader, Dict } = window;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const FormItem = Form.Item;
const { preConvictionsTags, identity } = Dict.map;
const tagList = [...preConvictionsTags, ...identity].filter(v => {
  v.tagColor = 'var(--danger-dark)';
  return v.code !== '120502'
}); // 合并标签去掉前科人员
class SpeciallyAccompany extends React.Component {

  getTips = () => {
    const tipValue = this.props.getFieldsValue() || {};
    const itemData = this.props.itemData;
    const { 
      hours=itemData.hours, 
      appearCount=itemData.appearCount, 
      personTags=itemData.personTags || [],
      village=itemData.village || {}
    } = tipValue;
    return accompanyRuleTips({
      hours, 
      personTagLabels: getTagLabel(personTags, tagList), 
      appearCount, 
      villageName: village.villageName
    })
  };
  render() {
    const { getFieldDecorator, itemData, getFieldsValue } = this.props;
    const { personTags=[], village, hours, appearCount } = itemData;
    const villageName = getVillageName(village, getFieldsValue);
    return (
      <BoxDesc title="任务规则" style={{ paddingBottom: 0 }} className="rule-panel">
        {this.getTips()}
        <FormItem label="居住小区">
          {getFieldDecorator('village', {
            initialValue: village,
            rules: [{ required: true, message: '请选择居住小区' }]
          })(<CommunitySelect />)}
        </FormItem>
        <FormItem label="人员标签">
          {getFieldDecorator('personTags', {
            initialValue: personTags,
            rules: [{ required: true, message: '请选择人员标签' }]
          })(<PersonTags tagList={tagList}/>)}
        </FormItem>
        <FormItem label="其他人员">
          <div>排除居住在 <span style={{ fontWeight: 600 }}>{villageName}</span> 且标签符合上述规则的</div>
        </FormItem>
        <FormItem label="触发规则" required={true}>
        <InputNumberRule
            labelTwo=" 小时内，两类人员间同出现次数大于 "
            labelThree=" 次 "
            getFieldDecorator={getFieldDecorator}
            inputNumberOne={{
              formValue: 'hours',
              formParams: {
                initialValue: hours
              },
              formProps: {
                min: 0.5,
                max: 48
              }
            }}
            inputNumberTwo={{
              formValue: 'appearCount',
              formParams: {
                initialValue: appearCount
              },
              formProps: {
                min: 1
              }
            }}
          />
        </FormItem>
      </BoxDesc>
    );
  }
}

export default SpeciallyAccompany;
