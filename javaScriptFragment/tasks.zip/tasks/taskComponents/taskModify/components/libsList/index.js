import React from 'react';
import ScoreSlider from '../../formComponents/scoreSlider';
import LibsSelect from '../../formComponents/libsSelect';
import { Form } from 'antd';
const { Loader, BaseStore, Dict } = window;
const FormItem = Form.Item;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
/**
 * title 自定义比较复杂，根据taskLabel和libLabel在判断，具体情况具体待定，暂不优化
 */
const LibsList = props => {
  const { getFieldDecorator, itemData, taskProps } = props;
  const { libType, taskTypeLabel } = taskProps;
  const { alarmThreshold, libIds = [], libs = [] } = itemData;
  // title自定义
  const sceneCode = BaseStore.user.appInfo.sceneCode;
  const monitorLabel = Dict.map.monitorLabel[sceneCode];
  let titleLibs = [monitorLabel.keyPerson.libLabel, monitorLabel.outsider.libLabel, '人员入侵库', '布控库', '重点车辆库', '合规车辆库'];
  let labelTitle = titleLibs[libType - 1];
  return (
    <BoxDesc title={taskTypeLabel} style={{ paddingBottom: 0 }}>
      {![5, 6].includes(libType) && (
        <FormItem label="告警阈值">
          {getFieldDecorator('alarmThreshold', {
            initialValue: alarmThreshold || 80,
            rules: [{ required: true }]
          })(<ScoreSlider libType={libType} />)}
        </FormItem>
      )}
      <FormItem label={labelTitle}>
        {getFieldDecorator('libIds', {
          initialValue: libIds || libs,
          rules: [{ required: true, message: '请选择布控库' }]
        })(<LibsSelect titleLibs={labelTitle} libType={libType} />)}
      </FormItem>
    </BoxDesc>
  );
};
export default LibsList;
