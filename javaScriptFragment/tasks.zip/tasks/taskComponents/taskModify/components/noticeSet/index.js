import React from 'react';
import './index.less';
const { Loader } = window;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const CheckboxGroup = Loader.loadBaseComponent('Form', 'CheckGroup');
const Checkbox = Loader.loadBaseComponent('Form', 'Checkbox');

class NoticeSet extends React.Component {
  
  render() {
    const { getFieldDecorator, itemData } = this.props;
    const { noticeType=[] } = itemData;
    return (
      <BoxDesc title="提醒设置" className="vehicle-tags-notice-set">
        {getFieldDecorator('noticeType', {
          initialValue: noticeType
        })(
          <CheckboxGroup>
          <Checkbox value={'1'}>
            声音提示
          </Checkbox>
          <Checkbox value={'2'} style={{ marginLeft: '50px' }}>
            弹框提醒
          </Checkbox>
        </CheckboxGroup>
        )}
      </BoxDesc>
    );
  }
}

export default NoticeSet;
