import React from 'react';
import { Form, InputNumber, Select } from 'antd';
import CommunitySelect from '../../formComponents/communitySelect';
import {AgeLabel} from '../../../taskLabel'
import { idlehousehasPersonRuleTips } from '../../../taskRuleTips';

const { Loader } = window;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const FormItem = Form.Item;
const Option = Select.Option;
const relationsArray = [
  { value: 0, label: '且' },
  { value: 1, label: '或' },
]

class IdlehousehasPersonRule extends React.Component {
  getTips = () => {
    const tipValue = this.props.getFieldsValue() || {};
    const itemData = this.props.itemData;
    const { relations=itemData.relations, days=itemData.days, accessCardCount=itemData.accessCardCount,captureCount=itemData.captureCount,village=itemData.village||{} } = tipValue;
    let itemObj = relationsArray.find(v => v.value === relations) || {};
    
    return idlehousehasPersonRuleTips({villageName:village.villageName,days,captureCount,label: itemObj.label,accessCardCount});
  };
  render() {
    const { getFieldDecorator, itemData } = this.props;
    const { relations, days, accessCardCount,captureCount,village} = itemData;
    return (
      <BoxDesc title="任务规则" style={{ paddingBottom: 0 }} className="rule-panel">
        {this.getTips()}
        <FormItem label="居住小区">
          {getFieldDecorator('village', {
            initialValue: village,
            rules: [{ required: true, message: '请选择居住小区' }]
          })(<CommunitySelect  />)}
        </FormItem>
        <FormItem label="房屋状态">
          <AgeLabel label='闲置房'/>
        </FormItem>
        <FormItem label="任务规则" required={false}>
          <InputNumberRule 
            getFieldDecorator={getFieldDecorator} 
            days={days}
            accessCardCount={accessCardCount}
            relations={relations}
            captureCount={captureCount}
          />
        </FormItem>
        <FormItem label="任务计算方式" required={false}>
          每天
        </FormItem>
      </BoxDesc>
    );
  }
}

const InputNumberRule = ({ getFieldDecorator, days, relations, accessCardCount,captureCount }) => (
  <div>
    {getFieldDecorator('days', {
      initialValue: days 
    })(<InputNumber min={1} max={30} />)}
    <span> 天内，业主及其家属，在小区出现次数累计大于 </span>
    {getFieldDecorator('captureCount', {
      initialValue: captureCount 
    })(<InputNumber min={1}/>)}
    次，
    {
      getFieldDecorator('relations', {
        initialValue: relations  
      })(
        <Select style={{ width: '100px' }}>
          {
            relationsArray.map(v => (
              <Option value={v.value} key={v.value}>{v.label}</Option>
            ))
          }
        </Select> 
      )
    }
    <span> 名下门禁卡刷卡次数累计大于 </span>
    {getFieldDecorator('accessCardCount', {
      initialValue: accessCardCount 
    })(<InputNumber min={1}/>)}
    <span> 次</span>
  </div>
);

export default IdlehousehasPersonRule;
