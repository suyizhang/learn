import React from 'react';
import { Form } from 'antd';
import InputNumberRule from '../../formComponents/inputNumber';
const { Loader } = window;
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const SingleTag = Loader.loadBusinessComponent('Tags', 'SingleTag');
const FormItem = Form.Item;

const RuleConfig = props => {
  const { getFieldDecorator, itemData, taskCode } = props;
  const { triggerDuration, personCount } = itemData;
  return (
    <BoxDesc title="配置规则" className="lm-tl-judgement-center-config-rules">
      <FormItem label="人员标签">
        <SingleTag
          item={{
            label: '吸毒',
            tagColor: 'var(--danger-dark)',
          }}
          isActive={true}
        />
      </FormItem>
      {taskCode === '101565' && (
        <FormItem label="地点范围">
          <div>范围不限</div>
        </FormItem>
      )}
      {taskCode === '101564' && (
        <FormItem label="触发规则" required={true}>
          <InputNumberRule
            labelOne="近 "
            labelTwo=" 天内，出现 "
            labelThree=" 人及以上的地点 "
            getFieldDecorator={getFieldDecorator}
            inputNumberOne={{
              formValue: 'triggerDuration',
              formParams: {
                initialValue: triggerDuration,
              },
              formProps: {
                min: 1,
                max: 30,
              },
            }}
            inputNumberTwo={{
              formValue: 'personCount',
              formParams: {
                initialValue: personCount,
              },
              formProps: {
                min: 1,
              },
            }}
          />
        </FormItem>
      )}
      {taskCode === '101565' && (
        <FormItem label="触发规则" required={true}>
          <InputNumberRule
            labelOne="近 "
            labelTwo=" 小时内， "
            labelThree=" 人及以上"
            getFieldDecorator={getFieldDecorator}
            inputNumberOne={{
              formValue: 'triggerDuration',
              formParams: {
                initialValue: triggerDuration,
              },
              formProps: {
                min: 1,
              },
            }}
            inputNumberTwo={{
              formValue: 'personCount',
              formParams: {
                initialValue: personCount,
              },
              formProps: {
                min: 1,
              },
            }}
          />
        </FormItem>
      )}
    </BoxDesc>
  );
};
export default RuleConfig;
