import React, { Component } from 'react';
import { difference } from "lodash";
const { Loader, Service } = window;
const ListComponent = Loader.loadBaseComponent("List", "ClearList");
const IconFont = Loader.loadBaseComponent('IconFont');
const Row = Loader.loadBaseComponent("Grid", "Row");
const Col = Loader.loadBaseComponent("Grid", "Col");

class LibsSelect extends Component {
  constructor(props){
    super(props);
    this.state = {
      listData: [], // 全部布控库列表
      keywords: '', // 未分配布控库列表关键字
      selKeywords: '', // 已分配布控库列表关键字
      selectKey: [], // 左侧列表被选中的布控库
      tentLibsList: [], // 右侧布控库列表
      selectLibsKey: [], // 右侧选中的布控库列表
      LeftListKey: Math.random(), // 用于刷新左侧列表的全选和反选状态
    }
  }

  async componentDidMount(){
    let { libType, value } = this.props
    let result;
    if(libType === 5 || libType === 6){
      result = await Service.monitorLib.getVehicleLibs({libType:libType === 5?1:3})
      result.data.list.forEach(v => {
        v.name=v.libName
      })
    }else{
      result = await Service.monitorLib.queryMonitorLibs({ libType })
      
    }
    let listData = result.data.list || []
      let tentLibsList = [], selectKey = [], selectLibsKey=[];
      if(Array.isArray(value) && value.length > 0){
        tentLibsList = listData.filter(v => ~value.indexOf(v.id));
        selectKey = selectLibsKey = value;
      }
      this.setState({ 
        listData,
        selectKey,
        tentLibsList,
        selectLibsKey
      });
  }

  // 通过ids拿到对应的布控库列表
  getLibsInfoByIds = ids => {
    const { listData } = this.state;
    return listData.filter(v => ~ids.indexOf(v.id));
  }

  // 未分配布控库关键字
  onChangeKeywords = keywords => {
    this.setState({ keywords });
  }

  // 已分配布控库关键字
  onChangeSelectedKeyword = selKeywords => {
    this.setState({ selKeywords });
  }

  // 选择待添加的布控库 (选中后同步到右侧组件，同时同步的布控库全部选中)
  /**
   * @param keys 当前选中的id集合
   */
  checkLibsList = keys => {
    const { selectLibsKey, selectKey } = this.state;
    let addKey = difference(keys, selectKey); // 新加的key
    let delKey = difference(selectKey, keys); // 删除的key
    let selectLibsKeyFilter = [].concat(difference(selectLibsKey, delKey), addKey);
    this.setState({ 
      selectKey: keys,
      selectLibsKey: selectLibsKeyFilter,
      tentLibsList: this.getLibsInfoByIds(keys),
    });
    this.props.onChange && this.props.onChange(selectLibsKeyFilter);
  }

  // 右侧列表选中
  checkedLibs = keys => {
    this.setState({ selectLibsKey: keys });
    this.props.onChange && this.props.onChange(keys);
  }

  // 待添加列表取消选中
  deleteItem = item => {
    const { selectLibsKey, selectKey } = this.state;
    let selectKeyFilter = difference(selectKey, [item.id]);
    let selectFilter = difference(selectLibsKey, [item.id]);
    this.setState({
      selectKey: selectKeyFilter,
      selectLibsKey: selectFilter,
      tentLibsList: this.getLibsInfoByIds(selectKeyFilter),
      LeftListKey: Math.random()
    });
    this.props.onChange && this.props.onChange(selectFilter);
  }

  // 筛选列表的数据
  getDataList = (list, key) => {
    let keywords = this.state[key];
    if(keywords){
      return list.filter(v => ~v.name.indexOf(keywords));
    }
    return list;
  }

  render(){
    const { listData, keywords, selKeywords, selectKey, tentLibsList, selectLibsKey, LeftListKey } = this.state;
    const { style={ height: '300px' }, titleLibs } = this.props;
    let leftList = this.getDataList(listData, 'keywords');
    let rightList = this.getDataList(tentLibsList, 'selKeywords');
    return (
      <Row className='person-monitor-tasks-libs-select' gutter={8}>
        <Col span='12' style={style}>
          <ListComponent 
            title={titleLibs ? titleLibs : '重点人员库'}
            placeholder='请输入你要搜索的库'
            checkable={true}
            keywords={keywords}
            onChange={this.onChangeKeywords}
            whatIcon={() => <IconFont type='icon-S_Bar_Layer' />}
            list={leftList}
            onChecked={this.checkLibsList}
            checkedKeys={selectKey}
            key={LeftListKey}
          />
        </Col>
        <Col span='12' style={style}>
          <ListComponent 
            title={`已添加${titleLibs ? titleLibs : '重点人员库'}(${selectLibsKey.length || 0}个)`}
            placeholder='请输入你要搜索的库'
            keywords={selKeywords}
            checkable={true}
            onChange={this.onChangeSelectedKeyword}
            whatIcon={() => <IconFont type='icon-S_Bar_Layer' />}
            list={rightList}
            checkedKeys={selectLibsKey} // 选中的布控库
            onChecked={this.checkedLibs}
            deleteItem={this.deleteItem}
          />
        </Col>
      </Row>
    )
  }
}
export default LibsSelect;