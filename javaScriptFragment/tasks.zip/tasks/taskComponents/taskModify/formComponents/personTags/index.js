import React, { Component } from 'react';
const { Loader } = window;
const SingleTag = Loader.loadBusinessComponent("Tags", "SingleTag");

class PersonTags extends Component {
  constructor(props){
    super(props);
    this.state = {
      value: props.value || []
    }
  }

  onChange = item => {
    let { value } = this.state;
    const { onChange } = this.props;
    let index = value.indexOf(item.code);
    index === -1 ? value.push(item.code) : value.splice(index, 1);
    this.setState({ value });
    onChange && onChange(value);
  }
  render(){
    const { value } = this.state;
    const { tagList=[] } = this.props;
    return (
      <div className='task-from-person-tags'>
        {
          tagList.map(v => (
            <SingleTag 
              item={v} 
              key={v.code}
              isActive={~value.indexOf(v.code)}
              onSelect={this.onChange}
              style={{ marginLeft: '8px' }}
            />
          ))
        }
      </div>
    )
  }
}
export default PersonTags;