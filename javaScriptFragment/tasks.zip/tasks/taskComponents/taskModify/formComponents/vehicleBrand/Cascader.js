import React from "react";
import { Icon } from 'antd';

const dictAll = { code: 'all', name: '全部' };

export const CascaderList = ({
  className = '',
  id,
  visible,
  data,
  renderItem,
  onClick,
  selectIds,
  hasAll=true
}) => {
  return (
    <ul id={id} className={`ant-cascader-menu ${className} ${visible ? '' : 'hide'}`}>
      {!!hasAll && <CascaderItem
        item={dictAll}
        onClick={onClick}
        selectIds={selectIds}
      />}
      {data.map((item, k) => (
        renderItem
          ? renderItem(item, k)
          : <CascaderItem
            item={item}
            onClick={onClick}
            selectIds={selectIds}
          />
      ))}
    </ul>
  )
}

export const CascaderItem = ({ item, onClick, selectIds }) => {
  const hasChild = item.typeName !== 'vehicleYear' && item.code !== 'all';
  const active = selectIds.includes(item.code);
  return (
    <li
      key={item.code} onClick={() => onClick(item)}
      className={`
        ant-cascader-menu-item 
        ${hasChild ? 'ant-cascader-menu-item-expand' : ''}
        ${active ? 'ant-cascader-menu-item-active' : ''}
      `}
      title={item.name}
    >
      {item.name}
      <span className="ant-cascader-menu-item-expand-icon">
        {hasChild && <Icon type='right' />}
      </span>
    </li>
  )
}
