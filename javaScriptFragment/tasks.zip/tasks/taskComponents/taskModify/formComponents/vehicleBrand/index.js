import React, { useState, useRef, useMemo, useEffect } from "react";
import { Anchor, Icon } from 'antd';
import './index.less';
import { CascaderList, CascaderItem } from './Cascader';
const {  Utils, Dict, Shared, Service } = window; //Loader,

const { Link } = Anchor;
// const BaseTitle = Loader.loadBaseComponent("Title", "BaseTitle");
const anchorList = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

// 获取第一个字母
const getFirstLetter = (item) => {
  return item.pinyin.slice(0, 1).toLocaleUpperCase();
}
// 近15年字典
const getLastedYear = () => {
  const currentYear = new Date().getFullYear() + 1;
  const lastYear = currentYear - 15;
  const yearDict = Dict.map.vehicleYear.filter(v => v.name <= currentYear && v.name >= lastYear);
  yearDict.forEach(v => v.name = `${v.name}款`)
  return yearDict;
}
// const sourceData = Dict.map.vehicleBrands;
const yearDict = getLastedYear();
const getLabel = (value, sourceData) => {
  let [lv1Code, lv2Code, lv3Code] = value;
  // 清空操作
  let label = '';
  if (!lv1Code) {
    return label;
  }
  const lv1Item = sourceData.find(v => v.code === lv1Code) || { name: '' };
  label = lv1Item.name;
  if (lv2Code === 'all' || !lv2Code) {
    // 选中全部子品牌 或 全部年份 或未选
    return label;
  }
  const lv2List = lv1Item.childDictionary && lv1Item.childDictionary.length;
  let lv2Item = (lv2List ? lv1Item.childDictionary : yearDict).find(v => v.code === lv2Code) || { name: '' };
  label += ` / ${lv2Item.name || ''}`
  if (lv3Code === 'all' || !lv3Code) {
    // 选中全部年份 或 没有三级菜单
    return label;
  }
  // 选中单个年份
  const lv3Item = yearDict.find(v => v.code === lv3Code) || { name: '' }
  label += ` / ${lv3Item.name}`
  return label;
}

const HEIGHT = 300

/*
  TODO:
  1. 数据定位
*/
const VehicleBrands = (props) => {
  const { className = '',  value, onChange } = props; //title, icon,
  const [id] = useState(`brand_select_${Math.random}`);
  const [sourceData, setSourceData] = useState([]);
  const [secendData, setSecendData] = useState([]);
  const [thirdData, setThirdData] = useState([]);
  const [selectIds, setSelectIds] = useState([]);
  const [visible, setVisible] = useState({ lv1: false, lv2: false, lv3: false });
  const [style, setStyle] = useState({});
  const [label, setLabel] = useState('');
  const cascaderRef = useRef();
  const firstRef = useRef();

  const inputRef = useRef();
  // 获取车辆品牌字典
  useEffect(() => {
    const memoVehicleBrands = Shared.memoryCache.vehicleBrands;
    if (memoVehicleBrands && memoVehicleBrands.length) {
      return setSourceData(memoVehicleBrands)
    }
    // 处理车辆品牌子品牌
    async function fetchVehicleBrand() {
      const code = 117100;
      const result = await Service.dict.findTreeDic({ code });
      const { vehicleBrands } = Dict.map;
      vehicleBrands.forEach(v => {
        let item = result.data.find(x => x.code === v.code) || {};
        v.childDictionary = item.childDictionary;
      })
      const vehicleBrandsData = vehicleBrands.sort((x, y) => x.pinyin.localeCompare(y.pinyin));
      Shared.memoryCache.vehicleBrands = vehicleBrandsData;
      Dict.map.vehicleBrands = vehicleBrandsData;
      setSourceData(vehicleBrandsData)
    }
    fetchVehicleBrand()
  }, []);
  // 区域外点击关闭弹窗
  useEffect(() => {
    const clickEvent = (e) => {
      // e.target.scrollIntoView()
      if (!e.path.includes(cascaderRef.current) && !e.path.includes(inputRef.current)) {
        resetSelect();
      }
    }
    document.body.addEventListener('click', clickEvent)
    return () => document.body.removeEventListener('click', clickEvent)
  }, [value]);
  // 处理选中
  useEffect(() => {
    setSelectIds(value)
    setLabel(getLabel(value, sourceData))
  }, [value, sourceData])
  // 关闭弹窗时，重新定位位置
  // useEffect(() => {
  //   if (!visible.lv1) {
  //     const activeDoms = cascaderRef.current.querySelectorAll('.ant-cascader-menu-item-active');
  //     console.log(activeDoms);
  //     activeDoms.forEach(v => v.scrollIntoView())
  //   }
  // }, [visible.lv1])
  // 区域外关闭弹窗并还原数据
  const resetSelect = () => {
    setSelectIds(value)
    onBlur();
  }
  // 渲染方向判断
  const computedPosition = () => {
    const { top, left } = inputRef.current.getBoundingClientRect();
    let style = { top: top + 30, left, height: HEIGHT }
    const bodyHeight = document.body.clientHeight;
    if (style.top + HEIGHT > bodyHeight) {
      style.top = top - HEIGHT
    }
    return style
  }
  // 输入框 focus 事件
  const onFocus = () => {
    if (visible.lv1) {
      // 还原选中并关闭弹窗
      return resetSelect()
    }
    const [, lv2, lv3] = selectIds;
    setVisible({ lv1: true, lv2: !!lv2, lv3: !!lv3 });
    const style = computedPosition()
    setStyle(style);
  }
  const onLv1Click = (item) => {
    const newSelectIds = [item.code];
    setThirdData([]);
    if (item.code === 'all') {
      setSecendData([]);
      return endSelect(newSelectIds)
    }
    setSelectIds(newSelectIds);
    if (!item.childDictionary || !item.childDictionary.length) {
      // 无子品牌，补年份数据
      setSecendData(yearDict);
    } else {
      setSecendData(item.childDictionary);
    }
    setVisible({ lv1: true, lv2: true, lv3: false })
  }
  const onLv2Click = (item) => {
    const newSelectIds = [selectIds[0], item.code];
    // 选中的全部 或 选中的是年份(即没有第三级)
    if (item.code === 'all' || item.typeName === 'vehicleYear') {
      setThirdData([]);
      return endSelect(newSelectIds)
    }
    // 选中的是单项，补齐年份数据
    setThirdData(yearDict);
    setVisible({ lv1: true, lv2: true, lv3: true });
    setSelectIds(newSelectIds);
  }
  const onLv3Click = (item) => {
    const [lv1, lv2] = selectIds;
    const newSelectIds = [lv1, lv2, item.code];
    endSelect(newSelectIds)
  }
  // 选择结束
  const endSelect = (value) => {
    onBlur();
    onChange(value.filter(v => v && v !== 'all'));
  }
  // 关闭弹窗
  const onBlur = () => {
    setVisible({ lv1: false, lv2: false, lv3: false })
  }
  // 清空数值
  const onClear = (e) => {
    Utils.stopPropagation(e);
    endSelect([])
  }
  // 给一级品牌添加锚点
  const renderFirstItem = (item, idx) => {
    let lastLetter = idx < 1 ? undefined : getFirstLetter(sourceData[idx - 1]);
    let currentLetter = getFirstLetter(item);
    let nextLetter = idx === (sourceData.length - 1) ? 'Z' : getFirstLetter(sourceData[idx + 1]);
    if (currentLetter === nextLetter && currentLetter !== lastLetter) {
      return (
        <>
          <li key={currentLetter} id={`${id}_${currentLetter}`}
            className={`ant-cascader-menu-item ant-cascader-menu-item-disabled`}
            style={{ color: 'var(--primary)' }}
          >
            {currentLetter}
          </li>
          <CascaderItem item={item} onClick={onLv1Click} selectIds={selectIds} domRef={firstRef} />
        </>
      )
    }
    return <CascaderItem item={item} onClick={onLv1Click} selectIds={selectIds} />
  }

  const hasValue = useMemo(() => value && value.length, [value])

  return (
    <div className={`lm-filter-vehicle-brand-wrapper ${className}`}>
      {/* {title && <BaseTitle icon={icon} title={title} />} */}
      <div className='vehicle-brand-wrapper'>
        <div onClick={onFocus} ref={inputRef} className={`ant-cascader-picker ${visible.lv1 ? 'ant-cascader-picker-focused' : ''}`}>
          <span className="ant-cascader-picker-label" title={label}>{label}</span>
          <input
            placeholder={hasValue ? '' : '请选择车辆品牌'}
            // value={value}
            className="ant-input ant-cascader-input"
            readonly
            autocomplete="off"
          />
          <Icon
            style={{ display: hasValue ? 'block' : 'none' }}
            type="close-circle" theme="filled"
            className='ant-cascader-picker-clear'
            onClick={onClear}
          />
          <Icon type="down"
            className={`ant-cascader-picker-arrow ${visible.lv1 ? 'ant-cascader-picker-arrow-expand' : ''}`}
          />
        </div>
        <div
          className={`vehicle-brand-list ${visible.lv1 ? '' : 'hide'}`}
          ref={cascaderRef}
          style={style}
        >
          <Anchor
            className='vehicle-brand-anchor'
            getContainer={() => document.getElementById(id)}
            onClick={e => e.preventDefault()}
          >
            {anchorList.map(v => (
              <Link href={`#${id}_${v}`} key={v} title={v} />
            ))}
          </Anchor>
          <div className='ant-cascader-menus'>
            <CascaderList
              id={id}
              className='first-list'
              hasAll={false}
              visible={true}
              data={sourceData}
              renderItem={renderFirstItem}
            />
            <CascaderList
              className='secend-list'
              visible={visible.lv2}
              data={secendData}
              onClick={onLv2Click}
              selectIds={selectIds}
            />
            <CascaderList
              className='third-list'
              visible={visible.lv3}
              data={thirdData}
              onClick={onLv3Click}
              selectIds={selectIds}
            />
          </div>
        </div>
      </div>
    </div>
  )
}

export default VehicleBrands;