import React, { Component } from 'react';
import { inject, observer } from "mobx-react";
import SelectBtn from '../../../selectBtn';
const { Loader, Utils } = window;
const SelectPointsMap = Loader.loadBusinessComponent("LMap", "SelectPointsMap");
const SelectDevices = Loader.loadBaseComponent("List", "SelectDevices");

@inject("device", "organization", "place")
@observer
class DevicesSelect extends Component {
  constructor(props){
    super(props);
    this.state = {
      type: 1, // 地图模式：1  列表模式：2
    }
  }

  // tab切换
  changeType = type => {
    this.setState({ type });
  }

  // 地图选择设备改变
  onChange = ids => {
    this.props.onChange && this.props.onChange(ids);
  }

  render(){
    const { type } = this.state;
    const { device, place, organization, value=[] } = this.props;
    return (
      <div>
        <SelectBtn style={{ marginBottom: '16px' }} type={type} changeType={this.changeType} />
        <div style={{ height: '540px' }}>
          { type === 1 && <SelectPointsMap 
            points={device.cameraList}
            selectKeys={value}
            onChange={this.onChange}
          />}
          { type === 2 && <SelectDevices 
            selectDevices={value}
            placeTreeData={Utils.computPlaceTree(place.placeListWithCameraCount)}
            orgTreeData={Utils.computTreeList(organization.orgListWithCameraCount)}
            onChange={this.onChange}
          />}
        </div>
      </div>
    )
  }
}
export default DevicesSelect;