import React, { Component } from 'react';
import './index.less';
const { Loader } = window;
const RadioGroup = Loader.loadBaseComponent('Form', 'RadioGroup');
const Radio = Loader.loadBaseComponent('Form', 'Radio');
const Button = Loader.loadBaseComponent('Form', 'Button');
const timeBtns = [
	{
		label: '周一',
		value: '1'
	}, {
		label: '周二',
		value: '2'
	}, {
		label: '周三',
		value: '3'
	},{
		label: '周四',
		value: '4'
	},{
		label: '周五',
		value: '5'
	},{
		label: '周六',
		value: '6'
	},{
		label: '周日',
		value: '7'
	},
]
class RepeatMode extends Component {
  constructor(props){
		super(props);
		const { value } = props;
    this.state = {
      repeatModeState: value === '8' ? value : '1',
    }
	}
	
  changeRepeatMode = e => {
    let repeatModeState = e.target.value; // '8'为每天 '1'为自定义
		let repeatMode = repeatModeState === '8' ? repeatModeState : '';
		this.setState({ repeatModeState });
    this.props.onChange && this.props.onChange(repeatMode);
  }

  /**
   * @desc 重复方式类型选择-自定义
   * @param {string} val 事件对象
   */
	changeRepeatModeItem = val => {
    const { value, onChange } = this.props;
    let repeatModeArr = value ? value.split(',') : [];
		let index = repeatModeArr.indexOf(val);
		if(index !== -1){
			repeatModeArr.splice(index,1);
		}else{
			repeatModeArr.push(val);
		}
    let repeatMode = repeatModeArr.join(',');
    onChange && onChange(repeatMode);
  }
  
  render(){
    const { repeatModeState } = this.state;
    const repeatMode = this.props.value;
    let repeatModeArr = repeatMode ? repeatMode.split(',') : [];
    return (
      <div className='task-modify-repeat-mode-box'>
        <RadioGroup onChange={this.changeRepeatMode} value={repeatModeState}>
          <Radio value='8'>每天</Radio>
					<Radio value='1'>自定义</Radio>
        </RadioGroup>
        {repeatModeState === '1' && 
          timeBtns.map(v => (<Button
            key={v.value}
            className={repeatModeArr.indexOf(v.value) === -1 ? '' : 'active'}
            onClick={this.changeRepeatModeItem.bind(this,v.value)}
          >
            {v.label}
          </Button>)
        )}
      </div>
    )
  }
}
export default RepeatMode;