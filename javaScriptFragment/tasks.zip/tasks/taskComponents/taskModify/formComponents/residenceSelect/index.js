import React, { Component } from 'react';
import { Cascader, Button } from 'antd';
import './index.less';

const { Utils, Loader } = window;
const IconFont = Loader.loadBaseComponent('IconFont');

class ResidenceSelect extends Component {
  constructor(props){
    super(props);
    let residenceValue = [[]];
    if(Array.isArray(props.value) && props.value.length > 0){
      residenceValue = props.value;
    }
    this.state = {
      residenceValue, // 户籍数据
    }
  }

  // 添加户籍
  onAdd = () => {
    this.setState({
      residenceValue: [...this.state.residenceValue, []]
    })
  }

  // 删除户籍
  onDelete = index => {
    let { residenceValue } = this.state;
    residenceValue.splice(index, 1);
    this.setState({ residenceValue });
    this.onFormChange(residenceValue);
  }

  onChange = (index, value) => {
    let { residenceValue } = this.state;
    residenceValue[index] = value;
    this.setState({ residenceValue });
    this.onFormChange(residenceValue);
  }

  // 数据处理提交到父组件
  onFormChange = value => {
    const { onChange } = this.props;
    let residenceValue = value.filter(v => !!v.length);
    onChange && onChange(residenceValue);
  }

  render() {
    const { residenceValue=[] } = this.state;
    const { locationData } = this.props;
    let options = Utils.computTreeList(locationData,"code","parentCode")
    return (
      <div className='lm-task-rule-residence-select'>
        {
          residenceValue.map((v, index)=> {
            let flag = residenceValue.length - 1 === index;
            return (
              <div className='residence-select-item' key={index}>
                <Cascader
                  options={options}
                  value={v}
                  placeholder="请选择户籍"
                  showSearch
                  size="small"
                  style={{ width: '202px' }}
                  onChange={value => this.onChange(index, value)}
                  fieldNames={{ label: 'name', value: 'code', children: 'children' }}

                />
                <Button onClick={() => flag ? this.onAdd() : this.onDelete(index)} >
                  <IconFont type={flag ? "icon-S_Edit_LinePlus" : 'icon-S_Edit_LineMinus'} />
                  {flag ? '添加户籍' : '删除户籍'}
                </Button>
              </div>
            )
          })
        }
      </div>
    )
  }
}
export default ResidenceSelect;