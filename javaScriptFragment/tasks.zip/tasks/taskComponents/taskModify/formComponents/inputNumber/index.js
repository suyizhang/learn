import React from 'react';
import { InputNumber } from 'antd';

const InputNumberRule = ({ getFieldDecorator, labelOne, labelTwo, labelThree, labelFour, inputNumberOne, inputNumberTwo, inputNumberThree }) => (
  <div>
    <span>{labelOne}</span>
    {inputNumberOne && getFieldDecorator(inputNumberOne.formValue, inputNumberOne.formParams)(<InputNumber {...inputNumberOne.formProps} />)}
    <span>{labelTwo}</span>
    {inputNumberTwo && getFieldDecorator(inputNumberTwo.formValue, inputNumberTwo.formParams)(<InputNumber {...inputNumberTwo.formProps} />)}
    <span>{labelThree}</span>
    {inputNumberThree && getFieldDecorator(inputNumberThree.formValue, inputNumberThree.formParams)(<InputNumber {...inputNumberThree.formProps} />)}
    <span>{labelFour}</span>
  </div>
);

export default InputNumberRule;
