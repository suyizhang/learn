import React, { useState, useEffect, useRef, useMemo, useLayoutEffect } from 'react';
import { Button, message } from 'antd';
import ReactDOM from 'react-dom';
import _ from 'lodash';
import './index.less';

const { Loader,Utils } = window;
const IconFont = Loader.loadBaseComponent('IconFont');

function TaskTimePartPick({ value, onChange }) {
  const [executionTime, setExecutionTime] = useState(function() {
    let initValue = value ? value : [];
    if (!!initValue.length) {
      initValue = value.map(times => times.map(time => Math.round(time / (60 * 60 * 1000))));
    }
    return initValue;
  });

  const timesSpace = useMemo(() => {
    const times = [];
    executionTime.forEach(v => {
      if (v.length) {
        const [start, end] = v;
        for (let i = start; i < end + 1; i++) {
          times.push(i);
        }
      }
    });
    return times;
  }, [executionTime]);

  useEffect(() => {
    if (!onChange) {
      return;
    }
    onChange(executionTime.filter(v => v.length !== 0).map(times => times.map(time => time * 60 * 60 * 1000)));
    }, [onChange, executionTime]);

  const onAdd = function() {
    setExecutionTime(executionTime => {
      const newExecutionTime = _.cloneDeep(executionTime);
      newExecutionTime.push([]);
      return newExecutionTime;
    });
  };

  const onDelete = function(index) {
    setExecutionTime(executionTime => {
      let newExecutionTime = _.cloneDeep(executionTime);
      newExecutionTime.splice(index, 1);
      return Utils.isEqual(newExecutionTime, executionTime) ? executionTime : newExecutionTime;
    });
  };

  const onChangeTime = function(range, i) {
    setExecutionTime(executionTime => {
      let newExecutionTime = _.cloneDeep(executionTime);
      newExecutionTime[i] = range;
      return Utils.isEqual(newExecutionTime, executionTime) ? executionTime : newExecutionTime;
    });
  };
  
  return (
    <div className="lm-c-task-time-part-pick">
      <div className="type-radio">
        每天  
      </div>
      <div className="time-pick">
        {executionTime.map((v, i) => (
          <TimePickRange
            key={i}
            onDelete={i !== executionTime.length - 1 && executionTime.length !== 1 ? () => onDelete(i) : false}
            value={v}
            timesSpace={v.length === 2 ? timesSpace.filter(v2 => !(v2 >= v[0] && v2 <= v[1])) : timesSpace}
            index={i}
            onAdd={i === executionTime.length - 1 ? onAdd : false}
            onChange={range => onChangeTime(range, i)}
          />
        ))}
      </div>
    </div>
  );
}

function TimePickRange({ value, onAdd, onDelete, onChange, timesSpace }) {
  const [rangeValue, setRnageValue] = useState(value || []);
  const [visible, setVisible] = useState(false);
  const boxRef = useRef(null);
  const timeDicts = useMemo(() => new Array(25).fill(true).map((_, i) => i), []);
  const timeText = useMemo(() => {
    if (rangeValue[0] === undefined || rangeValue[1] === undefined) {
      return '';
    }
    return `${rangeValue[0] >= 10 ? rangeValue[0] : '0' + rangeValue[0]}:00 - ${rangeValue[1] >= 10 ? rangeValue[1] : '0' + rangeValue[1]}:00`;
  }, [rangeValue]);

  useLayoutEffect(() => {
    const container = ReactDOM.findDOMNode(boxRef.current).querySelector('.ant-time-picker');

    function openVisibelProtal() {
      setVisible(true);
    }

    container.addEventListener('click', openVisibelProtal, false);
    return () => container.removeEventListener('click', openVisibelProtal, false);
  }, []);

  useLayoutEffect(() => {
    function hideVisible(e) {
      const container = ReactDOM.findDOMNode(boxRef.current).querySelector('.ant-time-picker');
      if (e.path && e.path.includes(container)) {
        return;
      }
      setVisible(false);
    }

    document.body.addEventListener('click', hideVisible, false);
    return () => document.body.removeEventListener('click', hideVisible, false);
  }, []);

  useEffect(() => {
    if (rangeValue && rangeValue[0] !== undefined && rangeValue[1] !== undefined) {
      const arr = createTimeRangeList(...rangeValue);
      if (_.intersection(timesSpace, arr).length !== 0) {
        setRnageValue([]);
        message.warn('时间段存在交叉请重新选择！');
      } else {
        onChange(rangeValue);
      }
    }
  }, [onChange, rangeValue, timesSpace]);

  useEffect(() => {
    setRnageValue(() => value);
  }, [value]);

  const selectStart = function(e) {
    const start = +e.target.dataset.value;
    setRnageValue(value => [start, value[1]]);
  };
  const selectEnd = function(e) {
    const end = +e.target.dataset.value;
    setRnageValue(value => [value[0], end]);
  };
  const [start, end] = rangeValue;
  return (
    <div className="lm-c-time-range-pick" ref={boxRef}>
      <span class="ant-time-picker">
        <input class="ant-time-picker-input" type="text" placeholder="请选择时间段" id="" value={timeText} />
        <span class="ant-time-picker-icon">
          <IconFont type="icon-S_Edit_ClockEnd"></IconFont>
        </span>
        {visible && (
          <div className="lm-c-protal-time-group">
            <ul className="protal-time-item">
              {timeDicts.map(v => {
                const disabled = !(!timesSpace.includes(v) && !(end && v >= end));
                return (
                  <li onClick={e => !disabled && selectStart(e)} data-value={v} className={`${start === v ? 'active' : ''} ${disabled ? 'disabled' : ''}`}>{`${
                    v >= 10 ? v : '0' + v
                  }:00`}</li>
                );
              })}
            </ul>
            <ul className="protal-time-item">
              {timeDicts.map(v => {
                const disbled = !(!timesSpace.includes(v) && !(start && v <= start));
                return (
                  <li onClick={e => !disbled && selectEnd(e)} data-value={v} className={`${end === v ? 'active' : ''} ${disbled ? 'disabled' : ''}`}>{`${
                    v >= 10 ? v : '0' + v
                  }:00`}</li>
                );
              })}
            </ul>
          </div>
        )}
      </span>
      {onAdd && (
        <Button onClick={onAdd}>
          <IconFont type="icon-S_Edit_PlusLine" />
          添加时间段
        </Button>
      )}
      {onDelete && (
        <Button onClick={onDelete}>
          <IconFont type="icon-S_Edit_MinusLine" />
          删除时间段
        </Button>
      )}
    </div>
  );
}

function createTimeRangeList(start, end) {
  const arr = [];
  for (let i = start; i < end + 1; i++) {
    arr.push(i);
  }
  return arr;
}

export default TaskTimePartPick;
