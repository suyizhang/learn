import React from 'react';
import _ from 'lodash';
import { Form, Select, message } from 'antd';
import VehicleBrands from '../vehicleBrand';
import './index.less';
const { Loader, Dict } = window;
const FormContent = Loader.loadBaseComponent('Drawer', 'FormContent');
const FormItem = Form.Item;
const Input = Loader.loadBaseComponent('Form', 'Input');
const CheckboxGroup = Loader.loadBaseComponent('Form', 'CheckGroup');
const Checkbox = Loader.loadBaseComponent('Form', 'Checkbox');
const Option = Select.Option;

function handleData(data){
  let { vehicleClasses=[], ...rest } = _.cloneDeep(data);
  let vehicleArray = [];
  // 预留多选 车辆类型处理
  vehicleClasses.forEach(v => {
    let item = Dict.map.vehicleClasses.find(k => k.ids.indexOf(+v) > -1);
    if(item){
      vehicleArray.push(item.value);
    }
  })
  return { ...rest, vehicleClasses: [...new Set(vehicleArray)] };
}

// 车牌相关正则校验
function validatePlateNo(rule, value, callback){
  console.log(value, value.length);
  // 1.检验车牌位数
  if(value.length !== 7 && value.length !== 8){
    console.log(value.length !== 7 , value.length !== 8, '=====')
    return callback('请输入正确的车牌位数');
  }
  // 2.检验车牌首位
  const firstStr = /^[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z\?]{1}[A-Z\?]{1}.*/;
  if(!firstStr.test(value)){
    return callback('请输入正确的车牌格式');
  }
  // 3.校验模糊位
  if(value.match(/\?/g) && value.match(/\?/g).length > 3){
    callback('车牌未知项最多不超过3位');
  }
  callback(undefined);
}

const AddDrawer = (props) => {
  const { closeDrawer, form, submitForm, data } = props;
  // 车辆数据处理
  const { plateColors, plateNo, vehicleBrands, vehicleClasses, vehicleColors } = handleData(data);
  const { getFieldDecorator } = form;
  function handleSave() {
    console.log('提交');
    form.validateFields((err, values) => {
      if (err) {
        return;
      }
      submitForm && submitForm(values);
      message.success(plateNo ? '修改成功' : '添加成功');
      closeDrawer(false);
    });
  }
  
  return (
    <FormContent className="lm-tl-vehicle-add-drawer-box" onCancel={closeDrawer} onOk={handleSave} labelCol={{ span: 4 }} wrapperCol={{ span: 20 }}>
      <div className="title-tips" style={{ color: '#1C3769', fontWeight: 700, fontSize: '14px', lineHeight: '32px' }}>
        添加属性标签
      </div>
      <FormItem label="车牌号码">
        {getFieldDecorator('plateNo', {
          rules: [
            { required: true, message: '请输入车牌号码' },
            { validator: validatePlateNo }
          ],
          initialValue: plateNo
        })(<Input placeholder={`请输入车牌号码，未知项可用"?"代替`} />)}
      </FormItem>
      <FormItem label="车辆类型">
        {getFieldDecorator('vehicleClasses', {
          initialValue: vehicleClasses
        })(
          <Select placeholder="请选择车辆类型" mode='multiple'>
            {Dict.map.vehicleClasses.map((v) => (
              <Option value={v.value} key={v.value}>
                {v.label}
              </Option>
            ))}
          </Select>
        )}
      </FormItem>
      <FormItem label="车辆品牌">
        {getFieldDecorator('vehicleBrands', {
          initialValue: vehicleBrands || [],
        })(<VehicleBrands />)}
      </FormItem>
      <FormItem label="车辆颜色" className="add-vehicle-checkout-group-box">
        {getFieldDecorator('vehicleColors', {
         initialValue: vehicleColors,
        })(
          <CheckboxGroup>
            {Dict.map.vehicleColor.map((v) => (
              <Checkbox value={v.code} key={v.code}>
                {v.label}
              </Checkbox>
            ))}
          </CheckboxGroup>
        )}
      </FormItem>
      <FormItem label="车牌颜色">
        {getFieldDecorator(
          'plateColors',
          {
            initialValue: plateColors,
          }
        )(
          <CheckboxGroup>
            {Dict.map.plateColor.map((v) => (
              <Checkbox value={v.code} key={v.code}>
                {v.label}
              </Checkbox>
            ))}
          </CheckboxGroup>
        )}
      </FormItem>
    </FormContent>
  );
};

export default Form.create()(AddDrawer);
