import React, { useState, useRef } from 'react';
import { message } from 'antd';
import { useGetVehicleBranch } from '../../../hooks';
import { getVehicleColor, getVehicleClasses, getVehicleBrand } from '../../../utils';
import AddDrawer from '../addDrawer';
import './index.less';
const { Loader, Dict } = window;
const IconFont = Loader.loadBaseComponent('IconFont');
const Drawer = Loader.loadBaseComponent('Drawer', 'Base');
const Notice = Loader.loadBusinessComponent('Modal', 'Notice');

const AddVehicle = (props) => {
  const { onChange, value } = props;
  const [vehicles, setVehicles] = useState(value); 
  // 是否显示添加弹框
  const [isShow, setIsShow] = useState(false);
  // 车辆删除弹框
  const [delVisible, setDelVisible] = useState(false);
  // 当前选中的车辆，根据索引去选中
  const currentIndex = useRef(null);
  // 车辆品牌相关数据
  const [ vehicleSourceData ] = useGetVehicleBranch();

  function addVehicle() {
    if(vehicles.length>19) return message.warning('布控目标不能超过20个')
    setIsShow(true);
  }
  function closeDrawer(){
    setIsShow(false);
    currentIndex.current = null;
  }
  // 车辆编辑
  function editAction(index) {
    currentIndex.current = index;
    setIsShow(true);
  }

  // 车辆校验成功，添加车辆到当前
  function submitForm(data){
    const { vehicleClasses, ...rest } = data;
    // 车辆类型处理
    let vehicleClassesCodes = [];
    vehicleClasses.forEach(v => {
      let vehicleClassesItem = Dict.map.vehicleClasses.find(k => k.value === v);
      if(vehicleClassesItem) {
        vehicleClassesCodes = vehicleClassesCodes.concat(vehicleClassesItem.ids);
      }
    })
    let vehicelItem = { ...rest, vehicleClasses: vehicleClassesCodes };
    if(currentIndex.current !== null){
      // 编辑
      vehicles[currentIndex.current] = vehicelItem;
    }else{
      // 添加
      vehicles.push(vehicelItem);
    }
    setVehicles(vehicles);
    closeDrawer();
    onChange && onChange(vehicles);
  }

  // 车辆删除
  function deleteAction(index) {
    currentIndex.current = index;
    setDelVisible(true);
  }

  function deleteOK(){
    vehicles.splice(currentIndex.current, 1);
    deleteCancel();
    setVehicles(vehicles);
    onChange && onChange(vehicles);
  }

  function deleteCancel(){
    setDelVisible(false);
    currentIndex.current = null;
  }
  let data = {};
  if(currentIndex.current !== null && vehicles[currentIndex.current]){
    data = vehicles[currentIndex.current];
  }
  return (
    <div className="lm-c-tl-add-vehicle-target-box">
      <div className="vehicel-add">
        <span onClick={addVehicle}>
          <IconFont type="icon-S_Edit_LinePlus" />
          <span style={{ marginLeft: '4px' }}>添加目标车辆</span>
        </span>
      </div>
      <div className="vehicle-box">
        <div className="vehicle-table-title">
          <div>车牌号码</div>
          <div>车牌颜色</div>
          <div>车辆颜色</div>
          <div>车辆类型</div>
          <div>车辆品牌</div>
          <div>操作</div>
        </div>
        <div className="vehicle-table-content">
          {vehicles.map((v, index) => {
            let plateColorLabel = getVehicleColor(v.plateColors, 'plateColor');
            let vehicleColorLabel = getVehicleColor(v.vehicleColors, 'vehicleColor');
            let Classes = getVehicleClasses(v.vehicleClasses);
            let vehicleBranch = getVehicleBrand(vehicleSourceData, v.vehicleBrands);
            return (
              <div className="vehicle-item">
                <div title={v.plateNo}>{v.plateNo}</div>
                <div title={plateColorLabel}>{plateColorLabel}</div>
                <div title={vehicleColorLabel}>{vehicleColorLabel}</div>
                <div title={Classes}>{Classes}</div>
                <div title={vehicleBranch}>{vehicleBranch}</div>
                <div className="vehicle-manage-box">
                  <IconFont type="icon-S_Edit_Edit" title="编辑" onClick={() => editAction(index)} />
                  <IconFont type="icon-S_Edit_Delete" title="删除" onClick={() => deleteAction(index)} style={{ marginLeft: '8px' }} />
                </div>
              </div>
            )
          })}
        </div>
      </div>
      <Drawer destroyOnClose={true} title={data.plateNo ? '编辑目标' : '添加目标'} width={660} visible={isShow} onClose={closeDrawer}>
        <AddDrawer 
          closeDrawer={closeDrawer}
          submitForm={submitForm}
          data={data || {}}
        />
      </Drawer>
      <Notice 
        visible={delVisible} 
        onOk={deleteOK} 
        title={data.plateNo || ''} 
        onCancel={deleteCancel}
      />
    </div>
  );
};

export default AddVehicle;
