import React, { useState } from 'react';
import SelectBtn from '../../../selectBtn';
const { Loader, Utils, BaseStore } = window;
const SelectPointsMap = Loader.loadBusinessComponent('LMap', 'SelectPointsMap');
const SelectDevices = Loader.loadBaseComponent('List', 'SelectDevices');

const VehicleDeviceSelect = props => {
  const { onChange, value={} } = props;
  const { deviceIds=[], isAll=true } = value;
  const [type, setType] = useState(1);
  const [key, setKey] = useState(1);
  // 是否全城布控
  function onCheckChange(e){
    let isChecked = e.target.checked;
    onChange && onChange({
      deviceIds: [],
      isAll: isChecked
    });
    setKey(Math.random());
  }
  // 自定义布控事件
  function deviceSelect(deviceIds){
    onChange && onChange({
      deviceIds,
      isAll: false
    });
  }
  return (
    <div>
      <SelectBtn 
        style={{ marginBottom: '16px' }} 
        type={type} 
        changeType={type => setType(type)} onCheckChange={onCheckChange} 
        isChecked={isAll}
      />
      <div style={{ height: '540px' }}>
        {type === 1 && 
          <SelectPointsMap 
            key={key}
            points={BaseStore.device.cameraList} 
            selectKeys={deviceIds} 
            onChange={deviceSelect} 
          />}
        {type === 2 && (
          <SelectDevices
            key={key}
            selectDevices={deviceIds}
            placeTreeData={Utils.computPlaceTree(BaseStore.place.placeListWithCameraCount)}
            orgTreeData={Utils.computTreeList(BaseStore.organization.orgListWithCameraCount)}
            onChange={deviceSelect}
          />
        )}
      </div>
    </div>
  );
};
export default VehicleDeviceSelect;
