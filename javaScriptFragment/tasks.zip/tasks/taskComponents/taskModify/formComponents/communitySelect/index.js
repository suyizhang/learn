import React, { Component } from 'react';
import { Cascader, Select, message } from 'antd';

const { Service, Utils,BaseStore } = window;
const { Option } = Select;
class CommunitySelect extends Component {
  constructor(props){
    super(props);
    let villageItem = props.value;
    let value =[];
    if(villageItem){
      let placeItem = BaseStore.place.getPlaceInfoById(villageItem.placeId)
      value= placeItem ? BaseStore.place.getIdsForCodes(placeItem.pcodes).slice(0,3) : [];
    }
    this.state = {
      communitySelect: villageItem && (villageItem.id || '-') , // 选中的小区
      communityArray: villageItem && [villageItem],
      value,
    }
  }

  cascaderChange = value => {
    const { onChange } = this.props;
    this.setState({ value, communitySelect: undefined });
    // 调用接口，拿小区列表数据渲染
    Service.community.queryChildByPlaceId({
      id: value[value.length - 1]
    }).then(data => {
      let communityArray = data || [];
      this.setState({ communityArray });
    }).catch(err => {
      message.error('查询小区失败');
    })
    onChange && onChange(undefined);
  }

  // 选择小区
  communityOnChange = communitySelect => {
    const { onChange } = this.props;
    let {communityArray} =this.state
    this.setState({ communitySelect });
    onChange && onChange(communityArray.find(v => v.id === communitySelect));
  }
  
  render() {
    const { communityArray=[], communitySelect ,value} = this.state;
    let options = Utils.computPlaceTree(BaseStore.place.placeList.filter(v => v.level<3))
    const { label } = this.props;
    
    return (
      <div className='lm-task-rule-residence-select'>
        <div className='residence-select-item' >
          {label && <span style={{ lineHeight: '32px', marginRight: '8px' }}>{label}</span>}
          <Cascader
            options={options}
            fieldNames={{ label: 'areaName', value: 'placeId', children: 'children' }}
            placeholder="请选择城市"
            showSearch
            value={value}
            size="small"
            allowClear={false}
            style={{ width: '202px' }}
            onChange={this.cascaderChange}
          />
          <Select 
            style={{ width: '202px', marginLeft: '8px' }} 
            value={communitySelect?communitySelect+'':undefined} 
            placeholder='请选择居住小区'
            onChange={this.communityOnChange}
          >
            {
              communityArray.map(v => (
                <Option key={v.id+'' || '-'}>{v.villageName}</Option>
              ))
            }
          </Select>
        </div>
      </div>
    )
  }
}
export default CommunitySelect;