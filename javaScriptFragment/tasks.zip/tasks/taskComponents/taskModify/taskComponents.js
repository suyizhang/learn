import BaseInfo from './components/baseInfo';
import BaseInfoValidate from './components/baseInfoValidate';
import LibList from './components/libsList';
import TasksScope from './components/tasksScope';
import TasksReceive from './components/tasksReceive';
import IdlehousehasPersonRule from './components/idlehousehasPersonRule'; // 闲置房屋疑似住人
import SuspectedRentalHousingRule from './components/suspectedRentalHousingRule'; // 疑似租赁房
import AstrayPersonTaskRule from './components/astrayPersonTaskRule'; // 失足人员
import OutsidePreConvictionsRule from './components/outsidePreConvictionsRule'; // 外来前科
import PsychoticNotAppearRule from './components/psychoticNotAppearRule'; // 外来前科
import SpeciallyAccompanyRule from './components/speciallyAccompanyRule'; // 特殊人员同行
import XjPersonNotAppearRule from './components/xjPersonNotAppearRule'; // XJ人员长期未出现
import XjPersonGatheredRule from './components/xjPersonGatheredRule'; // 特殊人员聚集
import XjPersonContactedRule from './components/xjPersonContactedRule'; // 特殊人员串联
import NocturnalRule from './components/nocturnalRule'; // 昼伏夜出
import AddictRule from './components/addictRule'; // 吸毒人员
import AbnormalChargeRule from './components/abnormalChargeRule'; // 异常刷卡研判
import YoungNotAppearRule from './components/youngNotAppearRule'; // 青壮年长期未出现研判
// 布控相关组件
import NoticeSet from './components/noticeSet';
import TargetVehicle from './components/targetVehicle';
import VehicleTasksScope from './components/vehicleTasksScope';
// 研判中心任务组件
import RuleConfig from './components/ruleConfig';
// 编辑组件集合
export const componentModule = {
  BaseInfo,
  BaseInfoValidate,
  LibList,
  TasksScope,
  TasksReceive,
  IdlehousehasPersonRule,
  SuspectedRentalHousingRule,
  AstrayPersonTaskRule,
  OutsidePreConvictionsRule,
  PsychoticNotAppearRule,
  SpeciallyAccompanyRule,
  XjPersonNotAppearRule,
  XjPersonGatheredRule,
  XjPersonContactedRule,
  NocturnalRule,
  AddictRule,
  AbnormalChargeRule,
  YoungNotAppearRule,
  NoticeSet,
  TargetVehicle,
  VehicleTasksScope,
  RuleConfig
}
// 默认渲染组件
export const defaultComponents = ['BaseInfo', 'AstrayPersonTaskRule', 'TasksReceive'];