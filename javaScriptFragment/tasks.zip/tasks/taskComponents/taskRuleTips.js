import React from 'react';
import { Tooltip } from 'antd';
const { Loader } = window;
const IconFont = Loader.loadBaseComponent('IconFont');

// 失足人员
export const astrayPersonRuleTips = ({ isEdit = true, censusRegisterLabels, ageRangeStrat, ageRangeEnd, villageName }) => (
  <div className="rule-tip">
    {isEdit && '( '}
    <span className="highlight">{censusRegisterLabels}</span>
    户籍，租住在
    <span className="highlight"> {villageName || ''} </span>的<span className="highlight"> {ageRangeStrat} </span>
    岁至
    <span className="highlight"> {ageRangeEnd} </span>
    岁的女性，连续7天，
    <span className="highlight">每天 7:00 至 21:00</span>
    ，在小区抓拍次数
    <span className="highlight"> 每天均 </span>
    小于
    <span className="highlight"> 2 </span>次{isEdit && ' )'}
  </div>
);

// 外来前科
export const outsidePreConvictionsRuleTips = ({ isEdit = true, villageName, personTagLabels }) => (
  <div className="rule-tip">
    {isEdit && '( '}
    不住在
    <span className="highlight"> {villageName} </span>的<span className="highlight"> {personTagLabels} </span>
    人员，在
    <span className="highlight"> {villageName} </span>
    出现
    {isEdit && ' )'}
  </div>
);

// 特殊人员同行
export const accompanyRuleTips = ({ hours, personTagLabels, appearCount, villageName, isEdit = true }) => (
  <div className="rule-tip">
    {isEdit && '( '}
    <span className="highlight">{hours} </span>
    小时内，居住在
    <span className="highlight"> {villageName || ''} </span>的<span className="highlight"> {personTagLabels} </span>
    人员，与不居住在
    <span className="highlight"> {villageName || ''} </span>的<span className="highlight"> {'同类标签人员'} </span>
    同出现次数大于
    <span className="highlight"> {appearCount} </span>次{isEdit && ' )'}
  </div>
);

// 精神病长期未出现、XJ人员长期未出现、吸毒人员多日未出现、青壮年长期未出现
export const notAppearRuleTips = ({ days, tagLabel, villageName, isEdit = true }) => (
  <div className="rule-tip">
    {isEdit && '( '}
    <span className="highlight"> {villageName || ''} </span>的<span className="highlight"> {tagLabel} </span>，<span className="highlight"> {days} </span>
    天内，在
    <span className="highlight"> {villageName || ''} </span>
    抓拍次数为
    <span className="highlight"> 0 </span>次{isEdit && ' )'}
  </div>
);

// 闲置房屋疑似住人研判
export const idlehousehasPersonRuleTips = ({ villageName, days, captureCount, label, accessCardCount, isEdit = true }) => {
  
  return <div className="rule-tip">
    {isEdit && '( '}
    <span className="highlight"> {days} </span>天内，
    <span className="highlight"> {villageName } </span>
    闲置房业主及其家属，在小区出现次数累计大于
    <span className="highlight"> {captureCount } </span>
    次，
    <span className="highlight"> {label} </span>
    名下门禁卡刷卡次数累计大于
    <span className="highlight"> {accessCardCount } </span>次{isEdit && ' )'}
  </div>
};

// 疑似租赁房研判
export const suspectedRentalHousingRuleTips = ({ villageName, days, captureCount, label, accessCardCount, isEdit = true }) => (
  <div className="rule-tip">
    {isEdit && '( '}
    <span className="highlight"> {days } </span>天内，
    <span className="highlight"> {villageName } </span>
    自住房业主及其家属，在小区出现次数累计小于
    <span className="highlight"> {captureCount } </span>
    次，
    <span className="highlight"> {label} </span>
    名下门禁卡刷卡次数累计大于
    <span className="highlight"> {accessCardCount} </span>次{isEdit && ' )'}
  </div>
);

// 异常刷卡研判
export const abnormalChargeRuleTips = ({ villageName, days, label, accessCardCount, isEdit = true }) => (
  <div className="rule-tip">
    {isEdit && '( '}
    <span className="highlight"> {villageName} </span>
    的某单张门禁卡
    <span className="highlight"> {days } </span>
    天内，刷卡次数
    <span className="highlight"> {label} </span>
    大于
    <span className="highlight"> {accessCardCount } </span>次{isEdit && ' )'}
  </div>
);

// 人员昼伏夜出
export const nocturnal = ({ villageName, isEdit = true }) => (
  <div className="rule-tip">
    {isEdit && '( '}
    居住在<span className="highlight"> {villageName || ''} </span>，出行规律符合昼伏夜出
    <Tooltip placement="right" title='(最近30天为周期，7天内「可配置」至少3天「可配置」，在晚上11点到早上5点之间在抓拍次数和早上5点到晚上11点抓拍次数比大于4:1'>
      <IconFont style={{ marginLeft: '4px', color: 'var(--icon)' }} type="icon-L_Bar_Label" />
    </Tooltip>
    {isEdit && ' )'}
  </div>
);

// xj人员聚集
export const xjPersonGatheredRuleTips = ({ villageName, triggerDuration, personCount, isEdit = true }) => (
  <div className="rule-tip">
    {isEdit && '( '}
    <span className="highlight"> {triggerDuration} </span>
    小时内，居住在
    <span className="highlight"> {villageName || ''} </span>的<span className="highlight"> XJ人员 </span>
    ，超过
    <span className="highlight"> {personCount} </span>
    人及以上出现在同一场所
    {isEdit && ' )'}
  </div>
)