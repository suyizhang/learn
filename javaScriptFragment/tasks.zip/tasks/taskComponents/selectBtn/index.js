import React from 'react';
import './index.less';
const { Loader } = window;
const IconFont = Loader.loadBaseComponent('IconFont');
const Button = Loader.loadBaseComponent("Form", "Button");
const Checkbox = Loader.loadBaseComponent('Form', 'Checkbox');

const SelectBtn = ({type, changeType, onCheckChange, isChecked,  ...rest}) => {
  return (
    <div className="lm-tl-task-device-select-btn" {...rest} >
      <Button type={type === 1 && 'primary'} onClick={() => changeType(1)}>
        <IconFont type="icon-S_Photo_Map" />地图模式
      </Button>
      <Button style={{ marginLeft: '8px' }} type={type === 2 && 'primary'} onClick={() => changeType(2)}>
        <IconFont type="icon-S_Photo_ListTree"/>列表模式
      </Button>
      {onCheckChange && <Checkbox checked={isChecked} onChange={onCheckChange} style={{ marginLeft: '20px' }}>全城布控</Checkbox>}
    </div>
  )
}
export default SelectBtn