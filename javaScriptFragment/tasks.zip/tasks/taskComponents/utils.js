/**
 * @desc 用于研判任务接口数据兼容
 * @param {研判任务状态} status 
 */
export const handleAssessmentTaskStatus = status => {
  const statusObj = {
    paused: 0,
    running: 1,
    notStarted: 2,
    expired: 3,
    deleted: 4
  };
  return statusObj[status];
}

/**
 * 
 * @param {详情数据里面的小区数据} village 
 * @param {from方法} getFieldsValue 
 */
export const getVillageName = (village, getFieldsValue) => {
  const formValue = getFieldsValue() || {};
  // 优先级： form里面的小区名称 > itemData里的小区名称
  let villageName;
  if(village){
    villageName = village.villageName;
  }
  if(formValue.village){
    villageName = formValue.village.villageName;
  }
  return villageName;
}

/**
 * @param {标签code数组} tags 
 * @param {标签全量数据} tagData 
 * @param {分割的方式} sep 
 */
export const getTagLabel = (tags, tagData, sep = '、') => {
  let tagLabels = tags.map(v => {
    let item = tagData.find(k => k.code === v) || {};
    return item.name;
  })
  return tagLabels.join(sep);
}


/**
 * 获取车辆颜色
 */
export const getVehicleColor = (codes = [], type) => {
  const { Dict } = window;
  let labelArray = [];
  codes.forEach((v) => {
    let item = Dict.map[type].find((k) => k.code === v);
    if (item) {
      labelArray.push(item.label);
    }
  });
  return [...new Set(labelArray)].join('、');
}

/**
 * 车辆类型label
 */

export const getVehicleClasses = (codes = []) => {
  const { Dict } = window;
  let labelArray = [];
  codes.forEach((v) => {
    let item = Dict.map.vehicleClasses.find((k) => k.ids.indexOf(+v) > -1);
    if (item) {
      labelArray.push(item.label);
    }
  });
  return [...new Set(labelArray)].join('、');
}

/**
 * 车辆品牌
 */
export const getVehicleBrand = (sourceData, codes = []) => {
  const { vehicleYear=[] } = window.Dict.map;
  const [lv1, lv2, lv3] = codes;
  let labelArray = [];
  let lv1Item = sourceData.find(v => v.code === lv1);
  if(lv1Item){
    labelArray.push(lv1Item.name);
    if(lv2){
      let lv2Item = lv1Item.childDictionary.find(k => k.code === lv2);
      lv2Item && labelArray.push(lv2Item.name);
    }
  }
  if(lv3){
    let lv3Item = vehicleYear.find(k => k.code === lv3);
    lv3Item && labelArray.push(lv3Item.name);
  }
  return labelArray.join('/');
}