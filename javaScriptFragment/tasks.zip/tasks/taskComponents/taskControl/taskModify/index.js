import React, { Component } from 'react';
import moment from 'moment';
import { message } from 'antd';
import './index.less';

const { Loader } = window;
const CustomForm = Loader.loadBusinessComponent('CustomForm');
const Progress = Loader.loadBaseComponent('Progress');

// tips:
// 布控任务相关form字段应该以当前组件的字段为主，
// 使用该布控组件的布控任务字段要转换为当前组件需要的字段
// 否则copy一份代码自己实现

class TaskModify extends Component {
  constructor(props) {
    super(props);
    let itemData = this.handleData(props.data); // 数据统一处理
    this.state = {
      httpStatus: 'over', // 模拟数据请求
      itemData, // 当前编辑的布控任务
    };
    this.isSubmiting = false;
  }

  // 数据进入编辑添加组件时的差异化处理
  handleData = (data) => {
    const { initTaskParams = {}, factory } = this.props.taskProps;
    // 数据处理
    let options = {
      validTime: moment(), // 开始时间
      invalidTime: moment().add('days', 3), // 结束时间
    };
    if (!data.id) {
      // 新增任务处理
      return { ...options, ...initTaskParams };
    }
    // 编辑任务抛到相关配置自行处理
    return factory.prevHandleData(data);
  };

  // 添加编辑成功后的处理
  handleSave = (err, values) => {
    const { onClose } = this.props;
    if (this.isSubmiting) {
      return; // 正在提交时不能再次提交
    }
    if (err) {
      console.log(err);
      message.error('表单验证失败');
      return;
    }
    this.setState({ httpStatus: 'loading' });
    this.isSubmiting = true; // 开始提交
    if (!values.tasksScope) {
      // values.tasksScope = {
      //   [],
      //   isAll: deviceIds.length === 0 ? true : false
      // }
    }
    this.submitService(values)
      .then((res) => {
        if (res.code === 0) {
          message.success(res.message);
          this.isSubmiting = false; // 提交完成
          onClose && onClose(true);
          this.setState({ httpStatus: 'over' });
        } else {
          this.setState({ httpStatus: 'error' });
          this.isSubmiting = false; // 提交失败
          message.error(res.message);
        }
      })
      .catch((err) => {
        this.setState({ httpStatus: 'error' });
        this.isSubmiting = false; // 提交失败
        message.error(err.message);
      });
  };

  // 提交代码的差异处理
  submitService = (values) => {
    const { data, taskProps } = this.props;
    const { taskTypeCode, factory } = taskProps;
    return factory.addOrEditAction({ id: data.id, type: taskTypeCode, ...values }, taskProps, true);
  };

  render() {
    const { httpStatus, itemData } = this.state;
    const { onClose, formData } = this.props;
    const { deviceIds = [] } = itemData;
    itemData.tasksScope = {
      deviceIds: deviceIds,
      isAll: deviceIds.length === 0 ? true : false,
    };
    itemData.validTime = [itemData.validTime, itemData.invalidTime];
    return (
      <>
        <Progress status={httpStatus} />
        <CustomForm type="form" formData={formData} defaultData={itemData} onOk={this.handleSave} onCancel={() => onClose(false)} />
      </>
    );
  }
}
export default TaskModify;
