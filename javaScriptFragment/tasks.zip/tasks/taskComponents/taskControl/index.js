/**
 * @desc 拷贝任务入口 使用自定义表单 
 * @tips 任务相关的配置都在tasksConfig.js文件下，传入type后取出任务配置，往下一层层传递
 *       因为接口不同导致的字段的兼容性问题，统一在factoryConfig文件下修改处理
 */
import React from 'react';
import TaskHelper from './taskHelper'; // 布控任务抽离的公共方法
import taskList from '../taskList'; // 布控任务列表
import TaskDetail from '../taskDetail'; // 布控任务详情
import TaskModify from './taskModify'; // 布控任务添加编辑
import tasksConfig from '../tasksConfig'; // 布控任务类型相关参数配置

const { Loader } = window;
const TwoColumnLayout = Loader.loadBaseComponent('Layout', 'TwoColumnLayout');
const PaddingBox = Loader.loadBaseComponent('Box', 'PaddingBox');
const Progress = Loader.loadBaseComponent('Progress');
const Drawer = Loader.loadBaseComponent('Drawer', 'Base');
const InfoBox = Loader.loadBaseComponent('Box', 'InfoBox');
const Notice = Loader.loadBusinessComponent('Modal', 'Notice');
// 初始列表的搜索条件 -- 按智能研判设置初始化参数，后期需要更改就通过tasksConfig去覆盖
const initSearchData = {
  source: 'all', // 任务来源
  limit: 500,
  offset: 0
};

class TaskControl extends TaskHelper {
  constructor(props) {
    super(props);
    this.taskProps = tasksConfig[props.type] || {}; // 通过类型取出对应的任务相关参数
    const { searchData = {} } = this.taskProps;
    const searchDataHandle = { ...initSearchData, ...searchData };
    this.state = {
      httpStatus: 'over',
      tasksList: [], // 布控库列表数据
      activeItem: {}, // 当前选中的布控任务
      taskViewKey: Math.random(), // 刷新详情界面使用
      taskDrawerIsShow: false, // 新增编辑布控任务抽屉
      taskEdit: {}, // 当前编辑的布控任务
      isShowDelModal: false, // 布控任务删除
      searchData: searchDataHandle // 布控任务列表搜索条件
    };
  }

  /**
   * @desc 布控任务列表接口调用
   */
  queryTasksListService = searchData => {
    const { factory } = this.taskProps;
    return factory.queryListAction(searchData);
  };

  /**
   * @desc 任务详情接口调用
   */
  queryTaskDetailService = item => {
    const { factory } = this.taskProps;
    return factory.queryDetailAction(item);
  };

  /**
   * @desc 布控任务删除接口调用
   */
  deleteTaskService = () => {
    const { factory } = this.taskProps;
    return factory.deleteAction(this.delItem, this.taskProps);
  };

  /**
   * @desc 开始暂停布控任务接口调用
   */
  onStartPauseService = item => {
    const { factory } = this.taskProps;
    return factory.updateStatusAction(item, this.taskProps);
  };

  render() {
    const { 
      httpStatus, tasksList, activeItem, searchData, 
      taskViewKey, taskDrawerIsShow, taskEdit, isShowDelModal,formData
    } = this.state;
    const { taskListType='BaseList' } = this.taskProps;
    const TaskList = taskList[taskListType] || null;
    return (
      <TwoColumnLayout
        leftContent={
          TaskList && <TaskList
            data={tasksList}
            activeItem={activeItem}
            changeSearchData={this.changeSearchData}
            keywords={searchData.name}
            searchData={searchData}
            queryMonitorTaskDetail={this.queryMonitorTaskDetail}
            showDrawerChange={this.showDrawerChange}
            privName={this.taskProps.privName}
            delTasksModal={this.delTasksModal} // 删除
            taskProps={this.taskProps}
            onStartPauseBtnClick={this.onStartPauseBtnClick} // 开启和暂停
          />
        }
      >
        <Progress status={httpStatus} />
        <div style={{ height: '100%', overflow: 'auto' }}>
          <InfoBox grid={'rightScreen'}>
            <PaddingBox style={{ overfloat: 'auto', height: 'auto' }}>
              { activeItem.id && 
                <TaskDetail 
                data={activeItem} 
                key={taskViewKey} 
                showDrawerChange={this.showDrawerChange} 
                taskProps={this.taskProps} 
              />}
            </PaddingBox>
          </InfoBox>
        </div>
        <Notice 
          visible={isShowDelModal} 
          onOk={this.deleteTask} 
          title={this.delTaskName} 
          onCancel={this.deleteCancel} 
          desc="删除后该任务将不可编辑和产生告警" 
        />
        <Drawer
          destroyOnClose={true}
          width={1040}
          title={`${taskEdit.id ? '编辑' : '新建'}${this.taskProps.taskTypeLabel}任务`}
          visible={taskDrawerIsShow}
          onClose={() => this.showDrawerChange(false)}
        >
          <TaskModify 
            onClose={isInitData => this.showDrawerChange(false, {}, isInitData)} 
            data={taskEdit || null }
            formData = {formData}
            taskProps={this.taskProps} 
          />
        </Drawer>
      </TwoColumnLayout>
    );
  }
}
export default TaskControl;
