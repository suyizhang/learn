import React from 'react';
import { message } from 'antd';
const {Service } = window;
class TaskHelper extends React.Component {
  
  componentDidMount() {
    // 查询taskLis
    const { searchData } = this.state;
    this.queryTasksList(searchData);
    this.formList()
  }

  /**
   * @func 布控任务列表请求成功后的统一处理
   * @desc isInitDetail和activeItem同时存在的原因：
   * 编辑时（刷新列表同时拿当前详情），
   * 新增时（刷新列表，调用详情接口）,
   * 删除时（刷新列表，删除当前时，要调用详情，否则不调用）
   */
  queryTasksList = (searchData, isInitDetail = true, activeItem = {}) => {
    // 这里可以用来抽离，作为请求列表后的公共处理方法
    this.queryTasksListService(searchData).then(list => {
        if (isInitDetail && list.length > 0) {
          this.queryMonitorTaskDetail(activeItem.id ? activeItem : list[0]);
        }
        let stateOptions = { tasksList: list };
        if (list.length === 0) {
          stateOptions.activeItem = {}; // 不存在布控库时重置详情（布控删除）
        }
        this.setState(stateOptions);
    }).catch(err => {
      this.setState({ httpStatus: 'error' });
      message.error('布控任务列表查询失败');
    });
  };

  /**
   * @desc 布控任务详情公共逻辑处理
   */
  queryMonitorTaskDetail = item => {
    this.setState({ httpStatus: 'loading' });
    this.queryTaskDetailService(item).then(activeItem => {
      this.setState({ activeItem, httpStatus: 'over', taskViewKey: Math.random() });
    }).catch(err => {
      console.log('error: ', err)
      this.setState({ httpStatus: 'error' });
      message.error('布控任务详情查询失败');
    });
  }

  /**
   * @desc 布控任务搜索
   */
  changeSearchData = options => {
    let searchData = { ...this.state.searchData, ...options };
    this.setState({ searchData });
    this.queryTasksList(searchData);
  };

  // 显示或隐藏布控任务抽屉
  showDrawerChange = (flag = true, item = {}, isInitData) => {
    let taskEdit = this.state.taskEdit;
    if (flag !== this.state.taskDrawerIsShow) {
      this.setState({ taskDrawerIsShow: flag, taskEdit: item });
    }
    if (isInitData) {
      this.queryTasksList(this.state.searchData, true, taskEdit); // 初始化列表数据
    }
  };

  /**
   * @desc 删除布控任务弹框
	 * @param {objectt} delItem 布控任务
	 * @param {boolean} isActive 是否删除的是当前选中的布控任务
	 * @param {string} delTaskName 布控名称
   */
  delTasksModal = (e, item) => {
    e.stopPropagation();
    const { activeItem } = this.state;
    this.delTaskName = item.name;
    this.isActive = item.id === activeItem.id;// 是否删除的为当前选中的任务
		this.delItem = item;
		this.setState({ isShowDelModal: true });
  }

  /**
   * @desc 布控任务删除确认
   */
  deleteTask = () => {
    const { searchData } = this.state;
    this.deleteTaskService().then(res => {
      message.success('任务删除成功')
      this.setState({
        isShowDelModal: false
      })
      // 更新列表 判断是否改变选中的布控任务
      this.queryTasksList(searchData, this.isActive);
    }).catch(err => {
			message.error('任务删除失败')
		})
  }

  /**
   * @desc 取消删除
   */
  deleteCancel = () => {
		this.setState({
			isShowDelModal: false
		}, () => {
      this.delTaskName = null;
      this.isActive = null;
      this.delItem = null;
    })
  }

  /**
   * @desc 布控任务开始暂停
   */
  onStartPauseBtnClick = (e, item) => {
    e.stopPropagation();
    if (Date.now() > item.endTime) {
			return message.info('请修改有效时间')
    }
    const { searchData } = this.state;
    this.onStartPauseService(item).then(res => {
      this.queryTasksList(searchData, false) // 重新刷新列表, 不改变选中的布控任务
      message.success('任务操作成功');
    }).catch(err => {
      message.error('任务操作失败');
    })
  }
  /**
   * @desc 表单请求接口
   */
  formList = () => {
    Service.formManage
      .queryPage({ formType: 1, offset: 1, limit: 100 })
      .then((res) => {
        if (res.data && res.data.list.length > 0) {
          let formData = res.data.list.find((v => v.senceName === 'saveDeployControl'))
          formData = formData.formContent;
          this.setState({formData})
        }
      })
      .catch((err) => {
       message.error('表单模板请求失败');
      });
  };
  render(){
    return null;
  }
}
export default TaskHelper;