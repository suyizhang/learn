import React from 'react';
import Task from '../../taskComponents';
import AlarmHistory from '../components/personAlarm';
const { Loader, BaseStore, Decorator } = window;
const StaticRoute = Loader.loadBusinessComponent('AppRoute', 'StaticRoute');
const AlarmWithLog = Decorator.withEntryLog({moduleName: 'idlehousehasPersonHistory'})(AlarmHistory);
const TaskWithLog = Decorator.withEntryLog({moduleName: 'idlehousehasPersonTask'})(Task);

//闲置房屋疑似住人研判
class IdlehousehasPerson extends React.Component {
  constructor(props){
    super(props);
    this.tabList = [
      {
        title: '历史预警信息',
        icon: 'icon-S_Bar_Alarm',
        name: 'idlehousehasPersonHistory',
        content: <AlarmWithLog
        taskType='101551'
        cardHeight={232}
        taskApi={'queryTasks'}
        countApi={'countTaskWarnings'}
        listApi={'houseQueryWarnings'}
        detailModuleName={'personRecord'}
        />
      },
      {
        title: '研判任务管理',
        icon: 'icon-S_View_Task',
        name: 'idlehousehasPersonTask',
        content: <TaskWithLog
          type='idlehousehasPerson'
        />
      }
    ] 
    this.tabList = this.tabList.filter(v => !!BaseStore.menu.getInfoByName(v.name))
    this.state = {
      activeKey: this.tabList[0].name
    }
  }

  componentDidMount() {
    const { history, match, location } = this.props;
    let lastName = location.pathname.split('/').pop();
    if (!this.tabList.find(v => v.name === lastName)) {
      location.pathname = `${match.url}/${this.tabList[0].name}`;
      location.state = Object.assign({}, location.state);
      history.replace(location);
    }
  }
  render(){
    const { activeKey } = this.state;
    const { match, ...rest } = this.props;
    return <StaticRoute {...rest} defaultKey={activeKey} path={`${match.url}/:module`} match={match} onTabChange={this.onTabChange} tabList={this.tabList} isRightHead={true} />;
  }
}
export default IdlehousehasPerson;