import React from 'react';
import AlarmList from '../components/detail/alarmList';
import {_goPage} from '../components/detail/utils' //_jumpPersonnelDetail, 
import './index.less';

const { Loader, Service, Utils, LM_DB, Dict } = window;

const LabelValue = Loader.loadBaseComponent('LabelValue');
const IconFont = Loader.loadBaseComponent('IconFont');
const InfoBox = Loader.loadBaseComponent('Box', 'InfoBox');
const PaddingBox = Loader.loadBaseComponent('Box', 'PaddingBox');
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const Button = Loader.loadBaseComponent('Form', 'Button');
const AbnormalGroupTrajectory = Loader.loadBusinessComponent('LMap', 'AbnormalGroupTrajectory');

const { personnelAttr, identity } = Dict.map;

export const tagList = [...personnelAttr, ...identity];

class OutflowofDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      httpStatus: 'loading',
      baseData: {},
      list: [],
      trackList: [],
      type: 'map',
      dataList: [], // 人员列表
      leaveCount: 0
    };
  }

  async componentDidMount() {
    let { location } = this.props;
    const id = location.pathname.split('/').reverse()[0];
    try {
      let { data } = await LM_DB.get({ id });
      const option = { id: data.id };
      let result = await Service.intelligentJudgement.xJGather(option);
      const option2 = {
        aids: data.aids,
        placeId: result.data.placeId
      };
      let res = await Service.subscription.countLeaveAbnormalPopulationPersons(option2);
      this.setState({ baseData: result.data, leaveCount: res.data.count }, () => {
        this.getTrackList(result.data);
        this.queryActivityTrackList(result.data);
      });
    } catch (error) {
      console.log(error);
      this.setState({ httpStatus: 'error' });
    }
  }

  // 查询轨迹
  getTrackList = async (data = {}) => {
    const { aids, alarmTime } = data;
    let result = await Service.subscription.queryAbnormalPopulationActivityTrack({
      aids,
      alarmTime
    });
    let tempList = result.data || [];
    tempList.forEach(item => {
      item.trails = item.trails.filter(v => v.latitude && v.longitude && (v.latitude !== 'null') && (v.longitude !== 'null'))
    })
    this.setState({ trackList: tempList, httpStatus: 'over' });
  };

  // 查询列表
  queryActivityTrackList = async detailInfo => {
    const result = await Service.subscription.queryActivityTrackList({
      eventType: '101558',
      captureIds: detailInfo.captureIds
    });
    const dataList = result.data || [];
    this.setState({ dataList, httpStatus: 'over' });
  };

  // 跳转抓拍详情
  handlePageJump = async item => {
    const id = item.id;
    await LM_DB.put({ id, data: this.state.dataList });
    _goPage.call(this, { id, moduleName: 'subscriptionCaptureDetail' });
  };
  render() {
    const { baseData, type, trackList = [], httpStatus, dataList, leaveCount } = this.state;
    const { aggregateNumber, personTags = [], alarmTime, durationString, placeName, context='' } = baseData;
    const xjPersonGatheredRules = context ? JSON.parse(context) : {};
    // 人员标签处理
    const tagInfo = tagList.find(v => v.value === personTags[0]) || {};
    const isMapStyle = type === 'map';
    return (
      <InfoBox grid={'rightScreen'} className="xjPerson-gathered-detail">
        <PaddingBox className="detail-box">
          <BoxDesc title="异常活动信息" className="info-detail">
            <LabelValue label="聚集地点" value={placeName} />
            <LabelValue
              label="聚集人员数量"
              value={
                aggregateNumber ? (
                  <span>
                    <span style={{ color: 'var(--primary)' }}>{aggregateNumber}</span>人
                  </span>
                ) : (
                  undefined
                )
              }
            />
            <LabelValue label="已离开" value={leaveCount ? `${leaveCount}人` : ''} />
            <LabelValue label="告警时间" value={Utils.formatTimeStamp(alarmTime, 'YYYY-MM-DD HH:mm:ss')} />
            <LabelValue label="持续时间" value={durationString} />
            <LabelValue label="聚集人员来源" value={xjPersonGatheredRules.villageName||''} />
            <LabelValue label="聚集人员标签" value={tagInfo.label ? <span className="tags-box">{tagInfo.label}</span> : null} />
          </BoxDesc>
          <BoxDesc title="xj人员轨迹及详情" className="trajectory-detail">
            <div className="type-change-btn-box">
              <Button type={isMapStyle ? 'primary' : 'default'} onClick={() => this.setState({ type: 'map' })}>
                <IconFont type="icon-S_Photo_ListMap" />
                地图模式
              </Button>
              <Button type={!isMapStyle ? 'primary' : 'default'} onClick={() => this.setState({ type: 'list' })}>
                <IconFont type="icon-S_Photo_ListTree" />
                列表模式
              </Button>
            </div>
            <div className="trajectory-container">
              {type === 'list' && (
                <AlarmList
                  cardType="CaptureCard"
                  list={dataList}
                  total={dataList.length}
                  httpStatus={httpStatus}
                  itemHeight={300}
                  isLoadMore={false}
                  taskType="101558"
                  handlePageJump={this.handlePageJump}
                />
              )}
              {type === 'map' && <AbnormalGroupTrajectory list={trackList} placeId={baseData.placeId} />}
            </div>
          </BoxDesc>
        </PaddingBox>
      </InfoBox>
    );
  }
}

export default OutflowofDetail;
