import React from 'react';
import './index.less'
const { Loader, Dict } = window

const ImageView = Loader.loadBaseComponent('ImageView');
const LabelValue = Loader.loadBaseComponent('LabelValue');
const IconFont = Loader.loadBaseComponent('IconFont');

const nationDict = Dict.map.nation;
const sexDict = Dict.map.sex;
const generationDict = Dict.map.generation;
const dictLabel = [
  ...Dict.map.personnelAttr,
  ...Dict.map.gait,
  ...Dict.map.height,
  ...Dict.map.fatAndThin,
  ...Dict.map.identity,
  ...Dict.map.stabilizers,
  ...Dict.map.aidBehavior,
  ...Dict.map.behaviorAttr,
  ...Dict.map.aidBehaviorCode,
  ...Dict.map.appearPlace,
  ...Dict.map.faceMask
];

export default ({ baseData,  ownerInfo }) => {
  let { aid, personTags = [], identityNumber,phoneNumber, ageGroup, nation, gender,name ,representativePhotoUrl} = ownerInfo;
  let {accessCardNo} = baseData
  const nationItem = nationDict.find(v => v.value === nation) || {};
  const genderItem = sexDict.find(v => v.value === gender) || {};
  const ageGroupItem = generationDict.find(v => v.value === ageGroup) || {};
  return (
    <div className='abnormalChargeDetail-left-card'>
      <div className="access-card-no">
        卡号：<span className='highlight'>{accessCardNo}</span>
      </div>
      <div className="left-img">
        <ImageView src={representativePhotoUrl} />
      </div>
      <div className="left-tags">
        {personTags.length > 0 &&
          personTags.map(item => {
            console.log(item);
            
            let tag = {};
            if (dictLabel.length > 0) {
              tag = dictLabel.find(v => v.value === item);
            }
            let timeSpace = ['119051', '118703', '118702'];
            if (item - 120700 > 0 && item - 120700 < 21) {
              timeSpace.push(item);
            }
            console.log(tag);
            
            return tag? (
              <div className="label-info">
                {timeSpace.includes(tag.value) ? (
                  <div className="label label-palce label-chose">
                    <span className="label-palce-icon">
                      <IconFont type={'icon-S_Bar_Eye'} theme="outlined" />{' '}
                    </span>
                    {tag.label}
                  </div>
                ) : (
                    tag.label
                  )}
              </div>
            ):''
          })}
      </div>
      <div className="left-baseInfo">
        <LabelValue label="姓名" value={name} valueColor={'var(--primary)'} />
        <LabelValue label="虚拟身份" value={aid} />
        <LabelValue label="身份证号" value={identityNumber} />
        <LabelValue label="民族" value={nationItem.label} />
        <LabelValue label="性别" value={genderItem.label} />
        <LabelValue label="手机号码" value={phoneNumber} />
        <LabelValue label="年龄段" value={ageGroupItem.label} />
      </div>
    </div>
  );
};
