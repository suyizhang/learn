import React from 'react';
import _ from 'lodash';
import './index.less';
import {abnormalChargeRuleTips} from  '../../../../taskComponents/taskRuleTips';
const { Loader, Service,Utils } = window;

const Progress = Loader.loadBaseComponent('Progress');
const InfoBox = Loader.loadBaseComponent('Box', 'InfoBox');
const ListBox = Loader.loadBaseComponent('Box', 'ListBox');
const InfiniteScrollLayout = Loader.loadBaseComponent('List', 'InfiniteScrollLayout');
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const Pagination = Loader.loadBaseComponent('Form', 'Pagination');
const AccessControlRecordCard = Loader.loadBaseComponent('Card', 'AccessControlRecordCard');

const statisticalModeArray = [
  { value: 0, label: '累计' },
  { value: 1, label: '平均' },
];
class RecordView extends React.Component {
  constructor(props) {
    super(props);
    this.listRef = React.createRef();
    this.state = {
      httpStatus: 'over',
      ownerInfo:{},
      list: [],
      total: 0,
      searchData: {
        startTime: undefined,
        endTime: undefined,
        accessCardNos: -1,
        offset: 0,
        limit: 20,
      },
    };
  }


  static getDerivedStateFromProps(props, state) {
    if (props.data && !Utils.isEqual(state.ownerInfo, props.ownerInfo)) {
      return {isChangeData:true,ownerInfo: _.cloneDeep(props.ownerInfo) };
    }
    return null;
  }
  componentDidUpdate() {
    if (this.state.isChangeData) {
      this.getList(this.state.searchData)
      this.setState({ isChangeData: false });
    }
  }
  getList = async (param) => {
    let {data} = this.props
    let {accessCardNo} = data
    let option = _.cloneDeep(param);

    option.accessCardNos = [accessCardNo];
    this.setState({
      httpStatus: 'loading',
    })
    let res = await Service.intelligentJudgement.queryRecords(option);
    this.setState({
      httpStatus: 'over',
      list: res.data && res.data.list,
      total: res.data && res.data.total,
    });
  };

  /**
   * 更新参数
   * @param {*} options
   */
  mergeSearchData(options) {
    const searchDataNew = Object.assign({}, this.state.searchData, options);
    this.setState({ searchData: searchDataNew });
    return searchDataNew;
  }

  /**
   * 筛选条件更改
   */
  searchDataChange = (options) => {
    const param = this.mergeSearchData({ ...options, offset: 0 });
    this.getList(param);
  };
  pageChange = (page) => {
    let {searchData} = this.state
    const param = this.mergeSearchData({ offset: (page - 1)*searchData.limit });
    this.getList(param);
  };
  onShowSizeChange = (current, size) => {
    this.searchDataChange({ limit: size });
  };
  render() {
    let { httpStatus, searchData, list, total } = this.state;
    let { data } = this.props;
    let { villageName, taskRule = {} } = data;
    let { accessCardCount, days, statisticalMode } = taskRule;
    let itemObj = statisticalModeArray.find((v) => v.value === statisticalMode) || {};
    
    return (
      <div className="judgement-record-view">
        <Progress status={httpStatus} />
        <div className='judgement-record-abnormalChargeDetail-view-content' >
          <InfoBox grid={'listScreen'}>
            <BoxDesc title="任务规则" className="judgement-record-tasks-detail-info">
              {abnormalChargeRuleTips({isEdit:false,days,villageName,label:itemObj.label,accessCardCount})}
            </BoxDesc>

            <ListBox className="judgement-record-list-content">
              <InfiniteScrollLayout
                gutter={10}
                ref={this.listRef}
                itemGrid={{ xxl: 4, xl: 6, lg: 8, md: 12, sm: 24, xs: 24 }}
                hasBackTop={true}
                data={list}
                itemHeight={173}
                renderItem={(item) => {
                  return <AccessControlRecordCard imgUrl={item.recordUrl} deviceName={item.deviceName} captureTime={item.recordTime} />;
                }}
              />
            </ListBox>
            <div className="lm-c-custom-table-pagination">
              {
                <Pagination
                  total={total}
                  showTotal={(total) => `共 ${total} 条记录`}
                  showSizeChanger={true}
                  pageSizeOptions={['10', '20', '50', '100', '200']}
                  onChange={this.pageChange}
                  onShowSizeChange={this.onShowSizeChange}
                  pageSize={searchData.limit}
                  defaultCurrent={1}
                  current={(searchData.offset/searchData.limit) + 1}
                  showQuickJumper={true}
                ></Pagination>
              }
            </div>
          </InfoBox>
        </div>
      </div>
    );
  }
}
export default RecordView;
