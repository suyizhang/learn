import React from 'react';
import LeftCard from './components/LeftCard';
import RecordView from './components/recordView';
const { Loader ,LM_DB,Service} = window;
const TwoColumnLayout = Loader.loadBaseComponent('Layout', 'TwoColumnLayout');

class AbnormalChargeDetail extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      data:{},
      ownerInfo:{},
    };
  }
  async componentDidMount() {
    const { match } = this.props;
    let { data } = await LM_DB.get({ id:match.url.split('/').pop() });
    this.setState({data})
    await this.getOwnerInfo(data)
  }
  getOwnerInfo  = async data => {
    try {
      let res =await Service.intelligentJudgement.queryPeopleInfos({personIds:[data.personId]})
      this.setState({
        ownerInfo:res.data&&res.data[0]
      })
    } catch (error) {
      this.setState({
        ownerInfo:{}
      })
    }
  }
  render() {
    const {data ,ownerInfo} = this.state;
    return (
      <TwoColumnLayout className={`house-person-record`} leftContent={<LeftCard  ownerInfo={ownerInfo} baseData={data}/>}>
        <RecordView data={data} ownerInfo={ownerInfo}/>
      </TwoColumnLayout>
    );
  }
}
export default AbnormalChargeDetail;
