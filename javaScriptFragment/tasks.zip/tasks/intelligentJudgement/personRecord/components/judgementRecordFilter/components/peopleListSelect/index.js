import React, { useState } from 'react';
import { Select } from 'antd';

const { Loader,Dict } = window;
const IconFont = Loader.loadBaseComponent('IconFont');
const Option = Select.Option;

function PeopleListSelect({ value, onTypeChange,peopleList }) {
  
  const [people, setStatus] = useState(value || null);
  const handleTypeChange = function(key) {
    setStatus(key);
    onTypeChange && onTypeChange({ people: key });
  };
  
  return (
    <div style={{ marginRight: '8px' }}>
      <Select
        dropdownClassName="header_filter_select_type_downwrap"
        className="header_filter_type_select"
        style={{ width: 156 }}
        value={people}
        onChange={handleTypeChange}
        defaultValue={people}
        size="small"
        suffixIcon={<IconFont type="icon-S_Arrow_BigDown" />}
      >
        <Option value={-1}>业主及其家属：全部</Option>
        {
          peopleList.map(v => {
          return <Option value={v.aid}>{Dict.getLabel('peopleRelation',v.identifyType)||'其他'}:{v.personName}</Option>
          })
        }
        
      </Select>
    </div>
  );
}

export default PeopleListSelect;
