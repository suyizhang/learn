import React, { useState } from 'react';
import { Select } from 'antd';

const { Loader } = window;
const IconFont = Loader.loadBaseComponent('IconFont');
const Option = Select.Option;

function AccessCardSelect({ value, onTypeChange,accessCardNoList }) {
  
  const [accessCardNos, setStatus] = useState(value || null);
  const handleTypeChange = function(key) {
    setStatus(key);
    onTypeChange && onTypeChange({ accessCardNos: key });
  };
  
  return (
    <div style={{ marginRight: '8px' }}>
      <Select
        dropdownClassName="header_filter_select_type_downwrap"
        className="header_filter_type_select"
        style={{ width: 156 }}
        value={accessCardNos}
        onChange={handleTypeChange}
        defaultValue={accessCardNos}
        size="small"
        suffixIcon={<IconFont type="icon-S_Arrow_BigDown" />}
      >
        <Option value={-1}>门禁卡：全部</Option>
        {
          accessCardNoList.map(v => {
            return <Option value={v}>{v}</Option>
          })
        }
        
      </Select>
    </div>
  );
}

export default AccessCardSelect;
