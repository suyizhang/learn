import React from 'react';
import PeopleListSelect from './components/peopleListSelect';
import AlarmTimeSelect from './components/AlarmTimeSelect';

import './index.less';

class HistoryAlarmListFilter extends React.Component {
  render() {
    let {  searchData, searchDataChange ,peopleList} = this.props;
    return (
      <div className="judgement-record-fliter">
        {peopleList&& !!peopleList.length&&<div className="judgement-record-select">
          <PeopleListSelect value={searchData.people} peopleList={peopleList} onTypeChange={searchDataChange} />
        </div>}
        <div className="judgement-record-range-picker-fliter">
          <AlarmTimeSelect searchData={searchData} onTypeChange={searchDataChange} />
        </div>
      </div>
    );
  }
}

export default HistoryAlarmListFilter;
