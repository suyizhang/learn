import React from 'react';
import './index.less';
const { Loader,Dict } = window;
const LabelValue = Loader.loadBaseComponent('LabelValue');
const IconFont = Loader.loadBaseComponent('IconFont');
const ImageCard = Loader.loadBaseComponent('Card', 'ImageCard');
const LeftCard = props => {
  const { data = {},ownerInfo={} } = props;
  const { villageName, buildNo, unitNo, roomNo,personName } = data;
  const {gender,identityNumber,phoneNumber,representativePhotoUrl,idPhotoUrl,age} = ownerInfo
  return (
    <div className="judgement-left-card">
      <ImageCard imgUrl={idPhotoUrl||representativePhotoUrl} hasErrorImageStyle={false} />
      <div className="judgement-left-card-content">
        <div className="judgement-left-card-vill" title={villageName}>{villageName}</div> 
        <div className="judgement-left-card-house font-resource-normal" title={`${buildNo}楼栋 ${unitNo}单元 ${roomNo}房号`}>{buildNo}楼栋 {unitNo}单元 {roomNo}房号</div> 
        <LabelValue noColon={true} valueColor={'var(--primary)'} label={<IconFont  type='icon-S_Login_UserName' />} value={personName} />
        <LabelValue noColon={true} label={<IconFont  type='icon-M_Photo_Registration1' />} value={identityNumber} />
        <LabelValue noColon={true} label={<IconFont  type='icon-S_AID_AID_Sex' />} value={Dict.getLabel('sex',gender)} />
        <LabelValue noColon={true} label={<IconFont  type='icon-S_AID_AID_Age' />} value={age} />
        <LabelValue noColon={true} label={<IconFont  type='icon-S_Point_Phone' />} value={phoneNumber} />
      </div>
    </div>
  );
};

export default LeftCard;
