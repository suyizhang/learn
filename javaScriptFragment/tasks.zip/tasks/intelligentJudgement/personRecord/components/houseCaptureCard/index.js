import React, { Component } from 'react';
import './index.less';
const { Loader, Utils, Dict } = window;
const ImageView = Loader.loadBaseComponent('ImageView');
const IconFont = Loader.loadBaseComponent('IconFont');
/**
 * @desc 基础卡片
 * @param {string} className 类名
 * @param {boolean} hoverScale img是否hover放大
 * @param {string} name 姓名
 * @param {string} imgUrl 图片url
 * @param {string} deviceName 设备名称
 * @param {string} captureTime 抓拍时间
 * @param {*} renderItem 自定义渲染函数
 * @param {function} onClick 点击回调函数
 */
class HouseCaptureCard extends Component {
  render() {
    let { className = '', active = false, deviceName, address, hoverScale = true, captureTime, imgUrl = '', onClick, children, personInfo } = this.props;
    return (
      <div className={`house-capture-card ${className} ${active ? 'active' : ''}`} onClick={onClick}>
        <div className={`item-img-box ${hoverScale && imgUrl ? 'img-hover-scale' : ''}`}>
          <ImageView src={imgUrl} />
          <div className="person-identify-type">{Dict.getLabel('peopleRelation', personInfo.identifyType)}照片</div>
        </div>
        <div className="item-info">
          <div className="item plate-number">
            <IconFont type={personInfo.identifyType === '114501' ? 'icon-S_Edit_Avatar' : 'icon-S_Edit_User'} />
            {personInfo.name}
          </div>
          {(deviceName || address) && (
            <div className="item device-name" title={deviceName || address}>
              <IconFont type="icon-S_Bar_Add" />
              {(deviceName && Utils.getSubStr(deviceName)) || (address && Utils.getSubStr(address))}
            </div>
          )}
          {captureTime && (
            <div className="item capture-time">
              <IconFont type="icon-S_Edit_ClockEnd" />
              {Utils.formatTimeStamp(captureTime)}
            </div>
          )}
          {children}
        </div>
      </div>
    );
  }
}
export default HouseCaptureCard;
