import React from 'react';
import LeftCard from './components/leftCard';
import SnapshotRecordView from './components/snapshotRecordView';
import AccessControlRecordView from './components/accessControlRecordView';
const { Loader ,LM_DB,Service} = window;
const StaticRoute = Loader.loadBusinessComponent('AppRoute', 'StaticRoute');
const TwoColumnLayout = Loader.loadBaseComponent('Layout', 'TwoColumnLayout');

class PersonRecord extends React.Component {
  constructor(props) {
    super(props);
    this.tabList = [
      {
        title: '门禁记录',
        icon: 'icon-S_Point_Door',
        name: 'accessControlRecord',
        content: <AccessControlRecordView taskType={props.taskType}/>
      },
      {
        title: '抓拍记录',
        icon: 'icon-S_Bar_BodyStructured',
        name: 'snapshotRecord',
        content: <SnapshotRecordView taskType={props.taskType}/>
      }
    ];
    // tip: 权限判断后期补加
    // ....
    this.state = {
      activeKey: this.tabList[0].name,
      data:{},
      ownerInfo:{},
    };
  }

  async componentDidMount () {
    const { history, match, location } = this.props;
    let { data } = await LM_DB.get({ id:match.url.split('/').pop() });
    this.setState({data})
    let lastName = location.pathname.split('/').pop();
    if (!this.tabList.find(v => v.name === lastName)) {
      location.pathname = `${match.url}/${this.tabList[0].name}`;
      location.state = Object.assign({}, location.state);
      history.replace(location);
    }
    await this.getOwnerInfo(data)
  }

  getOwnerInfo  = async data => {
    try {
      let res =await Service.intelligentJudgement.queryPeopleInfos({personIds:[data.personId]})
      this.setState({
        ownerInfo:res.data&&res.data[0]
      })
    } catch (error) {
      this.setState({
        ownerInfo:{}
      })
    }
  }
  render() {
    const { activeKey,data ,ownerInfo} = this.state;
    
    const { match, ...rest } = this.props;
    return (
      <TwoColumnLayout className={`house-person-record`} leftContent={<LeftCard ownerInfo={ownerInfo} data={data}/>}>
        <StaticRoute {...rest} data={data} ownerInfo={ownerInfo} defaultKey={activeKey} path={`${match.url}/:module`} match={match} onTabChange={this.onTabChange} tabList={this.tabList} isRightHead={true} />;
      </TwoColumnLayout>
    );
  }
}
export default PersonRecord;
