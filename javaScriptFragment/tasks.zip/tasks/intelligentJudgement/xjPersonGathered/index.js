import React from 'react';
import AlarmHistory from '../components/personAlarm';
import Task from '../../taskComponents';
const { Loader, BaseStore, Decorator } = window;
const StaticRoute = Loader.loadBusinessComponent('AppRoute', 'StaticRoute');
const AlarmWithLog = Decorator.withEntryLog({moduleName: 'xjPersonGatheredHistory'})(AlarmHistory);
const TaskWithLog = Decorator.withEntryLog({moduleName: 'xjPersonGatheredTask'})(Task);

// XJ人员聚集研判
class XjPersonGathered extends React.Component {
  constructor(props){
    super(props);
    this.tabList = [
      {
        title: '历史预警信息',
        icon: 'icon-S_Bar_Alarm',
        name: 'xjPersonGatheredHistory',
        content: <AlarmWithLog
        taskType='101558'
        cardHeight={160}
        taskApi={'queryTasks'}
        countApi={'countTaskUnhandledNum'}
        listApi={'queryXJGatherResults'}
        detailModuleName={'xjPersonGatheredDetail'} />
      },
      {
        title: '研判任务管理',
        icon: 'icon-S_View_Task',
        name: 'xjPersonGatheredTask',
        content: <TaskWithLog
          type='xjPersonGathered'
        />
      }
    ] 
    this.tabList = this.tabList.filter(v => !!BaseStore.menu.getInfoByName(v.name))
    this.state = {
      activeKey: this.tabList[0].name
    }
  }

  componentDidMount() {
    const { history, match, location } = this.props;
    let lastName = location.pathname.split('/').pop();
    if (!this.tabList.find(v => v.name === lastName)) {
      location.pathname = `${match.url}/${this.tabList[0].name}`;
      location.state = Object.assign({}, location.state);
      history.replace(location);
    }
  }
  render(){
    const { activeKey } = this.state;
    const { match, ...rest } = this.props;
    return <StaticRoute {...rest} defaultKey={activeKey} path={`${match.url}/:module`} match={match} onTabChange={this.onTabChange} tabList={this.tabList} isRightHead={true} />;
  }
}
export default XjPersonGathered;