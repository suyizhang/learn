import React from 'react';
import './index.less';

const { Loader,Dict } = window;
const TwoColumnCard = Loader.loadBusinessComponent('Card', 'TwoColumnCard');
const CardPopover = Loader.loadBusinessComponent('Card', 'CardPopover');
// const IconFont = Loader.loadBaseComponent("IconFont");
// const LabelVaule = Loader.loadBaseComponent("LabelVaule");
const TagFooter = Loader.loadBaseComponent("Card", "TagFooter");
const IconValueCard = Loader.loadBaseComponent('Card',"IconValueCard");
const nationDict = Dict.map.nation;
const sexDict = Dict.map.sex;
const generationDict = Dict.map.generation;
/**
 * @desc 详情左侧档案卡片
 * @param {string} icon 图标
 * @param {string} info 信息
 * @param {func} onFollow 回调
 * @param {node} children 子组件
 */
const LeftCard = props => {
  const { data = {},labelList, onFollow, children } = props;
  let footer = {
    labelList: labelList,
    tagList: data.personTags,
    data
  };
  const {name,address,aid,identityNumber,nation,gender,ageGroup,phoneNumber} = data
  let imgUrl = data.idPhotoUrl || data.representativePhotoUrl
  const nationItem = nationDict.find(v => v.value === nation) || {};
  const genderItem = sexDict.find(v => v.value === gender) || {};
  const ageGroupItem = generationDict.find(v => v.value === ageGroup) || {};
  return (<div style={{height:250, paddingTop: 15}}>
    <TwoColumnCard {...props} imgUrl={imgUrl} className='left-card'  footer={<TagFooter {...footer} />}>
      <div className="lm-persom-card-popovers">
        {onFollow && (
          <CardPopover
            key="onFollow"
            content={''}
            icon={''}
            style={{
              color: '' ? 'var(--primary)' : 'var(--icon)'
            }}
            callBack={e => onFollow(data, e)}
          />
        )}
      </div>
      <IconValueCard icon={'icon-S_Login_UserName' } value={name} />
      {address && <IconValueCard icon={'icon-S_Bar_Add' } value={address} />}
      {aid && <IconValueCard icon={'icon-S_View_Clustering'} value={aid} />}
      <IconValueCard icon={'icon-M_Photo_Registration1' } value={identityNumber} />
      <IconValueCard icon={'icon-S_AID_AID_Flag' } value={nationItem.label} />
      <IconValueCard icon={'icon-L_AID_Gender1' } value={genderItem.label} />
      <IconValueCard icon={'icon-S_Point_Phone' } value={phoneNumber} />
      <IconValueCard icon={'icon-L_AID_Age1' } value={ageGroupItem.label} />
      {children}
    </TwoColumnCard></div>
  );
};

export default LeftCard;
