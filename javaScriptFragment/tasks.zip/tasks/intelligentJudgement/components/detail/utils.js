const { BaseStore, Utils } = window


// 跳转人员档案
export function _jumpPersonnelDetail({ moduleName,id, type, item=undefined }) {
  if (!BaseStore.menu.isAuth(moduleName)) {
    return Utils.log.debug('暂无人员档案权限！');
  }
  if(item) {
    if (item.personId) {
      id = item.personId;
      type = 'ploy';
    }
    if (item.aid) {
      id = item.aid;
      type = 'aid';
    }
    // if (!item.aid && !item.hasAid) {
    //   id = item.personId;
    //   type = 'entry';
    // }
  }
  const tabKey = BaseStore.tab.createTabKey();
  _goPage.call(this, {
    id,
    moduleName: `${moduleName}/${tabKey}/personnelDetail`,
    // extraPath: type ? `/${type}` : '',
  })
};

// 不可改成箭头函数，会影响this指向
export async function _goPage({ moduleName, id, extraPath = '', state }) {
  let { history, location, base, themeMode } = this.props;
  if (themeMode === 'single') {
    base = `/intelligentJudgement/${BaseStore.tab.createTabKey()}`;
  }
  const tabKey = BaseStore.tab.createTabKey();
  const newLocation = {
    pathname: `${base}/${moduleName}/${tabKey}/${id}${extraPath}`,
    state: state || location.state
  }
  history.push(newLocation);
};

