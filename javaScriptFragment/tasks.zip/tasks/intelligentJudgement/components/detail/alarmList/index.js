import React from "react";
import { itemGrid, offsetOptions, detailItemGrid } from './alarmGridConfig'
import ContactCard from '../../card/contactCard'

const { Loader } = window
const InfiniteScrollLayout = Loader.loadBaseComponent('List', 'InfiniteScrollLayout')
const ListBox = Loader.loadBaseComponent('Box', 'ListBox')
const IconFont = Loader.loadBaseComponent('IconFont');

const cardsComponent = [
  {
    type: "AbnormalPersonCard", // 异常人员
    component: Loader.loadBusinessComponent("Card", "AbnormalPersonCard")
  },
  {
    type: "MultipointUnusualCard", // 人员多点
    component: Loader.loadBusinessComponent("Card", "MultipointUnusualCard")
  },
  {
    type: "SubscriptionCard", // 异常群体
    component: Loader.loadBusinessComponent("Card", "SubscriptionCard")
  },
  {
    type: "CaptureCard", // 抓拍列表
    component: Loader.loadBusinessComponent("Card", "CaptureCard")
  },
  {
    type: "ContactCard", // 抓拍列表
    component: (props) => <ContactCard {...props} />
  }
];

class AlarmList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      type: 1,
      hasLoadMore: true
    };
    this.infinitRef = React.createRef();
  }

  handlePageJump = (data) => {
    const { handlePageJump } = this.props;
    handlePageJump && handlePageJump(data);
  };

  loadMore = () => {
    let { searchData, onTypeChange, total, isLoadMore = true } = this.props;
    if (!isLoadMore) {
      return; // 详情列表不需要loadMore
    }
    this.setState({
      hasLoadMore: false
    }, () => {
      if (searchData.offset > total - searchData.limit) {
        return;
      }
      searchData.offset += searchData.limit;
      onTypeChange && onTypeChange(searchData, true).then(length => {
        if (length === searchData.limit) {
          this.setState({ hasLoadMore: true })
        }
      })
    })
  };

  getPlaceColor = type => {
    let colors = ['--danger', '--primary'];
    return colors[type];
  }

  // 人员多点异常
  getChildren = item => {
    const { taskType } = this.props;
    const { placeName, type } = item;
    if (taskType !== '101522') {
      return null;
    }
    if (type !== 2) {
      // 人员多点异常详情卡片增加小区字段
      return <div className="item" style={{ color: `var(${this.getPlaceColor(type)})` }}>
        <IconFont type="icon-S_Tree_Place" />
        {placeName || '-'}
      </div>
    } else {
      return <div style={{ height: '17px' }}></div>
    }
  }

  render() {
    let {
      list,
      className,
      infinitKey,
      cardType,
      itemHeight,
      moduleName,
      searchType,
      httpStatus,
      isDetail=true,
      showPlaceName
    } = this.props;
    let { hasLoadMore } = this.state;
    let Card = cardsComponent.find(v => v.type === cardType).component;

    console.log(isDetail);
    let itemGrids=isDetail ? detailItemGrid[cardType] : itemGrid[cardType]
    list.forEach((v,i) => {v.idx=i})
    return (
      <ListBox
        className={`history-alarm-list ${className}`}
        offsetOptions={isDetail ? 0 : offsetOptions[cardType]}
      >
        <InfiniteScrollLayout
          gutter={15}
          itemHeight={itemHeight}
          data={list}
          key={infinitKey}
          itemGrid={itemGrids}
          isNoData={httpStatus !== 'loading' && list.length === 0}
          ref={this.infinitRef}
          hasBackTop={true}
          loadMore={this.loadMore}
          hasLoadMore={hasLoadMore}
          renderItem={(item,index) => {
            const color = item.total > 80 ? '#FF5F57' : "#B5BBC7"
            return <div key={item.id}>
              <Card
                showPlaceName={showPlaceName}
                color={color}
                data={item}
                placeName={item.placeName}
                moduleName={moduleName}
                type={1}
                height={itemHeight}
                // score={libType === 4 ? item.score : null}
                handlePageJump={this.handlePageJump}
                handleChangeYN={this.handleChangeYN}
                onClick={() => this.handlePageJump(item)}
                deviceName={item.deviceName}
                captureTime={item.captureTime}
                relativeIcon={false}
                imgUrl={item.faceUrl}
                children={this.getChildren(item)}
                searchType={searchType}
              />
            </div>
          }}
        />
      </ListBox>
    );
  }
}

export default AlarmList;
