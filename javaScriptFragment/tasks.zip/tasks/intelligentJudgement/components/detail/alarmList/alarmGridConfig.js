
export const offsetOptions = {
  CalendarCard: {
    xxl: 1, // ≥1600px
    xl: 1, // ≥1200px
    lg: 2, // ≥992px
    md: 1, // ≥768px
    sm: 0, // ≥576px
    xs: 4, // <576px 
  },
  MultipointUnusualCard: {
    xxl: 2, // ≥1600px
    xl: 0, // ≥1200px
    lg: 0, // ≥992px
    md: 1, // ≥768px
    sm: 0, // ≥576px
    xs: 2, // <576px 
  },
  SubscriptionCard: {
    xxl: 1, // ≥1600px
    xl: 1, // ≥1200px
    lg: 2, // ≥992px
    md: 1, // ≥768px
    sm: 0, // ≥576px
    xs: 4, // <576px 
  },
  AbnormalPersonCard: {
    xxl: 1, // ≥1600px
    xl: 0, // ≥1200px
    lg: 1, // ≥992px
    md: 4, // ≥768px
    sm: 4, // ≥576px
    xs: 4, // <576px 
  },
}
export const itemGrid = {
  CalendarCard: { // 疑似人口
    xxl: 6, // ≥1600px
    xl: 8, // ≥1200px
    lg: 12, // ≥992px
    md: 12, // ≥768px
    sm: 12, // ≥576px
    xs: 24, // <576px 
  },
  MultipointUnusualCard: {
    xxl: 4, // ≥1600px
    xl: 4.5, // ≥1200px
    lg: 6, // ≥992px
    md: 8, // ≥768px
    sm: 8, // ≥576px
    xs: 12, // <576px 
  },
  SubscriptionCard: {
    xxl: 6, // ≥1600px
    xl: 8, // ≥1200px
    lg: 12, // ≥992px
    md: 12, // ≥768px
    sm: 12, // ≥576px
    xs: 24, // <576px 
  },
  AbnormalPersonCard: {
    xxl: 6, // ≥1600px
    xl: 8, // ≥1200px
    lg: 12, // ≥992px
    md: 24, // ≥768px
    sm: 24, // ≥576px
    xs: 24, // <576px 
  },
};
export const detailItemGrid = {
  CaptureCard: {
    xxl: 6, // ≥1600px
    xl: 8, // ≥1200px
    lg: 12, // ≥992px
    md: 12, // ≥768px
    sm: 12, // ≥576px
    xs: 12, // <576px 
  },
  ContactCard: {
    xxl: 8, // ≥1600px
    xl: 8, // ≥1200px
    lg: 12, // ≥992px
    md: 12, // ≥768px
    sm: 24, // ≥576px
    xs: 24, // <576px 
  },
};

