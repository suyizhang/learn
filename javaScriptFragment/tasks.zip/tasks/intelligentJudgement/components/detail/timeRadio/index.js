import React from "react";
import { Radio, Popover, Button } from "antd";
import moment from "moment";
import RangePicker from '../RangePicker'
import "./index.less";
const {Utils} = window


class AlarmTimeRadio extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dateBegin: null,
      dateEnd: null,
      showDate: false,
      popHoverType: false,
      option: {}
    };
    this.refTime = React.createRef();
  }

  chooseTime = e => {
    let { onTypeChange } = this.props;
    let value = e.target.value;
    if (value === undefined || value === "undefined") {
      onTypeChange({startTime:undefined,endTime:undefined,timeType:undefined})
    }else {
      onTypeChange({timeType:2})
      this.setState({
        popHoverType: true
      });
    }
  };

  timeChange = (type, value) => {
    let startTime=undefined ,
      endTime = undefined;
    if (type === "startTime") {
      startTime = moment(moment(value).format("YYYY-MM-DD HH:mm:ss")).valueOf();
      this.setState({ dateBegin: startTime });
    } else {
      endTime = value;
      this.setState({ dateEnd: endTime });
    }
  };

  popSubmit = () => {
    let { dateBegin, dateEnd } = this.state;
    this.props.onTypeChange({startTime:dateBegin, endTime:dateEnd,timeType:2 });
    this.setState({
      popHoverType: false
    });
  };

  popCancel = () => {
    this.setState({
      popHoverType: false
    });
  };

  popClick = e => {
    Utils.stopPropagation(e);
      this.setState({
        popHoverType: !this.state.popHoverType
      });
  };

  render() {
    let { dateBegin, dateEnd, popHoverType } = this.state;
    const {timeType} = this.props.searchData
    return (
      <div className="alarm-time-radio">
        <div className="time-piack-layout" ref={this.refTime} />
        <Radio.Group
          className="header_filter_radio"
          defaultValue={"undefined"}
          value={ timeType ? 2:"undefined"}
          buttonStyle="solid"
          onChange={this.chooseTime}
          size="small"
        >
          <Radio value={"undefined"}>全部</Radio>
          <Popover
            overlayClassName={"radio_poppver"}
            getPopupContainer={() => this.refTime.current}
            content={
              <div>
                <RangePicker
                  onChange={this.timeChange}
                  startTime={dateBegin}
                  endTime={dateEnd}
                  allowClear={false}
                />
                <div className="pop_btn">
                  <Button onClick={this.popCancel}>取消</Button>
                  <Button onClick={this.popSubmit} type="primary">
                    确定
                  </Button>
                </div>
              </div>
            }
            placement="bottom"
            visible={popHoverType}
          >
            <span>
              <Radio onClick={this.popClick} value={2}>
                自定义
              </Radio>
            </span>
          </Popover>
        </Radio.Group>
      </div>
    );
  }
}

export default AlarmTimeRadio;
