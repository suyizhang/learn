
export const itemGrid = {
    normal: {
      xxl: 3, // ≥1600px
      xl: 5, // ≥1200px
      lg: 6, // ≥992px
      md: 8, // ≥768px
      sm: 8, // ≥576px
      xs: 12, // <576px 
    },
    large: {
      xxl: 4, // ≥1600px
      xl: 4, // ≥1200px
      lg: 8, // ≥992px
      md: 12, // ≥768px
      sm: 12, // ≥576px
      xs: 24, // <576px 
    }
};
export const offsetOptions = {
    normal: {
        xxl: 1, // ≥1600px
        xl: 1, // ≥1200px
        lg: 0, // ≥992px
        md: 1, // ≥768px
        sm: 0, // ≥576px
        xs: 2, // <576px 
      },
      large: {
        xxl: 1, // ≥1600px
        xl: 1, // ≥1200px
        lg: 2, // ≥992px
        md: 1, // ≥768px
        sm: 0, // ≥576px
        xs: 4, // <576px 
      }
}