import React from 'react';
import { Select } from 'antd'
import './index.less';

const { Loader } = window;
const Option = Select.Option;
const IconFont = Loader.loadBaseComponent('IconFont')


export default ({ searchData, changeSearchData }) => {
  return (
    <div className="task-button-group">
      <span>
        <span className='text-second-tip'>来源 : </span>
        <Select
          value={searchData.source}
          onChange={source => changeSearchData({source})}
          suffixIcon={<IconFont type='icon-S_Arrow_BigDown' />}
        >
          <Option value={'all'}>全部</Option>
          <Option value={'local'}>本地任务</Option>
          <Option value={'assign'}>指派任务</Option>
        </Select>
      </span>
      <span>
        <span className='text-second-tip'>状态 : </span>
        <Select
          value={searchData.status[0]}
          onChange={statues => changeSearchData({status: [statues]})}
          suffixIcon={<IconFont type='icon-S_Arrow_BigDown' />}
        >
          <Option value={'all'}>全部</Option>
          <Option value={'running'}>运行中</Option>
          <Option value={'notStarted'}>未开始</Option>
          <Option value={'paused'}>已暂停</Option>
          <Option value={'expired'}>已过期</Option>
          <Option value={'deleted'}>已删除</Option>
        </Select>
      </span>
    </div>
  )
}