import React from 'react';
import moment from "moment";

import SpecialCard from '../../../card/specialCard';
const { Loader, Utils } = window;
const PersonCard = Loader.loadBaseComponent('Card', 'PersonCard');
const SubscriptionCard = Loader.loadBaseComponent('Card', 'SubscriptionCard');
const TagFooter = Loader.loadBaseComponent('Card', 'TagFooter');
const OwnerCard = Loader.loadBaseComponent('Card', 'OwnerCard');
const AccessCard = Loader.loadBaseComponent('Card', 'AccessCard');
const modelArray={
  relationsArray:[
    { value: 0, label: '且' },
    { value: 1, label: '或' },
  ],
  statisticalModeArray:[
    { value: 0, label: '累计' },
    { value: 1, label: '平均' },
  ]
}
const getModelLabel = (value,type) => {
  let item = modelArray[`${type}Array`].find((v) => v.value === value) || {}
  return item.label
}
const getCard = (item, index,that) => {
  const { taskType } = that.props;
  const { labelList } = that.state;
  let footer = {
    labelList,
    tagList: item.personTags || item.tagCodes || [],
    key: index,
    data: item,
  };
  switch (taskType) {
    case '101551':
      //	闲置房屋疑似住人
      return (
        <OwnerCard
          data={item}
          click={() => that.handlePageJump(item)}
          footerContent={`闲置房业主${item.taskRule.days || 0}天内,抓拍记录超过${item.taskRule.captureCount || 0}次,${getModelLabel(item.taskRule.relations,'relations')}名下门禁卡刷卡次数累计大于${item.taskRule.accessCardCount}次`}
        />
      );
    case '101552':
      //	自住房疑似租赁
      return (
        <OwnerCard
          data={item}
          click={() => that.handlePageJump(item)}
          footerContent={`自住房业主${item.taskRule.days || 0}天内,抓拍记录小于${item.taskRule.captureCount || 0}次,${getModelLabel(item.taskRule.relations,'relations')}名下门禁卡刷卡次数累计大于${item.taskRule.accessCardCount}次`}
        />
      );
    case '101562':
      //	异常刷卡
      return (
        <AccessCard
          data={item}
          infoList={[
            { icon: 'icon-S_Login_UserName', label: <span className="highlight">{item.personName}</span> },
            {
              icon: 'icon-S_Photo_Library',
              label: (
                <span title={item.accessCardNo} className="highlight">
                  {item.accessCardNo}
                </span>
              ),
            },
            { icon: 'icon-S_Point_Phone', label: item.tel },
          ]}
          click={() => that.handlePageJump(item)}
          footerContent={`${item.taskRule.days || 0}天内,刷卡次数${getModelLabel(item.taskRule.statisticalMode,'statisticalMode')}大于${item.taskRule.accessCardCount || 0}次`}
        />
      );
    case '101555':
      //	特殊人员同出现
      return <SpecialCard click={that.handlePageJump} data={item} labelList={labelList} />;
    case '101559':
      //	XJ人员串联
      return <SpecialCard type='串联' click={that.handlePageJump} data={item} labelList={labelList} />;
    case '101558':
      //	XJ人员聚集
      return (
        <SubscriptionCard
          data={item}
          moduleName={'abnormalGroupsList'}
          height={300}
          handlePageJump={that.handlePageJump}
          relativeIcon={false}
        />
      );
    case '101554':
      //	外来前科人员出现
      return (
        <PersonCard
          sourceData={item}
          click={that.handlePageJump}
          footer={<TagFooter {...footer} />}
          imgUrl={item.lastCaptureUrl || ''}
          // onRelation={that.onRelation}
          data={[
            { infos: [{ info: (item.personBriefInfos &&  item.personBriefInfos.personName) ? item.personBriefInfos.personName : item.aid, icon: 'icon-S_Edit_Avatar' },
            { info: item.alarmDeviceName, icon: 'icon-S_Bar_Map' }] },
            {
              infos: [
                { info: item.lastCaptureDeviceName, icon: 'icon-S_Bar_Add' },
                { info: item.lastCaptureTime ? Utils.formatTimeStamp(+item.lastCaptureTime) : '暂无', icon: 'icon-S_Edit_ClockEnd' },
              ],
              label: getLabel(taskType),
            },
          ]}
          children={getOtherInfo(taskType,item)}
        />
      );
    case '101553':
      //疑似失足
      return (
        <PersonCard
          sourceData={item}
          click={that.handlePageJump}
          footer={<TagFooter {...footer} />}
          imgUrl={(item.imageUrls && item.imageUrls[0]) || (item.aidPictureInfos && item.aidPictureInfos.length > 0 && item.aidPictureInfos[0].newestPictureUrl) || ''}
          // onRelation={that.onRelation}
          data={[
            { infos: [{ info: item.personName || item.aid, icon: 'icon-S_Edit_Avatar' },
            { info: item.address, icon: 'icon-S_Bar_Map' }] },
            {
              infos: [
                { info: item.recentAppearanceAddress, icon: 'icon-S_Bar_Add' },
                { info: item.recentAppearanceTime ? Utils.formatTimeStamp(+item.recentAppearanceTime) : '暂无', icon: 'icon-S_Edit_ClockEnd' },
              ],
              label: getLabel(taskType),
            },
          ]}
          children={getOtherInfo(taskType,item)}
        />
      );
    case '101560':
      //人员昼伏夜出
      return (
        <PersonCard
          sourceData={item}
          click={that.handlePageJump}
          footer={<TagFooter {...footer} />}
          imgUrl={(item.imageUrls && item.imageUrls[0]) || (item.aidPictureInfos && item.aidPictureInfos.length > 0 && item.aidPictureInfos[0].newestPictureUrl) || ''}
          // onRelation={that.onRelation}
          data={[
            { infos: [{ info: item.personName || item.aid, icon: 'icon-S_Edit_Avatar' },
            { info: item.address, icon: 'icon-S_Bar_Map' }] },
            {
              infos: [
                { info: item.recentAppearanceAddress, icon: 'icon-S_Bar_Add' },
                { info: item.recentAppearanceTime ? Utils.formatTimeStamp(+item.recentAppearanceTime) : '暂无', icon: 'icon-S_Edit_ClockEnd' },
              ],
              label: getLabel(taskType),
            },
          ]}
        />
      );
    default:
      //精神病、XJ人员长期未出现、吸毒人员、青壮年长期未出现
      // 101556、101557、101561、101563

      return (
        <PersonCard
          sourceData={item}
          click={that.handlePageJump}
          footer={<TagFooter {...footer} />}
          imgUrl={(item.imageUrls && item.imageUrls[0]) || (item.aidPictureInfos && item.aidPictureInfos.length > 0 && item.aidPictureInfos[0].newestPictureUrl) || ''}
          // onRelation={that.onRelation}
          data={[
            { infos: [{ info: item.personName || item.aid, icon: 'icon-S_Edit_Avatar' },
            { info: item.address, icon: 'icon-S_Bar_Map' }] },
            {
              infos: [
                { info: item.warningInfo && item.warningInfo.lastCaptureAddress, icon: 'icon-S_Bar_Add' },
                { info: item.warningInfo ? Utils.formatTimeStamp(+item.warningInfo.lastCaptureTime) : '暂无', icon: 'icon-S_Edit_ClockEnd' },
              ],
              label: getLabel(taskType),
            },
          ]}
          children={getOtherInfo(taskType,item)}
        />
      );
  }
};
const getLabel = type => {
  switch(type){
    case '101553':
      return '最近出现';
      case '101560':
        return '最近出现';
      case '101554':
        return '最后出现';
      case '101556' :
        return '居住地最后出现';
      case '101557':
        return '居住地最后出现';
      case '101561':
        return '居住地最后出现';
      case '101563':
        return '居住地最后出现';
    default:
    return ''
  }
}

const getOtherInfo = (type,item) => {
  let { warningInfo = {}, continueTime = 0 } = item;
  let { notAppearDay = 0, lastCaptureTime = 0, } = warningInfo;

  //计算未出现时间
  let notAppearDayCopy = notAppearDay || Math.ceil((moment().valueOf()-lastCaptureTime)/(1*24*60*60*1000))
  let lastTime = lastCaptureTime ? moment(lastCaptureTime*1).format("YYYY.MM.DD") : 0;
  let nowTime = moment().format("YYYY.MM.DD");
  const getResult = () => {
    const str1 = `${notAppearDayCopy ? `连续${notAppearDayCopy*1}天未出现` : '从未出现'}`
    return<div className="lm-card-info other-info">
        <div className="ellipsis" title={str1} >{str1}</div>
        {lastCaptureTime*1 > 0 && <div className="ellipsis" title={`${lastTime}-${nowTime}`}>{`${lastTime}-${nowTime}`}</div>}
    </div>;
  }

  switch(type){
    case '101553':
      return <div className="lm-card-info other-info">正常工作时间不出现</div>;
      case '101560':
        return '';
      case '101554':
        return <div className="lm-card-info other-info">
            <div className="ellipsis" title={`在 ${item.placeName} 异常活动`}>
              在 {item.placeName} 异常活动
            </div>
            <div className="ellipsis">
              {`滞留 ${Math.ceil(1*continueTime/60000)} 分钟`}
            </div>
        </div>;
      case '101556' :
        //（精神病）
        return <div className="lm-card-info other-info">{getResult()}</div>;
      case '101557':
        // （XJ长期未出现）
        return <div className="lm-card-info other-info">{getResult()}</div>;
      case '101561':
        // （吸毒人员长期未出现）
        return <div className="lm-card-info other-info">{getResult()}</div>;
      case '101563':
        // （青壮年长期未出现）
        return <div className="lm-card-info other-info">{getResult()}</div>;
    default:
    return ''
  }
}

export default {
  getCard,
};
