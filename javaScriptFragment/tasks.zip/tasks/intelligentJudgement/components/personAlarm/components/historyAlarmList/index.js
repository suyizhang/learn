import React from 'react';
import { offsetOptions } from '../../../alarmGridConfig';
import HistoryAlarmListFilter from '../historyAlarmListFilter';
import cardConfig from './cardConfig';
import { message } from 'antd';
import './index.less';
const { Loader, Service, Utils, Shared, BaseStore, LM_DB } = window;
const InfiniteScrollLayout = Loader.loadBaseComponent('List', 'InfiniteScrollLayout');
const Portal = Loader.loadBaseComponent('Portal');
const Progress = Loader.loadBaseComponent('Progress');
const ListBox = Loader.loadBaseComponent('Box', 'ListBox');
// const SimilarDrawer = Loader.loadBusinessComponent('Drawer', 'SimilarDrawer');

class HistoryAlarmList extends React.Component {
  constructor(props) {
    super(props);
    this.listRef = React.createRef();
    this.state = {
      list: [],
      total: 0,
      hasLoadMore: false,
      loading: 'over',
      similarVisible: false,
      personData: {},
      labelList: [],
      searchData: {
        startTime: undefined,
        endTime: undefined,
        [`${['101553', '101560'].includes(props.taskType) ? 'assessmentType' : 'assessmentTypes'}`]: ['101554', '101558'].includes(props.taskType)
          ? undefined
          : ['101553', '101560'].includes(props.taskType)
          ? props.taskType
          : [props.taskType],
        taskIds: [],
        offset: 0,
        limit: 60,
      },
    };
  }

  componentDidMount() {
    this.initTags();
    this.getList({
      ...this.state.searchData,
      taskIds: this.props.taskIds,
      // taskIds:[1000000000020001]
    });
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props.taskIds && nextProps.taskIds !== this.props.taskIds) {
      if (nextProps.taskIds.length > 0) {
        let options = this.mergeSearchData({ taskIds: nextProps.taskIds, offset: 0 });
        this.setState({ hasLoadMore: false }, () => {
          this.getList(options);
        });
      } else {
        this.setState({ list: [], total: 0, hasLoadMore: false });
      }
    }
  }

  /**
   * 更新参数
   * @param {*} options
   */
  mergeSearchData(options) {
    const searchDataNew = Object.assign({}, this.state.searchData, options);
    this.setState({ searchData: searchDataNew });
    return searchDataNew;
  }

  /**
   * 筛选条件更改
   */
  searchDataChange = (options) => {
    const param = this.mergeSearchData({ ...options, offset: 0 });
    this.getList(param);
  };

  getList = async (option) => {
    if (!option.taskIds || (option.taskIds && option.taskIds.length <= 0)) {
      return false;
    }
    this.setState({ loading: 'loading' });
    let { list, searchData } = this.state;
    let { limit, offset } = searchData;
    let { listApi } = this.props;
    let hasLoadMore = false;
    let res = await Service.intelligentJudgement[`${listApi}`](option);
    if (res.code === 0) {
      let newData = res.data.list || [];
      if (newData.length === limit) {
        hasLoadMore = true;
      }
      hasLoadMore && this.mergeSearchData({ offset: offset + limit });
      this.setState(
        {
          list: hasLoadMore ? list.concat(newData) : newData,
          loading: 'over',
          hasLoadMore,
          total: res.data.total,
        },
        () => {
          this.listRef.current && this.listRef.current.forceUpdateGrid();
        }
      );
    } else {
      this.setState({ loading: 'error' });
      message.error(res.data.message);
    }
  };

  // 加载更多
  loadMore = () => {
    let { searchData } = this.state;
    return this.getList(searchData);
  };

  /**刷新 */
  refresh = () => {
    let options = this.mergeSearchData({ offset: 0 });
    this.getList(options);
  };

  handlePageJump = async (item, e) => {
    console.log(item);

    let { base, history, detailModuleName, taskType } = this.props;
    //闲置房屋疑似住人、疑似租赁房、外来前科人员出现、特殊人员同出现、XJ人员聚集、XJ人员串联
    if (['101551', '101552', '101554', '101555', '101558', '101559'].includes(taskType)) {
      let id = BaseStore.tab.createTabKey();
      const options = {
        id,
        data: {
          ...item,
        },
      };
      await LM_DB.put(options);
      const pathname = `${base}/${detailModuleName}/${id}`;
      // 疑似租赁房
      if (taskType === '101552') {
        history.push({
          pathname,
          state: {
            taskType,
            pageState: {
              tabTitle: '疑似租赁房研判',
            },
          },
        });
      } else if (taskType === '101551') {
        history.push({
          pathname,
          state: {
            taskType,
            pageState: {
              tabTitle: '闲置房屋疑似住人研判',
            },
          },
        });
      } else {
        history.push(pathname);
      }
    } else if (['101562'].includes(taskType)) {
      //	异常刷卡
      let id = BaseStore.tab.createTabKey();
      const options = {
        id,
        data: {
          ...item,
        },
      };
      await LM_DB.put(options);
      const pathname = `${base}/${detailModuleName}/${id}`;
      history.push(pathname);
    } else {
      /**跳转人员档案页面 */
      const { aid, personId } = item;
      const menu = BaseStore.menu.getInfoByName('personnelDetail');
      Shared.jumpPersonFile({ base, history, aid, personId, moduleName: menu ? 'personnelDetail' : 'communityPersonnelDetail' });
    }

    // 记录日志
    let logInfo = Service.url.request.judgeDetail[taskType] || {};
    let description = `${logInfo.text},信息id/aid/personId：${item.id || item.aid || item.personId}`;
    Service.logger.save({
      description,
      ...logInfo,
    });
  };

  getButtonContent(total) {
    return (
      <div className="history-alarm-top-right">
        <span className="header-text">
          共显示
          <b className="text-red"> {total && Utils.thousand(+total)} </b>
          条资源
        </span>
        {/* <Button className="refresh_btn" onClick={this.refresh}>
          <Icon type="reload" /> 刷新
        </Button> */}
      </div>
    );
  }
  initTags = async () => {
    let list = await Shared.getPersonTagList();
    this.setState({ labelList: list });
  };
  onRelation = (item) => {
    this.setState({ similarVisible: true, personData: item });
  };

  render() {
    let { taskType, cardHeight = 300 } = this.props;
    let { list, loading, total, searchData, hasLoadMore } = this.state; // ,personData,similarVisible

    return (
      <div className="history-alarm-list-box">
        <Progress status={loading} />
        <Portal getContainer={this.props.getHeaderRightExtContent} content={this.getButtonContent(total)} />
        <HistoryAlarmListFilter taskType={taskType} searchData={searchData} searchDataChange={this.searchDataChange} />
        <ListBox offsetOptions={offsetOptions.large} className={'history-alarm-list'}>
          <InfiniteScrollLayout
            gutter={20}
            isNoData={(loading === 'over' || loading === 'error') && list.length === 0}
            itemGrid={{ xxl: 6, xl: 8, lg: 12, md: 12, sm: 24, xs: 24 }}
            loadMore={this.loadMore}
            hasLoadMore={hasLoadMore}
            hasBackTop={true}
            data={list}
            renderItem={(item, index) => cardConfig.getCard(item, index, this)}
            itemHeight={cardHeight}
          />
          {/* {(taskType === '101553' || taskType === '101560') && <SimilarDrawer
            personData={personData}
            visible={similarVisible}
            onOk={() => this.setState({ similarVisible: false })}
            onCancel={() => this.setState({ similarVisible: false })}
            onClose={() => this.setState({ similarVisible: false })}
          />} */}
        </ListBox>
      </div>
    );
  }
}

export default HistoryAlarmList;
