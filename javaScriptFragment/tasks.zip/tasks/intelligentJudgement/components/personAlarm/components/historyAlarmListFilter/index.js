import React from 'react'
import AlarmTimeSelect from './components/AlarmTimeSelect'

import './index.less'


class HistoryAlarmListFilter extends React.Component{


    render(){
        let { searchData, searchDataChange} = this.props;
        return(
            <div className="history-alarm-list-filter">
                <div className="left">
                    <AlarmTimeSelect 
                        searchData={searchData}
                        onTypeChange={searchDataChange}
                    />
                </div>
            </div>
        )
    }
}

export default HistoryAlarmListFilter