import React from 'react'
import moment from 'moment'

const { Loader } = window;
const RangePickerFilter = Loader.loadBaseComponent("Filter", "RangePickerFilter");

class AlarmTimeSelect extends React.Component {


    onTypeChange = (date) =>{
        let [startTime, endTime] = date;
        let param = {}
        if(!startTime || !endTime){
            param = {startTime: undefined, endTime: undefined}
        }else{
            param = {startTime: moment(startTime).valueOf(), endTime: moment(endTime).valueOf()}
        }
        this.props.onTypeChange && this.props.onTypeChange(param);
    }

    render(){
        let { searchData } = this.props;
        let { startTime, endTime } = searchData
        return(
            <RangePickerFilter 
                value={[startTime && moment(startTime), endTime && moment(endTime)]}
                onChange={this.onTypeChange}
            />
        )
    }
}

export default AlarmTimeSelect;