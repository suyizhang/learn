import React, { Component } from 'react'
import _ from 'lodash'
// import TaskList from './components/taskList'
import TaskList from './components/taskList/hooks'
import HistoryAlarmList from './components/historyAlarmList'
import { message } from 'antd'

const { Loader, Service } = window
const TwoColumnLayout = Loader.loadBaseComponent('Layout', 'TwoColumnLayout')

class HistoryAlarm extends Component {
  constructor(props) {
    super(props)
    const { taskType } = props
    // this.searchList = Shared.searchList(searchList);
    this.state = {
      taskIds: [], // 选中的任务ids
      checkAll: true, //全选状态
      searchData: {
        source: 'all', // 任务来源
        status: ['running'], // 任务状态
        keywords: '', // 搜索框
        types: [taskType],
        offset: 0,
        limit: 500
      }
    }
  }

  alarmAllIds = []

  componentDidMount() {
    this.getTaskList({}, true)
  }

  changeSearchData = (options, isChangeActive = true) => {
    let searchData = { ...this.state.searchData, ...options }
    this.setState({ searchData })
    let param = _.cloneDeep(searchData)
    // if (param.status[0] === -1) {
    //   delete param.status
    // }
    this.getTaskList(param, isChangeActive)
  }

  //兼容前科聚集的source，status
  getSource = type => {
    switch(type){
      case 'local':
        return 1;
        case 'assign':
          return 2;  
          default:
            return 0;
    }
  }
  getStatus = type => {
    switch(type){
      case 'running':
        return 1
        case 'notStarted':
          return 2
          case 'paused':
            return 0
            case 'expired':
              return 3
              case 'deleted':
                return 4;
                default:
                  return undefined
    }
  }

  /**根据条件查询任务列表 */
  getTaskList = async(options, isChangeActive) => {
    const { taskType,taskApi,countApi } = this.props
    const { searchData } = this.state;
    let api,params;
    // 外来前科人员出现、XJ人员聚集
    if(['101554','101558'].includes(taskType)){
      api = 'subscription'
      params={
        ...searchData,
        ...options
      }
      params.source = this.getSource(params.source)
      params.status = this.getStatus(params.status[0])
    }else{
      api = 'intelligentJudgement'
      params={...searchData,...options}
    }
    return Service[`${api}`][`${taskApi}`](params, true)
    .then(res => {
      if (res.code === 0) {
        let list = res.data && res.data.list
        let taskIds = list.length > 0 ? list.map(v => v.id) : []
        isChangeActive && this.getAlarmHistoryId(taskIds)
        if (taskIds.length > 0) {
          Service[`${api}`][`${countApi}`]({[`${['101554','101558'].includes(taskType)?'eventType':'assessmentType'}`]:taskType,taskIds}).then(result => {
            if (!result.data) {
              return
            }
            list.forEach(item => {
              if (result.data[item.id]) {
                item.unhandledAlarmCount = result.data[item.id]
              }
            })
            this.setState({ list })
          }).catch(err => {
            this.setState({ list })
          })
        } else {
          this.setState({ list })
        }
      } else {
        message.error('布控任务列表查询失败')
      }
    })
  }

  getAlarmHistoryId(taskIds) {
    //布控告警所有id-全局设置, 初始全部选中
    this.alarmAllIds = taskIds
    this.setState({
      taskIds,
      checkAll: true
    })
  }

  // 布控任务选中
  changeAlarmTask = id => {
    const taskIds = [id]
    const checkAll = this.alarmAllIds.length === 1
    this.setState({
      taskIds,
      checkAll
    })
    // console.log('taskIds---', taskIds)
  }

  // 全选
  alarmCheckAll = e => {
    let checkValue = e.target.checked
    this.setState({
      taskIds: checkValue ? this.alarmAllIds : [],
      checkAll: checkValue
    })
    // console.log('taskIds---', checkValue ? this.alarmAllIds : [])
  }

  render() {
    let { taskIds, searchData, checkAll, list } = this.state
    
    let {taskType, ...props } = this.props
    return (
      <TwoColumnLayout
        className={`event-real-notify`}
        leftContent={
          <TaskList
            taskIds={taskIds}
            taskType={taskType}
            list={list}
            searchData={searchData}
            checkAll={checkAll}
            alarmCheckAll={this.alarmCheckAll}
            changeAlarmTask={this.changeAlarmTask}
            getTaskList={this.getTaskList}
            changeSearchData={this.changeSearchData}
          />
        }
      >
        <HistoryAlarmList {...props} taskType={taskType} taskIds={taskIds} />
      </TwoColumnLayout>
    )
  }
}
export default HistoryAlarm
