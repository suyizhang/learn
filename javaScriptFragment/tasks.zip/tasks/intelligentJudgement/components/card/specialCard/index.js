import React from 'react';
import moment from 'moment';
import './index.less';

const { Loader } = window;
const IconValueCard = Loader.loadBaseComponent('Card', 'IconValueCard');
const TagFooter = Loader.loadBaseComponent('Card', 'TagFooter');
const ImageCard = Loader.loadBaseComponent('Card', 'ImageCard');
/**
 * @desc 特殊人员列表卡片
 */

const AlarmTwoImgCard = (props) => {
  const { data = {}, type = '同出现', labelList, click } = props;
  let footer = {
    labelList: labelList,
    tagList: data.personTags,
    data,
  };
  let { lastTogetherFaceUrl, aid, faceUrl, togetherCount = 0, captureTime, villageName = '', personName } = data; // lastTogetherAid
  return (
    <div className={`lm-two-img-card special-card `} onClick={() => click && click(data)}>
      <div className="lm-two-img-card-header">
        <div className="header-box">
          <ImageCard imgUrl={faceUrl} hasErrorImageStyle={false} />
          <div className="img-text">{villageName ? villageName : '小区'}人员</div>
        </div>
        <div className="header-box">
          <ImageCard imgUrl={lastTogetherFaceUrl} hasErrorImageStyle={false} />
          <div className="img-text">非{villageName ? villageName : '小区'}人员</div>
        </div>
        <div className="img-desc">
          {type} {togetherCount} 次
        </div>
      </div>
      <div className="lm-two-img-card-info" style={{ paddingBottom: 44 }}>
        <div className="two-name">
          <IconValueCard value={personName || aid} icon={'icon-S_Login_UserName'} />
          {/* <IconValueCard value={lastTogetherAid} icon={'icon-S_Login_UserName'} /> */}
        </div>
        <IconValueCard title={villageName} value={villageName} icon={'icon-S_Place_Place'} />
        <IconValueCard value={moment(parseInt(captureTime, 10)).format('YYYY.MM.DD HH:mm:ss')} icon={'icon-S_Edit_ClockEnd'} />
      </div>
      <TagFooter {...footer} />
    </div>
  );
};

export default AlarmTwoImgCard;
