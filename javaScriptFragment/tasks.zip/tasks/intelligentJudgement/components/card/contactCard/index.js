import React from 'react';
import moment from 'moment'
import './index.less'

const { Loader,Utils } = window;
const IconValueCard = Loader.loadBaseComponent('Card',"IconValueCard");
const ImageCard = Loader.loadBaseComponent("Card", "ImageCard");
/**
 * @desc 特殊人员列表卡片
 */

const AlarmTwoImgCard = props => {
  const { data = {},click } = props;
  let { personName,villageName, faceUrl,idx, togetherPersonName,deviceName, togetherVillageName='', togetherFaceUrl,captureTime=0 } = data
return (<>{idx+1 && <p>第<span style={{color:'var(--primary)'}}>{idx+1}</span>次同出现</p>}
    <div className={`lm-two-img-card contact-card `} onClick={() => click && click(data)}>
      <div className="lm-two-img-card-header">
        <div className="header-box">
          <ImageCard imgUrl={faceUrl} hasErrorImageStyle={false} />
        </div>
        <div className="header-box">
          <ImageCard imgUrl={togetherFaceUrl} hasErrorImageStyle={false} />
        </div>
      </div>
      <div className="lm-two-img-card-infos">
      <div className="lm-two-img-card-info">
        <IconValueCard value={personName} icon={'icon-S_Login_UserName'} />
        <IconValueCard title={villageName} value={(villageName && Utils.getSubStr(villageName))} icon={'icon-M_Bar_Place1'} />
        <IconValueCard title={deviceName} value={deviceName} icon={'icon-S_Bar_Add'} />
        <IconValueCard value={moment(parseInt(captureTime, 10)).format('YYYY.MM.DD HH:mm:ss')} icon={'icon-S_Edit_ClockEnd'} />
      </div>
      <div className="lm-two-img-card-info">
        <IconValueCard value={togetherPersonName} icon={'icon-S_Login_UserName'} />
        <IconValueCard title={togetherVillageName} value={(togetherVillageName && Utils.getSubStr(togetherVillageName))} icon={'icon-M_Bar_Place1'} />
        <IconValueCard title={deviceName} value={deviceName} icon={'icon-S_Bar_Add'} />
        <IconValueCard value={moment(parseInt(captureTime, 10)).format('YYYY.MM.DD HH:mm:ss')} icon={'icon-S_Edit_ClockEnd'} />
      </div></div>
    </div></>
  )
}

export default AlarmTwoImgCard

