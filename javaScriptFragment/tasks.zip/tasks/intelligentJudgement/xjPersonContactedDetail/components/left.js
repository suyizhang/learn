import React, { useEffect, useState, useRef, useMemo } from 'react';
// import { Checkbox } from 'antd';
import LeftCard from '../../components/detail/leftCard';

const { Loader } = window;

const SimpleList = Loader.loadBaseComponent('List', 'SimpleList');

function Left({ baseData, apearList = [], labelList = [], getCheckIds }) {
  const listRef = useRef();
  // const [checkAll, setCheckAll] = useState(true);
  const [checkIds, setCheckIds] = useState(apearList.map((v) => v.id));
  useEffect(() => {
    listRef && listRef.current && listRef.current.forceUpdateGrid();
  }, [checkIds]);
  // function checkAlls(checked) {
  //   setCheckAll(checked);
  //   let ids = [];
  //   if (checked) {
  //     ids = apearList.map((v) => v.id);
  //   }
  //   getCheckIds && getCheckIds(ids);
  // }
  function checkOne(id) {
    setCheckIds([id]);
    getCheckIds && getCheckIds([id]);
  }
  const [currentData, list] = useMemo(() => {
    const cdata = apearList.find((v) => v.aid === baseData.aid);
    const list = apearList.filter((v) => v.aid !== baseData.aid);
    return [cdata, list];
  }, [baseData, apearList]);
  return (
    <div className="xj-person-contacted-detail-left">
      <LeftCard data={currentData} labelList={labelList} />
      <div style={{ paddingTop: 20, paddingLeft: 8 }}>
        <span style={{ marginRight: '145px' }}>同出现人员：</span>
        {/* <Checkbox onChange={() => checkAlls(!checkAll)} checked={checkAll} /><span> 展示全部</span> */}
      </div>
      <div className="together-appear">
        <SimpleList ref={listRef} data={list} rowHeight={250} renderItem={(v) => <LeftCard onClick={() => checkOne(v.id)} key={v.id} data={v} labelList={labelList} />} />
      </div>
    </div>
  );
}

export default Left;
