import React from 'react';
import AlarmHistory from '../components/personAlarm';
import Task from '../../taskComponents';
const { Loader, BaseStore, Decorator } = window;
const StaticRoute = Loader.loadBusinessComponent('AppRoute', 'StaticRoute');
const AlarmWithLog = Decorator.withEntryLog({moduleName: 'youngNotAppearHistory'})(AlarmHistory);
const TaskWithLog = Decorator.withEntryLog({moduleName: 'youngNotAppearTask'})(Task);

// 青壮年长期未出现研判
class YoungNotAppear extends React.Component {
  constructor(props){
    super(props);
    this.tabList = [
      {
        title: '历史预警信息',
        icon: 'icon-S_Bar_Alarm',
        name: 'youngNotAppearHistory',
        content: <AlarmWithLog
        taskType='101563'
        cardHeight={260}
        taskApi={'queryTasks'}
        countApi={'countTaskWarnings'}
        listApi={'queryNotAppearWarnings'}
        detailModuleName={''} />
      },
      {
        title: '研判任务管理',
        icon: 'icon-S_View_Task',
        name: 'youngNotAppearTask',
        content: (
          <TaskWithLog type='youngNotAppear' />
        )
      }
    ] 
    this.tabList = this.tabList.filter(v => !!BaseStore.menu.getInfoByName(v.name))
    this.state = {
      activeKey: this.tabList[0].name
    }
  }

  componentDidMount() {
    const { history, match, location } = this.props;
    let lastName = location.pathname.split('/').pop();
    if (!this.tabList.find(v => v.name === lastName)) {
      location.pathname = `${match.url}/${this.tabList[0].name}`;
      location.state = Object.assign({}, location.state);
      history.replace(location);
    }
  }
  render(){
    const { activeKey } = this.state;
    const { match, ...rest } = this.props;
    return <StaticRoute {...rest} defaultKey={activeKey} path={`${match.url}/:module`} match={match} onTabChange={this.onTabChange} tabList={this.tabList} isRightHead={true} />;
  }
}
export default YoungNotAppear;