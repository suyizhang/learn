import React, { useMemo } from 'react';
import LeftCard from '../../components/detail/leftCard';

const { Loader } = window;

const SimpleList = Loader.loadBaseComponent('List', 'SimpleList');

function Left({ baseData, apearList = [], labelList = [] }) {
  const [currentData, list] = useMemo(() => {
    const cdata = apearList.find((v) => v.aid === baseData.aid);
    const list = apearList.filter((v) => v.aid !== baseData.aid);
    return [cdata, list];
  }, [baseData, apearList]);
  return (
    <div className="multipoint-unusual-detail-aside">
      <LeftCard data={currentData} labelList={labelList} />
      <div style={{ paddingTop: 20, paddingLeft: 8 }}>
        <span style={{ marginRight: '145px' }}>同出现人员：</span>
      </div>
      <div className="together-appear">
        <SimpleList data={list} rowHeight={250} renderItem={(v) => <LeftCard key={v.id} data={v} labelList={labelList} />} />
      </div>
    </div>
  );
}

export default Left;
