import React from 'react';
import Left from './components/left';
import AlarmList from '../components/detail/alarmList';
import { _jumpPersonnelDetail, _goPage } from '../components/detail/utils';
import moment from 'moment';
import ContactCard from '../components/card/contactCard';
import _ from 'lodash';
import './index.less';

const { Loader, Service, LM_DB, Shared } = window;

const TwoColumnLayout = Loader.loadBaseComponent('Layout', 'TwoColumnLayout');
const Progress = Loader.loadBaseComponent('Progress');
const Portal = Loader.loadBaseComponent('Portal');
const LabelValue = Loader.loadBaseComponent('LabelValue');
const IconFont = Loader.loadBaseComponent('IconFont');
const InfoBox = Loader.loadBaseComponent('Box', 'InfoBox');
const PaddingBox = Loader.loadBaseComponent('Box', 'PaddingBox');
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const Button = Loader.loadBaseComponent('Form', 'Button');
const CoOccurrenceMap = Loader.loadBusinessComponent('LMap', 'CoOccurrenceMap');

class outsidePreConvictionsDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      httpStatus: 'loading',
      baseData: {},
      detailData: {}, //详情信息
      trackList: [],
      type: 'map',
      dataList: [], // 人员列表
      placeList: [], // 场所边界
      apearList: [], //同出现人员
    };
  }

  async componentDidMount() {
    let { location } = this.props;
    const id = location.pathname.split('/').reverse()[0];
    let { data } = await LM_DB.get({ id });
    const option = {
      aid: data.aid,
      warningTime: data.warningTime,
      taskId: data.taskId,
      // taskId:1000000000020001
    };
    let res = await Service.intelligentJudgement.getTogetherAppearWarningsDetail(option);
    this.setState({ baseData: data, detailData: res.data }, () => {
      let togetherAids = res.data.togetherAids || [];
      this.initTags();
      this.getPersons([res.data.aid, ...togetherAids]);
      this.getTrackList(option); // 查询轨迹
    });
  }

  getPersons = async (aids) => {
    let result = await Service.intelligentJudgement.queryPeopleInfos({ aids: _.uniq(aids) });
    this.setState({ apearList: result.data, httpStatus: 'over' });
  };

  initTags = async () => {
    let list = await Shared.getPersonTagList();
    this.setState({ labelList: list });
  };

  getTrackList = async (data = {}) => {
    let result = await Service.intelligentJudgement.queryTogetherAppearWarningsTrack(data);
    this.setState({ trackList: result.data.list, dataList: result.data.list, httpStatus: 'over' });
    this.getPlacesPolylineByIds(result.data.list); // 查询边界
  };

  getPlacesPolylineByIds = async (dataList) => {
    let placeIds = [],
      typePlaceKeyValue = {};
    dataList.forEach((v) => {
      typePlaceKeyValue[v.placeId] = v.type;
      placeIds.push(v.placeId);
    });
    placeIds = _.uniq(placeIds);
    // 通过场所id集合批量获取带边界的场所信息
    if (placeIds.length > 0) {
      const res = await Service.place.getPlacesPolylineByIds({ placeIds });
      let placeList = Array.isArray(res.data) ? res.data.forEach((v) => (v.type = typePlaceKeyValue[v.id])) : [];
      this.setState({ placeList });
    }
  };

  // 跳转人员档案
  goPage = () => {
    const { baseData } = this.state;
    _jumpPersonnelDetail.call(this, { item: baseData });
  };

  // 跳转抓拍详情
  handlePageJump = async (item) => {
    const id = item.id;
    await LM_DB.put({ id, data: this.state.dataList });
    _goPage.call(this, { id, moduleName: 'intelligentJudgementCaptureDetail' });
  };

  render() {
    const { baseData, type, httpStatus, dataList, detailData, placeList, labelList = [], apearList } = this.state;
    let { warningTime, taskRule = {}, togetherCount = 0 } = detailData; //captureTimes = []
    const isMapStyle = type === 'map';
    return (
      <TwoColumnLayout className="specially-accompany-detail" leftContent={<Left apearList={apearList} baseData={baseData} labelList={labelList} />}>
        <Progress status={httpStatus} />
        <Portal
          getContainer={this.props.getHeaderRightExtContent}
          style={{
            fontSize: '12px',
            textAlign: 'right',
            paddingRight: '24px',
          }}
        />
        <InfoBox grid={'rightScreen'} className="multipoint-unusual-detail-content">
          <PaddingBox className="detail-box">
            <BoxDesc className="info-detail" title="活动信息">
              <LabelValue label={`${taskRule.hours}小时内同出现次数`} value={togetherCount} valueColor={'var(--primary)'} />
              <LabelValue label="告警时间" value={warningTime ? moment(warningTime * 1).format(Shared.format.dataTime) : undefined} />
            </BoxDesc>
            <BoxDesc className="trajectory-detail" title="轨迹及详情">
              <div className="type-change-btn-box">
                <Button type={isMapStyle ? 'primary' : 'default'} onClick={() => this.setState({ type: 'map' })}>
                  <IconFont type="icon-S_Photo_ListMap" />
                  地图模式
                </Button>
                <Button type={!isMapStyle ? 'primary' : 'default'} onClick={() => this.setState({ type: 'list' })}>
                  <IconFont type="icon-S_Photo_ListTree" />
                  列表模式
                </Button>
              </div>
              <div className="trajectory-container">
                {type === 'list' && (
                  <AlarmList
                    cardType="ContactCard"
                    list={dataList}
                    total={dataList.length}
                    httpStatus={httpStatus}
                    itemHeight={300}
                    isDetail
                    isLoadMore={false}
                    taskType="101555"
                    handlePageJump={this.handlePageJump}
                  />
                )}
                {type === 'map' && <CoOccurrenceMap placeId={taskRule.placeId} list={dataList.filter((v) => v.latitude && v.longitude)} placeList={placeList} Card={ContactCard} />}
              </div>
            </BoxDesc>
          </PaddingBox>
        </InfoBox>
      </TwoColumnLayout>
    );
  }
}

export default outsidePreConvictionsDetail;
