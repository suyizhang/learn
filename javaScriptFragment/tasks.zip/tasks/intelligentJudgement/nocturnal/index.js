import React from 'react';
import AlarmHistory from '../components/personAlarm';
import Task from '../../taskComponents';
const { Loader,BaseStore, Decorator } = window;
const StaticRoute = Loader.loadBusinessComponent('AppRoute', 'StaticRoute');
const AlarmWithLog = Decorator.withEntryLog({moduleName: 'nocturnalHistory'})(AlarmHistory);
const TaskWithLog = Decorator.withEntryLog({moduleName: 'nocturnalTask'})(Task);

// 人员昼伏夜出研判
class Nocturnal extends React.Component {
  constructor(props){
    super(props);
    this.tabList = [
      {
        title: '历史预警信息',
        icon: 'icon-S_Bar_Alarm',
        name: 'nocturnalHistory',
        content: <AlarmWithLog
        taskType='101560'
        cardHeight={320}
        taskApi={'queryTasks'}
        countApi={'countTaskWarningsForGraph'}
        listApi={'queryWarnings'}
        detailModuleName={''} />
      },
      {
        title: '研判任务管理',
        icon: 'icon-S_View_Task',
        name: 'nocturnalTask',
        content: <TaskWithLog
          type='nocturnal'
        />
      }
    ] 
    this.tabList = this.tabList.filter(v => !!BaseStore.menu.getInfoByName(v.name))
    this.state = {
      activeKey: this.tabList[0].name
    }
  }

  componentDidMount() {
    const { history, match, location } = this.props;
    let lastName = location.pathname.split('/').pop();
    if (!this.tabList.find(v => v.name === lastName)) {
      location.pathname = `${match.url}/${this.tabList[0].name}`;
      location.state = Object.assign({}, location.state);
      history.replace(location);
    }
  }
  render(){
    const { activeKey } = this.state;
    const { match, ...rest } = this.props;
    return <StaticRoute {...rest} defaultKey={activeKey} path={`${match.url}/:module`} match={match} onTabChange={this.onTabChange} tabList={this.tabList} isRightHead={true} />;
  }
}
export default Nocturnal;