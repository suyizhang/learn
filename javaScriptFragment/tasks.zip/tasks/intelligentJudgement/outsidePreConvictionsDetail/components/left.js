import React from 'react';

const { Loader, Dict } = window

const ImageView = Loader.loadBaseComponent('ImageView');
const LabelValue = Loader.loadBaseComponent('LabelValue');
const IconFont = Loader.loadBaseComponent('IconFont');

const nationDict = Dict.map.nation;
const sexDict = Dict.map.sex;
const generationDict = Dict.map.generation;
const dictLabel = [
  ...Dict.map.personnelAttr,
  ...Dict.map.gait,
  ...Dict.map.height,
  ...Dict.map.fatAndThin,
  ...Dict.map.identity,
  ...Dict.map.aidBehavior,
  ...Dict.map.behaviorAttr,
  ...Dict.map.aidBehaviorCode,
  ...Dict.map.appearPlace,
  ...Dict.map.faceMask,
  ...Dict.map.preConvictionsTags
];

export default ({ baseData, imgUrl, className }) => {
  let { aid, personTags = [], personDetailInfos = [{}], ageGroup, nation, sex } = baseData;
  // 姓名字段处理
  let personNames = [];
  personDetailInfos.forEach(v => {
    if (v.personName) {
      personNames.push(v.personName);
    }
  });
  let personNameLabel = [...new Set(personNames)].join();
  if (personDetailInfos[0].nation) {
    nation = personDetailInfos[0].nation;
  }
  if (personDetailInfos[0].sex) {
    sex = personDetailInfos[0].sex;
  }
  const nationItem = nationDict.find(v => v.value === nation) || {};
  const genderItem = sexDict.find(v => v.value === sex) || {};
  const ageGroupItem = generationDict.find(v => v.value === ageGroup) || {};
  return (
    <div className={className}>
      <div className="left-img">
        <ImageView src={imgUrl} />
      </div>
      <div className="left-tags">
        {personTags.length > 0 &&
          personTags.map(item => {
            let tag = {};
            if (dictLabel.length > 0) {
              tag = dictLabel.find(v => v.value === item);
            }
            let timeSpace = ['119051', '118703', '118702'];
            if (item - 120700 > 0 && item - 120700 < 21) {
              timeSpace.push(item);
            }
            return (
              <div className="label-info">
                {timeSpace.includes(tag.value) ? (
                  <div className="label label-palce label-chose">
                    <span className="label-palce-icon">
                      <IconFont type={'icon-S_Bar_Eye'} theme="outlined" />{' '}
                    </span>
                    {tag.label}
                  </div>
                ) : (
                    tag.label
                  )}
              </div>
            );
          })}
      </div>
      <div className="left-baseInfo">
        <LabelValue label="姓名" value={personNameLabel || undefined} valueColor={'var(--primary)'} />
        <LabelValue label="虚拟身份" value={aid} />
        <LabelValue label="身份证号" value={personDetailInfos[0].idNumber} />
        <LabelValue label="民族" value={nationItem.label} />
        <LabelValue label="性别" value={genderItem.label} />
        <LabelValue label="手机号码" value={personDetailInfos[0].phoneNumber} />
        <LabelValue label="年龄段" value={ageGroupItem.label} />
      </div>
    </div>
  );
};
