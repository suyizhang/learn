import React from 'react';
import Left from './components/left';
import AlarmList from '../components/detail/alarmList';
import { _jumpPersonnelDetail, _goPage } from '../components/detail/utils';
import TimeRadio from '../components/detail/timeRadio';

import moment from 'moment';
import _ from 'lodash';
import './index.less';

const { Loader, Service, LM_DB, Shared } = window; //Dict,

const TwoColumnLayout = Loader.loadBaseComponent('Layout', 'TwoColumnLayout');
const Progress = Loader.loadBaseComponent('Progress');
const Portal = Loader.loadBaseComponent('Portal');
const LabelValue = Loader.loadBaseComponent('LabelValue');
const IconFont = Loader.loadBaseComponent('IconFont');
const InfoBox = Loader.loadBaseComponent('Box', 'InfoBox');
const PaddingBox = Loader.loadBaseComponent('Box', 'PaddingBox');
const BoxDesc = Loader.loadBaseComponent('Box', 'BoxDesc');
const Button = Loader.loadBaseComponent('Form', 'Button');
const AbnormalPersonMutipeTrajectory = Loader.loadBusinessComponent('LMap', 'AbnormalPersonMutipeTrajectory');

class MultipointUnusualDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      httpStatus: 'loading',
      baseData: {},
      trackList: [],
      type: 'map',
      dataList: [], // 人员列表
      placeList: [], // 场所边界
      searchData: {
        startTime: undefined,
        endTime: undefined,
        timeType: undefined,
      },
    };
  }

  async componentDidMount() {
    let { location } = this.props;
    const id = location.pathname.split('/').reverse()[0];
    let { data } = await LM_DB.get({ id });
    const option = {
      aid: data.aid,
      personId: data.personId,
      id: data.id,
    };
    // 查询详情
    try {
      const result = await Service.intelligentJudgement.personForeign(option);
      this.setState({ baseData: result.data, searchData: { startTime: result.data.firstTime, endTime: result.data.lastTime } }, () => {
        this.getTrackList(result.data); // 查询轨迹
        this.queryActivityTrackList(result.data); // 查询列表
      });
    } catch (error) {
      console.error(error);
      this.setState({ httpStatus: 'error' });
    }
  }

  getTrackList = async (data = {}) => {
    const { context, aid } = data;
    const contectObj = JSON.parse(context);
    const option = {
      aid,
      days: 15,
      placeIds: contectObj.foreignPersonActivity.placeIds,
      placeTag: contectObj.foreignPersonActivity.placeTag,
    };
    let result = await Service.subscription.queryPersonAbnormalActivityTrack(option);
    let trackList = result.data.map((v) => {
      v.position = [v.longitude, v.latitude];
      v.trackList && v.trackList.map((x) => (x.position = [x.longitude, x.latitude]));
      v.list = v.trackList;
      return v;
    });
    this.setState({ trackList: trackList, httpStatus: 'over' });
  };

  queryActivityTrackList = async (detailInfo) => {
    const { context, aid, captureIds, firstTime, lastTime } = detailInfo;
    let { startTime, endTime } = this.state.searchData;
    if (!startTime && !endTime) {
      startTime = firstTime;
      endTime = lastTime;
    }
    let contextObj = JSON.parse(context);
    const options = {
      aid,
      eventType: '101522',
      startTime,
      endTime,
      placeIds: contextObj.foreignPersonActivity.placeIds,
      placeTag: contextObj.foreignPersonActivity.placeTag,
      captureIds,
    };
    const res = await Service.subscription.queryActivityTrackList(options);
    const dataList = res.data || [];
    this.setState({ dataList, httpStatus: 'over' });
    this.getPlacesPolylineByIds(dataList);
  };

  //抓拍列表筛选
  onTypeChange = (option) => {
    const { searchData, baseData } = this.state;
    this.setState({ searchData: { ...searchData, ...option } }, () => this.queryActivityTrackList(baseData));
  };

  getPlacesPolylineByIds = async (dataList) => {
    let placeIds = [],
      typePlaceKeyValue = {};
    dataList.forEach((v) => {
      typePlaceKeyValue[v.placeId] = v.type;
      placeIds.push(v.placeId);
    });
    placeIds = _.uniq(placeIds);
    // 通过场所id集合批量获取带边界的场所信息
    const res = await Service.place.getPlacesPolylineByIds({ placeIds });
    res.data.forEach((v) => (v.type = typePlaceKeyValue[v.id]));
    let placeList = res.data;
    this.setState({ placeList });
  };

  // 跳转人员档案
  goPage = () => {
    const { baseData } = this.state;
    _jumpPersonnelDetail.call(this, { item: baseData });
  };

  // 跳转抓拍详情
  handlePageJump = async (item) => {
    const id = item.id;
    await LM_DB.put({ id, data: this.state.dataList });
    _goPage.call(this, { id, moduleName: 'subscriptionCaptureDetail' });
  };

  render() {
    const { baseData, type, httpStatus, dataList, trackList = [], placeList, searchData } = this.state;
    const { lastTime, alarmTime, placeName, aidPicture, permanentAddress = '' } = baseData; // placeTag,
    // let placeTagInfo = Dict.map.placeType.find(v => v.value === placeTag) || {};
    const isMapStyle = type === 'map';
    return (
      <TwoColumnLayout className="outside-preConvictions-detail" leftContent={<Left className="multipoint-unusual-detail-aside" baseData={baseData} imgUrl={aidPicture} />}>
        <Progress status={httpStatus} />
        <Portal
          getContainer={this.props.getHeaderRightExtContent}
          style={{
            fontSize: '12px',
            textAlign: 'right',
            paddingRight: '24px',
          }}
        />
        <InfoBox grid={'rightScreen'} className="multipoint-unusual-detail-content">
          <PaddingBox className="detail-box">
            <BoxDesc className="info-detail" title="活动信息">
              <LabelValue label="住址" value={permanentAddress} />
              <LabelValue label="异常活动区域" value={placeName} />
              <LabelValue label="告警时间" value={alarmTime ? moment(alarmTime * 1).format(Shared.format.dataTime) : undefined} />
              <LabelValue label="异常活动区域最后出现时间" value={lastTime ? moment(lastTime * 1).format(Shared.format.dataTime) : undefined} valueColor={'var(--primary)'} />
            </BoxDesc>
            <BoxDesc className="trajectory-detail" title="轨迹及详情">
              <div className="type-change-btn-box">
                <Button type={isMapStyle ? 'primary' : 'default'} onClick={() => this.setState({ type: 'map' })}>
                  <IconFont type="icon-S_Photo_ListMap" />
                  地图模式
                </Button>
                <Button type={!isMapStyle ? 'primary' : 'default'} onClick={() => this.setState({ type: 'list' })}>
                  <IconFont type="icon-S_Photo_ListTree" />
                  列表模式
                </Button>
                <TimeRadio searchData={searchData} onTypeChange={this.onTypeChange} />
              </div>
              <div className="trajectory-container">
                {type === 'list' && (
                  <AlarmList
                    cardType="CaptureCard"
                    list={dataList}
                    total={dataList.length}
                    httpStatus={httpStatus}
                    itemHeight={300}
                    isLoadMore={false}
                    taskType="10154"
                    showPlaceName={true}
                    handlePageJump={this.handlePageJump}
                  />
                )}
                {type === 'map' && <AbnormalPersonMutipeTrajectory data={trackList} list={dataList} placeList={placeList} dataNameKey="deviceName" />}
              </div>
            </BoxDesc>
          </PaddingBox>
        </InfoBox>
      </TwoColumnLayout>
    );
  }
}

export default MultipointUnusualDetail;
