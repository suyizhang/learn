import React from 'react';
import Task from '../../taskComponents';
import AlarmHistory from '../components/personAlarm';
// const { Loader, BaseStore, Dict, Decorator } = window;
const { Loader, BaseStore, Decorator } = window;
const StaticRoute = Loader.loadBusinessComponent('AppRoute', 'StaticRoute');
const AlarmWithLog = Decorator.withEntryLog({moduleName: 'astrayPersonHistory'})(AlarmHistory);
const TaskWithLog = Decorator.withEntryLog({moduleName: 'astrayPersonTask'})(Task);

//疑似失足人员研判
class AstrayPerson extends React.Component {
  constructor(props){
    super(props);
    this.tabList = [
      {
        title: '历史预警信息',
        icon: 'icon-S_Bar_Alarm',
        name: 'astrayPersonHistory',
        content: <AlarmWithLog
        taskType='101553'
        countApi={'countTaskWarningsForGraph'}
        taskApi={'queryTasks'}
        listApi={'queryWarnings'}
        detailModuleName={''}
        />
      },
      {
        title: '研判任务管理',
        icon: 'icon-S_View_Task',
        name: 'astrayPersonTask',
        content: <TaskWithLog
          type='astrayPerson'
        />
      }
    ] 
    this.tabList = this.tabList.filter(v => !!BaseStore.menu.getInfoByName(v.name))
    this.state = {
      activeKey: this.tabList[0].name
    }
  }

  componentDidMount() {
    const { history, match, location } = this.props;
    let lastName = location.pathname.split('/').pop();
    if (!this.tabList.find(v => v.name === lastName)) {
      location.pathname = `${match.url}/${this.tabList[0].name}`;
      location.state = Object.assign({}, location.state);
      history.replace(location);
    }
  }
  render(){
    const { activeKey } = this.state;
    const { match, ...rest } = this.props;
    return <StaticRoute {...rest} defaultKey={activeKey} path={`${match.url}/:module`} match={match} onTabChange={this.onTabChange} tabList={this.tabList} isRightHead={true} />;
  }
}
export default AstrayPerson;