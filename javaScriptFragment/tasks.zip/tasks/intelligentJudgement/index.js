import React from 'react';
import IdlehousehasPerson from './idlehousehasPerson'; // 闲置房屋疑似住人研判
import PersonRecord from './personRecord'; // 闲置房屋疑似住人研判记录
import SuspectedRentalHousing from './suspectedRentalHousing'; // 疑似租赁房研判
import AstrayPerson from './astrayPerson'; // 疑似失足人员研判
import OutsidePreConvictions from './outsidePreConvictions'; // 外来前科人员研判
import OutsidePreConvictionsDetail from './outsidePreConvictionsDetail'; // 外来前科人员研判详情
import SpeciallyAccompany from './speciallyAccompany'; // 特殊人员同行研判
import SpeciallyAccompanyDetail from './speciallyAccompanyDetail'; // 特殊人员同行研判详情
import PsychoticNotAppear from './psychoticNotAppear'; // 精神病长期未出现研判
import XjPersonNotAppear from './xjPersonNotAppear'; // XJ人员长期未出现研判
import XjPersonGathered from './xjPersonGathered'; // XJ人员聚集研判
import XjPersonGatheredDetail from './xjPersonGatheredDetail'; // XJ人员聚集研判详情
import XjPersonContacted from './xjPersonContacted'; // XJ人员串联研判
import XjPersonContactedDetail from './xjPersonContactedDetail'; // XJ人员串联研判详情
import Nocturnal from './nocturnal'; // 人员昼伏夜出研判
import Addict from './addict'; // 吸毒人员研判
import AbnormalCharge from './abnormalCharge'; // 异常刷卡研判
import AbnormalChargeDetail from './abnormalChargeDetail'; // 异常刷卡研判
import YoungNotAppear from './youngNotAppear'; // 青壮年长期未出现研判

const { Loader } = window;
const DynamicRoute = Loader.loadBusinessComponent("AppRoute", "DynamicRoute");
const SimpleRoute = Loader.loadBusinessComponent("AppRoute", "SimpleRoute");

class IntelligentJudgement extends React.Component {
  render(){
    const { match } = this.props;
    const RenderRouter = this.props.themeMode === "single" ? SimpleRoute : DynamicRoute;
    return (
      <RenderRouter 
        {...this.props}
        path={`${match.url}/:module/:key`}
        base={match.url}
        tabKey="intelligent-judgement-tab"
        defaultTitle="人员布控"
        hasExtContent={false}
        includeModuleNames={[
          'all',
          // 'idlehousehasPerson',
          // 'personRecord',
          // 'suspectedRentalHousing',
          // 'astrayPerson',
          // 'outsidePreConvictions',
          // 'speciallyAccompany',
          // 'psychoticNotAppear',
          // 'xjPersonNotAppear',
          // 'xjPersonGathered',
          // 'xjPersonContacted',
          // 'nocturnal',
          // 'addict',
          // 'abnormalCharge',
          // 'abnormalChargeDetail',
          // 'youngNotAppear',
          // 'outsidePreConvictionsDetail',
          // 'speciallyAccompanyDetail',
          // 'xjPersonGatheredDetail',
          // 'xjPersonContactedDetail',
          // 'personnelDetail'
        ]}
        renderModuleConfig={{
          idlehousehasPerson: IdlehousehasPerson,
          personRecord: PersonRecord,
          suspectedRentalHousing: SuspectedRentalHousing,
          astrayPerson: AstrayPerson,
          outsidePreConvictions: OutsidePreConvictions,
          speciallyAccompany: SpeciallyAccompany,
          psychoticNotAppear: PsychoticNotAppear,
          xjPersonNotAppear: XjPersonNotAppear,
          xjPersonGathered: XjPersonGathered,
          xjPersonContacted: XjPersonContacted,
          nocturnal: Nocturnal,
          addict: Addict,
          abnormalCharge: AbnormalCharge,
          abnormalChargeDetail: AbnormalChargeDetail,
          youngNotAppear: YoungNotAppear,
          outsidePreConvictionsDetail:OutsidePreConvictionsDetail,
          speciallyAccompanyDetail:SpeciallyAccompanyDetail,
          xjPersonGatheredDetail:XjPersonGatheredDetail,
          xjPersonContactedDetail:XjPersonContactedDetail,
        }}
      />
    )
  }
}
export default IntelligentJudgement;