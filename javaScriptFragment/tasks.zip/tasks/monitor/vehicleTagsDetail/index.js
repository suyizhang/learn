import React from 'react'
import { message } from 'antd'
import { inject } from 'mobx-react'
import headers from '../components/headers'
import './index.less'

const { Loader, LM_DB, SocketEmitter, Utils, Service } = window
const CommandCapturePage = Loader.loadBusinessComponent('CommandCapturePage');
const CaptureCard = Loader.loadBusinessComponent('Card', 'LibraryCard')
const DetailPictureMap = Loader.loadBusinessComponent('DetailPictureMap')
const ProgressLoding = Loader.loadBaseComponent('Progress')
const HorizontalScrollLayout = Loader.loadBaseComponent('List', 'HorizontalScrollLayout')
const Notice = Loader.loadBaseComponent('Modal', 'Notice')

/*
libType
详情类型
  重点人员布控历史告警详情  1
  非法入侵告警详情         2
  魅影告警								3
  专网套件告警详情         4
  重点车辆告警						5
  外来车辆告警详情        6
*/
@inject('user')
class snapshotDetail extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      loading: 'loading',
      data: {},
      oldData: undefined,
      detailList: [],
      libList: [],
      searchData: {},
      operationDetail: '',
      isRealAlarm: undefined,
      libType: undefined,
      handleVisible: false
    }
  }
  async componentDidMount() {
    const { location } = this.props
    const searchId = location.pathname.split('/').reverse()[0]
    const res = await LM_DB.get({ id: searchId })
    const { libType, isRealAlarm = false, list, searchData} = res
    let { alarmData={} } = res

    if(libType === 5 || libType === 6){
      this.querySameAlaramList(alarmData,searchData,isRealAlarm)
	  alarmData = this.vehicleDataCpy(alarmData) 
      this.setState({ libType, isRealAlarm, detailList: list, searchData, data: alarmData })
    }else{
      this.getDetail(searchId)
      this.setState({ libType, isRealAlarm, detailList: list, searchData})
    }
  }

  vehicleDataCpy(fieldObj){
    fieldObj.sceneUrl = fieldObj.scenePath;
    fieldObj.vehicleUrl = fieldObj.picPath;
    return fieldObj;
  }

  querySameAlaramList = async(data = {},searchData={},isRealAlarm) => {
    const { startTime, endTime } = searchData;
    // const logOption = {
    //   libType: this.state.libType,
    //   id: data.id
    // };
    const  alarmOperationType = isRealAlarm ? 2 : undefined
    const res = await Service.alarmResult.getTaskAlarmsResult({ startTime, endTime, taskId: data.taskId, plateNum: data.plateNum, alarmType: 2, alarmOperationType});
    this.setState({ alarmInfoList: res.data.list || [],loading:'over' });
  }

  getDetail = async id => {
    const { libType, isRealAlarm } = this.state
    const res = await Service.alarmResult.alarmResults({ libType, isRealAlarm, id })
    this.setState({ loading: 'over', data: res.data, operationDetail: res.data.operationDetail }, this.getAlarmList)
  }

  getAlarmList = async () => {
    const { libType } = this.state
    if (+libType === 1 || +libType === 4) {
      const option = { monitorPersonPictureId: this.state.data.infoId }
      const { data } = await Service.alarmResult.queryAlarmResults(option)
      this.setState({ alarmInfoList: data.list })
    }
    if (+libType === 2) {
      this.getLibs()
    }
  }

  updatePage = async (id, alarmData) => {
    const { history, location } = this.props
    const { libType, detailList, isRealAlarm, searchData } = this.state
    await LM_DB.put({ id, libType, list: detailList, isRealAlarm, searchData, alarmData })
    let locations = location.pathname.split('/').reverse()
    locations[0] = id
    history.replace(locations.reverse().join('/'))
  }

  // 跳转到人员库管理 若没有管理权限不给予跳转
  goLibDetail = async libId => {
    const { user, history, match } = this.props
    const res = await Service.monitorLib.queryMonitorLibDetail(libId)
    const managers = res.data.managers
    const userId = user.userInfo.id
    if (managers.find(v => v.id === userId)) {
      const locations = `${match.url.replace('outsiderDetail', 'outsiderMonitor')}/outsiderLibraryView`
      const location = {
        state: { id: libId },
        pathname: locations
      }
      history.push(location)
    }
  }

  getLibs = async () => {
    const { data } = this.state
    const res = await Service.monitorTask.queryMonitorTaskDetail(data.taskId)
    this.setState({ libList: res.data.libs })
  }

  handleChangeList = async id => {
    const { alarmInfoList,libType,searchData,isRealAlarm } = this.state;
    if(libType === 5 || libType === 6){
      const data = alarmInfoList.find(v => v.id === id);
      this.updatePage(data.id, data);
      this.setState({ data, operationDetail: data.operationDetail });
      this.querySameAlaramList(data,searchData,isRealAlarm);
    }else{
      await this.updatePage(id)
      this.getDetail(id)
    }
  }

  changeDetailView = async id => {
    const { detailList,libType,searchData,isRealAlarm } = this.state
    if(libType === 5 || libType === 6){
      const data = detailList.find(v => v.id === id);
      this.updatePage(data.id, data);
      this.setState({ data, operationDetail: data.operationDetail });
      this.querySameAlaramList(data,searchData,isRealAlarm);
    }else{
    await this.updatePage(id)
    await this.getDetail(id)
    this.setState({ oldData: detailList.find(v => v.id === id) })
    }
  }

  handleText = e => {
    const value = e.target.value
    if (value.length > 200) {
      return message.info('最大长度不超过200')
    }
    this.setState({ operationDetail: value })
  }

  handleOpenModal = type => {
    this.setState({ type, handleVisible: true })
  }

  onModalCancel = () => {
    this.setState({ handleVisible: false })
  }

  saveText = async () => {
    const { data, operationDetail, libType, isRealAlarm } = this.state
    if (operationDetail === data.operationDetail) return
    const option = [
      { id: data.id, operationDetail },
      { libType, isRealAlarm }
    ]
    let res={};
    if (libType === 5 || libType === 6) {
      const options = { id: data.id,operationDetail, isEffective: 1 };
      const logData = { libType };
      res = await Service.alarmResult.updateTaskAlarm(options, logData);
      // bug[8259], 扩展报警备注到data对象上，add by zhangyu 2020.4.15
      data.operationDetail = operationDetail;
    } else {
      res = await Service.alarmResult.handleAlarmResult(...option);
      this.setState({ data: res.data })
    }
    message.success('保存备注成功')
  }

  handleOk = async () => {
    const { data, type, detailList, libType, isRealAlarm, operationDetail, oldData } = this.state
    const option = [
      { id: data.id, isEffective: type, operationDetail },
      { libType, isRealAlarm }
    ]
    let res={};
    if (libType === 5 || libType === 6) {
      const options = { id: data.id, isEffective:type,operationDetail };
      const logData = { libType };
      res = await Service.alarmResult.updateTaskAlarm(options, logData);
      // bug[8259], 扩展报警处理结果到data对象上，add by zhangyu 2020.4.15
      data.isHandle = 1;
      data.operationDetail = operationDetail;
      data.isEffective = type;
      res.data = data;
    } else {
      res = await Service.alarmResult.handleAlarmResult(...option);
    }
    this.setState({ data: res.data, handleVisible: false }, () => {
      message.info('设置告警状态成功')
      // console.log(res.data)
      SocketEmitter.emit(SocketEmitter.eventName.resolveAlarm, res && res.data)
      if (detailList && detailList.length > 0) {
        const chose = detailList.find(v => (!!oldData ? v.id === oldData.id : v.id === data.id)) || {}
        const number = detailList.indexOf(chose)
        if (number < detailList.length && number > -1) {
          const nextDetail =(number===detailList.length-1)?detailList[number]:detailList[number+1]
          nextDetail && this.changeDetailView(nextDetail.id)
        } else {
          this.getAlarmList()
        }
      }
    })
  }

  getReactInfo = data => {
    const options = {
      vehicleRect: '',
      feature: ''
    };
    try {
      const json = JSON.parse(data.extraInfo);
      options.feature = json.vehicle_feature_base64;
      options.vehicleRect = json.vehicle_rect;
    } catch (e) {
      console.log('无特征');
    }
    return options;
  };

  render() {
    let { data = {}, type, handleVisible, alarmInfoList, libType, operationDetail, oldData, loading, libList, detailList = [] } = this.state
    let dataIndex = detailList.findIndex(v => (oldData ? v.id === oldData.id : v.id === data.id)),
      preData = undefined,
      nextData = undefined
    if (dataIndex > 0) {
      preData = detailList[dataIndex - 1]
      nextData = detailList[dataIndex + 1]
    }
    if (dataIndex === 0 && detailList.length > 1) {
      nextData = detailList[dataIndex + 1]
    }
    let HeaderView = headers.get(`alarm${libType}`)
    let detailType = 'personAlarm'
    if(libType === 5 || libType ===6 ){
      const { vehicleRect, feature } = this.getReactInfo(data);
      // debug [8053], modify by zhangyu 2020.04.14
      data.vehicleRect = vehicleRect
      data.feature = feature
      data.vehicleType = '0'
      detailType='vehicle'
    }
    // bug[8301] add by zhangyu, 2020.4.18
    let noticeText = libType === 3 ? "提醒" : "告警";
    // 255行bug[8079]"|| data.operationDetail", modify by zhangyu 2020.04.14
    const cid = data.cid || data.cameraId;
    const imgId = data.imgId || data.captureId || data.alarmImgId;
    const id = data.alarmObjId;
    return (
      <div className="baselib-detail-wrapper">
        <ProgressLoding status={loading} />
        <div className="b-container">
          <div className="obj-snapshot-detail" style={{ width: '100%', height: '100%', minHeight: 400 }}>
            {libType && (
              <HeaderView
                data={data}
                libList={libList}
                goLibDetail={this.goLibDetail}
                saveText={this.saveText}
                handleText={this.handleText}
                operationDetail={operationDetail || data.operationDetail}
                handleOpenModal={this.handleOpenModal}
                handleAuthName={libType === 5 ? 'vehicleTagsHandle' : 'vehicleTempHandle'}
              />
            )}
            <div className="picture-container">
              {preData && (
                <div className="nav-l">
                  <CommandCapturePage classNameNode="detail-text" pageType="pre" imgUrl={preData.faceUrl || preData.picPath} id={preData.id} onChange={this.changeDetailView} />{' '}
                </div>
              )}
              {nextData && (
                <div className="nav-r">
                  <CommandCapturePage classNameNode="detail-text" pageType="next" imgUrl={nextData.faceUrl || nextData.picPath} id={nextData.id} onChange={this.changeDetailView} />{' '}
                </div>
              )}
              <DetailPictureMap
                type={detailType}
                data={{ ...data, cid, imgId, id }}
                libType={libType}
                key={data.id}
                dataKey={'infoId'}
                getAid={this.getAid}
                base={this.props.base}
              />
            </div>
            {([1,4,5,6].includes(+libType)) && !!alarmInfoList && !!alarmInfoList.length && (
              <HorizontalScrollLayout
                size={6}
                data={alarmInfoList}
                currentIndex={dataIndex}
                className="key-ponit-horizont"
                renderItem={v => {
                  let item =  [
                    { info: v.deviceName || v.cameraName, icon: 'icon-S_Bar_Add' },
                    { info: v.captureTime ? Utils.formatTimeStamp(+v.captureTime) : '暂无', icon: 'icon-S_Edit_ClockEnd' }
                  ]
                  if(+libType === 5 || +libType === 6){
                    item.unshift({info: v.plateNum, icon: 'icon-S_Bar_Brand' })
                  }else if(+libType === 1){
                    item.unshift({info: Math.floor(data.score) + '%', icon: 'icon-S_Photo_Like' })
                  }
                  item.unshift({ icon:v.isHandle === 0? '':v.isEffective === 1 ? 'icon-S_Photo_ThumbEffective' : 'icon-S_Photo_ThumbInvalid',
                  info:v.isHandle === 0 ? '未处理':v.isEffective === 1 ?'有效':'无效'})
                   return <CaptureCard
                    key={v.id}
                    className="detail-box-item"
                    active={data.id === v.id ? true : false}
                    click={() => this.handleChangeList(v.id)}
                    imgUrl={(+libType === 5 || +libType === 6) ? v.picPath : v.faceUrl}
                    sourceData={v}
                    hoverScale={false}
                    data={item}
                  />}
                }
              />
            )}
          </div>
        </div>
        <Notice
          confirmTitle={`${+type === 1 ? '有' : '无'}效${noticeText}确认`}
          visible={handleVisible}
          onCancel={this.onModalCancel}
          onOk={this.handleOk}
          width={320}
          confirmText={`点击“确定”将其标注为${+type === 1 ? '有' : '无'}效${noticeText}`}
          iconType={+type === 1 ? 'icon-S_Photo_ThumbEffective' : 'icon-S_Photo_ThumbInvalid'}
        />
      </div>
    )
  }
}
export default snapshotDetail
