import React from 'react';
import HeaderBox from '../headerBox';
import moment from 'moment';
import { useGetVehicleBranch } from '../../../taskComponents/hooks';
import { getVehicleColor, getVehicleClasses, getVehicleBrand } from '../../../taskComponents/utils';
import './index.less';

const { Loader, BaseStore, Dict } = window;
const LabelValue = Loader.loadBaseComponent('LabelValue');
const AuthComponent = Loader.loadBusinessComponent('AuthComponent');
const Row = Loader.loadBaseComponent('Grid', 'Row');
const Col = Loader.loadBaseComponent('Grid', 'Col');
const { vehicleColor, plateColor, vehicleType, vehicleBrands } = Dict.map;

const outsiderHeader = ({ data = {}, saveText, handleText, score = 0, operationDetail, handleOpenModal, libList = [], goLibDetail }) => {
  const sceneCode = BaseStore.user.appInfo.sceneCode;
  const monitorLabel = Dict.map.monitorLabel[sceneCode];
  return (
    <HeaderBox
      score={score}
      saveText={saveText}
      handleText={handleText}
      operationDetail={operationDetail}
      handleOpenModal={handleOpenModal}
      data={data}
      handleAuthName="outsiderHandle"
      rightCenterP={
        <Row>
          <Col span={12}>
            <LabelValue label="所在布控任务" value={data.taskName} />
            <LabelValue label="告警设备名称" value={data.deviceName} />
            <LabelValue label="告警设备地址" value={data.address} />
            <LabelValue label="告警时间" value={data && moment(+data.captureTime).format('YYYY.MM.DD HH:mm:ss')} />
          </Col>
          <Col span={12}>
            <LabelValue
              label={monitorLabel.outsider.libLabel}
              value={
                libList.length > 0
                  ? libList.map((v) => {
                      return (
                        <span className="btn-box" key={v.id}>
                          <AuthComponent actionName="outsiderLibraryView" noAuthContent={<span className="btn-box-span">{v.name}</span>}>
                            <span style={{ cursor: 'pointer' }} className="btn-box-span" title={v.name} onClick={() => goLibDetail(v.id)}>
                              {v.name}
                            </span>
                          </AuthComponent>
                        </span>
                      );
                    })
                  : '-'
              }
            />
          </Col>
        </Row>
      }
    />
  );
};

const privateNetHeader = ({ data = {}, saveText, handleText, score = 0, operationDetail, handleOpenModal }) => {
  const { objectMainJson = {} } = data;
  return (
    <HeaderBox
      score={score}
      saveText={saveText}
      handleText={handleText}
      operationDetail={operationDetail}
      handleOpenModal={handleOpenModal}
      data={data}
      handleAuthName="privateNetHandle"
      rightCenterP={
        <>
          <LabelValue label="姓名" value={objectMainJson.name} />
          <LabelValue label="性别" value={objectMainJson.gender} />
          <LabelValue label="民族" value={objectMainJson.nationality} />
          <LabelValue label="身份证号" value={objectMainJson.identityNumber} />
          <LabelValue label="出生年月" value={objectMainJson.birthday} />
          <LabelValue label="所在布控库" value={data.libName} />
          <LabelValue label="所在布控任务" value={data.taskName} />
          <LabelValue label="告警设备名称" value={data.deviceName} />
          <LabelValue label="告警设备地址" value={data.address} />
          <LabelValue label="告警时间" value={data && moment(+data.captureTime).format('YYYY.MM.DD HH:mm:ss')} />
        </>
      }
    />
  );
};

const eventHeader = ({ data = {}, saveText, handleText, score = 0, operationDetail, handleOpenModal }) => {
  return (
    <HeaderBox
      score={data.score}
      saveText={saveText}
      handleText={handleText}
      operationDetail={operationDetail}
      handleOpenModal={handleOpenModal}
      data={data}
      isEvent={true}
      handleAuthName="eventHandle"
      rightCenterP={
        <>
          <LabelValue label="所在布控任务" value={data.taskName} />
          <LabelValue label="告警设备名称" value={data.deviceName} />
          <LabelValue label="告警设备地址" value={data.address} />
          <LabelValue label="告警时间" value={data && moment(+data.captureTime).format('YYYY.MM.DD HH:mm:ss')} />
        </>
      }
    />
  );
};

const focusHeader = ({ data = {}, saveText, handleText, score = 0, operationDetail, handleOpenModal }) => {
  const { objectMainJson = {} } = data;
  // bug[8239], "identityCardNumber", modify by zhangyu, 2020.4.14
  return (
    <HeaderBox
      score={data.score}
      saveText={saveText}
      handleText={handleText}
      operationDetail={operationDetail}
      handleOpenModal={handleOpenModal}
      data={data}
      handleAuthName="focusHandle"
      rightCenterP={
        <div style={{ width: '100%' }}>
          <Row>
            <Col span={12}>
              <LabelValue label="姓名" value={objectMainJson.name} />
              <LabelValue label="性别" value={objectMainJson.gender} />
              <LabelValue label="民族" value={objectMainJson.nationality} />
              <LabelValue label="身份证号" value={objectMainJson.identityCardNumber} />
              <LabelValue label="出生年月" value={objectMainJson.birthday} />
            </Col>
            <Col span={12}>
              <LabelValue label="所在布控库" value={data.libName} />
              <LabelValue label="所在布控任务" value={data.taskName} />
              <LabelValue label="告警设备名称" value={data.deviceName} />
              <LabelValue label="告警设备地址" value={data.address} />
              <LabelValue label="告警时间" value={data && moment(+data.captureTime).format('YYYY.MM.DD HH:mm:ss')} />
            </Col>
          </Row>
        </div>
      }
    />
  );
};

const vehicleHeader = ({ data = {}, saveText, handleText, operationDetail, handleOpenModal, handleAuthName }) => {
  const [ vehicleSourceData ] = useGetVehicleBranch();
  const { plateNum, vehicleTags = [], taskName, cameraName, address, captureTime } = data;
  vehicleColor.filter((v) => vehicleTags.includes(`${v.value}`)).map((v) => v.text);
  let vehicleHit = {};
  if(data.extraInfo){
    let extraInfoData = JSON.parse(data.extraInfo);
    vehicleHit = extraInfoData.vehicle_hit_rule || {};
  }
  let plateColorLabel = getVehicleColor(vehicleHit.plateColors || [], 'plateColor');
  let vehicleColorLabel = getVehicleColor(vehicleHit.vehicleColors || [], 'vehicleColor');
  let vehicleClasses = getVehicleClasses(vehicleHit.vehicleClasses || []);
  let vehicleBranch = getVehicleBrand(vehicleSourceData, vehicleHit.vehicleBrands || []);
  return (
    <HeaderBox
      saveText={saveText}
      handleText={handleText}
      operationDetail={operationDetail}
      handleOpenModal={handleOpenModal}
      data={data}
      isVehicle={true}
      handleAuthName={handleAuthName}
      rightCenterP={
        <Row>
          <Col span={6}>
            <p className="right-center-title">抓拍车辆：</p>
            <LabelValue label="车牌号码" value={plateNum} />
            <LabelValue
              label="车身颜色"
              value={vehicleColor
                .filter((v) => vehicleTags.includes(`${v.value}`))
                .map((v) => v.name)
                .join(',')}
            />
            <LabelValue
              label="车牌颜色"
              value={plateColor
                .filter((v) => vehicleTags.includes(`${v.value}`))
                .map((v) => v.name)
                .join(',')}
            />
            <LabelValue
              label="车辆类型"
              value={vehicleType
                .filter((v) => vehicleTags.includes(`${v.value}`))
                .map((v) => v.label)
                .join(',')}
            />
            <LabelValue
              label="车辆品牌"
              value={vehicleBrands
                .filter((v) => vehicleTags.includes(`${v.value}`))
                .map((v) => v.label)
                .join(',')}
            />
          </Col>
          <Col span={18}>
            <p className="right-center-title">布控信息：</p>
            <div className='lm-tl-vehicle-tags-tasks-detail-box'>
              <div className='tl-left'>
                <LabelValue label="车牌号码" value={vehicleHit.plateNo} />
                <LabelValue label="车身颜色" value={vehicleColorLabel} />
                <LabelValue label="车牌颜色" value={plateColorLabel} />
                <LabelValue label="车辆类型" value={vehicleClasses} />
                <LabelValue label="车辆品牌" value={vehicleBranch} />
              </div>
              <div className='tl-right'>
                <LabelValue label="所在布控任务" value={taskName} />
                <LabelValue label="告警设备名称" value={cameraName} />
                <LabelValue label="告警设备地址" value={address} />
                <LabelValue label="告警时间" value={data && moment(+captureTime).format('YYYY.MM.DD HH:mm:ss')} />
              </div>
            </div>
          </Col>
        </Row>
      }
    />
  );
};

const headers = new Map([
  ['alarm2', outsiderHeader],
  ['alarm1', focusHeader],
  ['alarm3', eventHeader],
  ['alarm4', privateNetHeader],
  ['alarm5', vehicleHeader],
  ['alarm6', vehicleHeader],
]);

export default headers;
