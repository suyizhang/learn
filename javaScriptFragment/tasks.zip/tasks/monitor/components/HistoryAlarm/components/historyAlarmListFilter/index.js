import React from 'react'
import AlarmTimeTypeSelect from './components/AlarmTimeTypeSelect'
import AlarmSiteScreening from './components/AlarmSiteScreening'
import AlarmStateSelect from './components/AlarmStateSelect'
import AlarmTimeSelect from './components/AlarmTimeSelect'

import './index.less'

const { Loader } = window;
const SearchInput = Loader.loadBaseComponent('Form', 'SearchInput')

class HistoryAlarmListFilter extends React.Component{


    render(){
        let { libType, searchData, searchDataChange , showSearchInput} = this.props;
        return(
            <div className="history-alarm-list-filter">
                <div className="left">
                    {[2,5,6].includes(libType)? '' :
                        <AlarmTimeTypeSelect
                            libType={libType}
                            searchData={searchData}
                            onTypeChange={searchDataChange}
                        />
                    }
                    <AlarmStateSelect
                        libType={libType}
                        searchData={searchData}
                        onTypeChange={searchDataChange}
                    />
                    <AlarmSiteScreening
                        libType={libType}
                        searchData={searchData}
                        onTypeChange={searchDataChange}
                    />
                    <AlarmTimeSelect 
                        searchData={searchData}
                        onTypeChange={searchDataChange}
                    />
                </div>
                <div className="right">
                    {showSearchInput && (
                        <SearchInput
                            onChange={value => searchDataChange({ monitorPersonKeywords: value, offset:0 })}
                            placeholder="请输入姓名或身份证号搜索"
                        />
                    )}
                </div>
            </div>
        )
    }
}

export default HistoryAlarmListFilter