import React from 'react';
import { itemGrid, offsetOptions } from '../../../alarmGridConfig';
import moment from 'moment';
import HistoryAlarmListFilter from '../historyAlarmListFilter';
import { Icon, message } from 'antd';
import './index.less';

const { Loader, Service, Utils, BaseStore, LM_DB, SocketEmitter } = window;
const InfiniteScrollLayout = Loader.loadBaseComponent('List', 'InfiniteScrollLayout');
const Portal = Loader.loadBaseComponent('Portal');
const Button = Loader.loadBaseComponent('Form', 'Button');
const Progress = Loader.loadBaseComponent('Progress');
const ListBox = Loader.loadBaseComponent('Box', 'ListBox');
const AlarmTwoImgCard = Loader.loadBaseComponent('Card', 'AlarmTwoImgCard');
const AlarmOneImgCard = Loader.loadBaseComponent('Card', 'AlarmOneImgCard');
const Notice = Loader.loadBusinessComponent('Modal', 'Notice');
const VehicleCard = Loader.loadBaseComponent('Card', 'VehicleCard');

const searchData1 = {
  //人员
  startTime: undefined,
  endTime: undefined,
  timeType: undefined,
  alarmOperationType: undefined,
  taskIds: undefined,
  monitorPersonKeywords: undefined,
  installationSites: undefined,
  noInstallationSites: undefined,
  libIds: [],
  sort: ['captureTime|desc'],
  captureUids: '',
  offset: 0,
  limit: 60
};
const searchData2 = {
  //车辆
  startTime: undefined,
  endTime: undefined,
  taskId: undefined,
  cids: [],
  taskIds: [],
  offset: 0,
  limit: 60,
  alarmType: 2
};
class HistoryAlarmList extends React.Component {
  constructor(props) {
    super(props);
    this.listRef = React.createRef();
    let data = props.libType === 5 || props.libType === 6 ? searchData2 : searchData1;
    this.newList = [];
    this.state = {
      list: [],
      total: 0,
      hasLoadMore: false,
      loading: 'over',
      modalItem: {}, // 设置的item数据
      handleVisible: false, // 设置有效无效弹窗
      isEffective: 1, // 有效无效
      searchData: data
    };
  }

  componentDidMount() {
    const { libType, taskIds } = this.props;
    let params = {};
    if (![5, 6].includes(libType)) {
      params = this.mergeSearchData({
        sort: libType === 2 ? undefined : ['captureTime|desc'],
        alarmTypes: [libType],
        taskIds: taskIds,
        offset: 0
      });
    }
    let options = this.mergeSearchData(params);
    this.init(options, true);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (this.props.taskIds && nextProps.taskIds !== this.props.taskIds) {
      if (nextProps.taskIds.length > 0) {
        let options = this.mergeSearchData({ taskIds: nextProps.taskIds, offset: 0 });
        this.init(options, true);
      } else {
        this.setState({ list: [], total: 0, hasLoadMore: false });
      }
    }
  }

  componentWillMount() {
    SocketEmitter.on(SocketEmitter.eventName.resolveAlarm, this.updateCard)
  }

  componentWillUnmount() {
    SocketEmitter.off(SocketEmitter.eventName.resolveAlarm, this.updateCard)
  }

  updateCard = data => {
    let { list } = this.state;
    let item = list.find(v => v.id === data.id);
    if (item) {
      item.isEffective = data.isEffective;
      item.isHandle = 1;
      this.setState({ list }, () => {
        this.listRef.current.forceUpdateGrid();
      });
    }
  };

  /**
   * 更新参数
   * @param {*} options
   */
  mergeSearchData(options) {
    const searchDataNew = Object.assign({}, this.state.searchData, options);
    // console.log('newsearchData', searchDataNew)
    this.setState({ searchData: searchDataNew });
    return searchDataNew;
  }

  /**
   * 筛选条件更改
   */
  searchDataChange = options => {
    // let { libType } = this.props;
    let params = this.mergeSearchData({ ...options, offset: 0 });
    // if (libType === 3 || libType === 5 || libType === 6) {
    //   if (!options.startTime || !options.endTime) {
    //     params.endTime = moment().valueOf();
    //     params.startTime = moment()
    //       .subtract(1, 'year')
    //       .set({ hour: 0, minute: 0, second: 0 })
    //       .valueOf();
    //   }
    // }

    this.init(params, true);
  };

  init(option, isChange) {
     //6.11日修改日期bug格式化
   option = JSON.parse(JSON.stringify(option))
   if(!option.startTime)  option.startTime = moment().subtract(1, 'years').set({ hour: 0, minute: 0, second: 0 }).valueOf()
   if(!option.endTime)  option.endTime = moment().valueOf()
   
    if (option.taskIds.length <= 0) {
      return false;
    }
    this.setState({ loading: 'loading' });
    let { list } = this.state;
    const { libType } = this.props;
    let hasLoadMore = false;
    // params因为要setState,所以这里不能直接改params
    let vehicleParams = JSON.parse(JSON.stringify(option));
    if (libType === 5 || libType === 6) {
      vehicleParams.plateNum = vehicleParams.monitorPersonKeywords;
      delete vehicleParams.monitorPersonKeywords;
      if (!!vehicleParams.installationSites && !!vehicleParams.installationSites.length) {
        vehicleParams.placeTags = vehicleParams.installationSites;
        delete vehicleParams.installationSites;
      } else {
        delete vehicleParams.installationSites;
        delete vehicleParams.placeTags;
      }
    }
    Service.alarmResult[libType === 5 || libType === 6 ? 'getTaskAlarmsResult' : 'queryAlarmResults'](libType === 5 || libType === 6 ? vehicleParams : option)
      .then(res => {
        if (res.code === 0) {
          let newData = res.data.list || [];
          hasLoadMore = newData.length >= limit ? true : false;
          this.newList = this.newList.concat(newData);
          hasLoadMore && this.mergeSearchData({ offset: offset + limit });
          let temp = isChange ? newData : (list.concat(newData))
          this.setState({
            list: temp,
            loading: 'over',
            hasLoadMore
          });
        } else {
          this.setState({ loading: 'error' });
          message.error(res.message);
        }
      })
      .catch(e => {
        message.error(e.message);
        this.setState({ loading: 'error' });
      });
    const { limit, offset } = option;
    Service.alarmResult[libType === 5 || libType === 6 ? 'countTaskAlarmsResult' : 'countAlarmResults'](option).then(res => {
      this.setState({ total: res.data.total });
    });
  }

  // 加载更多
  loadMore = () => {
    let { searchData } = this.state;
    return this.init(searchData, false);
  };

  /**刷新 */
  refresh = () => {
    let options = this.mergeSearchData({ offset: 0 });
    this.init(options, true);
  };

  handlePageJump = async item => {
    let { searchData, list } = this.state;
    let { libType, alarmType, base, history } = this.props;
    let moduleName = 'focusDetail';
    if (libType * 1 === 1) {
      moduleName = 'focusDetail';
    } else if (libType * 1 === 2) {
      moduleName = 'outsiderDetail';
    } else if (libType * 1 === 3) {
      moduleName = 'eventDetail';
    }
    if (libType === 5 || libType === 6) {
      searchData = {
        startTime: moment()
          .subtract(1, 'years')
          .valueOf(),
        endTime: moment().valueOf(),
        taskId: undefined,
        cids: [],
        taskIds: [],
        offset: 0,
        limit: 40,
        alarmType: 2
      };
      alarmType = 2;
      moduleName = 'vehicleTagsDetail'; // 跳转车辆标签详情
    }
    for (let i in searchData) {
      if (!searchData[i]) {
        delete searchData[i];
      }
    }
    const findIndex = list.findIndex(v => v.id === item.id);
    if (findIndex > -1) {
      const number = Math.floor(findIndex / searchData.limit);
      searchData.offset = number * searchData.limit;
    }
    if (BaseStore.menu.getInfoByName(moduleName)) {
      await LM_DB.put({
        id: item.id.toString(),
        libType,
        list,
        alarmType,
        isRealAlarm: false,
        alarmData: list[findIndex],
        searchData
      });
      const pathname = `${base}/${moduleName}/${BaseStore.tab.createTabKey()}/${item.id}`;
      history.push(pathname);
    } else {
      message.warn('暂无告警详情查看权限');
    }
  };

  handleChangeYN = (item, isEffective) => {
    this.setState({
      modalItem: item,
      handleVisible: true,
      isEffective
    });
  };

  handleCancel = () => {
    this.setState({
      modalItem: {},
      handleVisible: false
    });
  };

  /**
   * 设置有效、无效
   */
  handleEffective = async (operationDetail = undefined) => {
    let { modalItem, isEffective, list } = this.state;
    const { libType } = this.props;
    let res;
    if (libType === 5 || libType === 6) {
      const options = { id: modalItem.id, isEffective };
      const logData = { libType };
      res = await Service.alarmResult.updateTaskAlarm(options, logData);
    } else {
      res = await Service.alarmResult.handleAlarmResult({ id: modalItem.id, isEffective, operationDetail }, { libType });
    }
    if (res.code === 0) {
      message.info('设置' + (libType === 3 ? '' : '告警状态') + '成功');
      //更新警情
      let listItem = list.find(v => v.id === modalItem.id);
      if (listItem) {
        listItem.isHandle = 1;
        listItem.isEffective = isEffective;
        SocketEmitter.emit(SocketEmitter.eventName.resolveAlarm, listItem);
      }
      this.handleCancel();
      // 更新布控告警列表的告警数量
      this.setState({ list }, () => {
        this.listRef && this.listRef.current && this.listRef.current.forceUpdateGrid();
      });
    }
  };

  getButtonContent(total) {
    return (
      <div className="history-alarm-top-right">
        <span className="header-text">
          共显示
          <b className="text-red"> {total && Utils.thousand(+total)} </b>
          条资源
        </span>
        <Button className="refresh_btn" onClick={this.refresh}>
          <Icon type="reload" /> 刷新
        </Button>
      </div>
    );
  }

  getGrid = libType => {
    let grid = {};
    switch(libType) {
      case 1 :
        grid = itemGrid.large;
        break;
      case 5 :
        grid = itemGrid.vehicle;
        break;
      case 6 :
        grid = itemGrid.vehicle;
        break;
      default :
        grid = itemGrid.normal;
        break;
    }
    return grid;
  }

  render() {
    let { libType, actionName } = this.props;
    let { list, loading, total, searchData, handleVisible, isEffective, hasLoadMore } = this.state;
    const libLabel = libType !== 3 ? '告警' : '提醒';
    let grid = this.getGrid(libType);
    return (
      <div className="history-alarm-list-box">
        <Progress status={loading} />
        <Portal getContainer={this.props.getHeaderRightExtContent} content={this.getButtonContent(total)} />
        <HistoryAlarmListFilter libType={libType} searchData={searchData} showSearchInput={libType === 1 ? true : false} searchDataChange={this.searchDataChange} />
        <ListBox offsetOptions={libType === 1 ? offsetOptions.large : offsetOptions.normal} className={'history-alarm-list'}>
          <InfiniteScrollLayout
            gutter={10}
            itemGrid={grid}
            loadMore={this.loadMore}
            hasLoadMore={hasLoadMore}
            data={list}
            ref={this.listRef}
            itemHeight={libType === 1 ? 340 : libType === 5 || libType === 6 ? 352 : 300}
            isNoData={(loading === 'over' || loading === 'error') && list.length === 0}
            hasBackTop={true}
            renderItem={item =>
              libType === 1 ? (
                <AlarmTwoImgCard
                  sourceData={item}
                  alarmType={libType}
                  isActual={true}
                  actionName={actionName}
                  click={this.handlePageJump}
                  handleChangeYN={this.handleChangeYN.bind(this)}
                  className='history-alarm-list-focus-card'
                />
              ) : libType === 5 || libType === 6 ? (
                <VehicleCard libType='vehicleTags' isActual={true} data={item} height={352} handleChangeYN={this.handleChangeYN} handlePageJump={this.handlePageJump} />
              ) : (
                <AlarmOneImgCard
                  sourceData={item}
                  alarmType={libType}
                  isActual={true}
                  click={this.handlePageJump.bind(this)}
                  imgUrl={item.faceUrl}
                  actionName={actionName}
                  score={libType === 2 ? item.score : null}
                  handleChangeYN={this.handleChangeYN.bind(this)}
                  data={[
                    { info: item.deviceName || '暂无', icon: 'icon-S_Bar_Add' },
                    { info: Utils.formatTimeStamp(item.captureTime) || '暂无', icon: 'icon-S_Edit_ClockEnd' },
                    { info: item.taskName || '暂无', icon: 'icon-S_Bar_Layer' }
                  ]}
                />
              )
            }
          />
        </ListBox>

        <Notice
          confirmText={''}
          endMark={''}
          visible={handleVisible}
          onCancel={this.handleCancel}
          onOk={this.handleEffective}
          confirmTitle={isEffective === 1 ? `有效${libLabel}确认` : `无效${libLabel}确认`}
          desc={`点击“确定”将其标注为${isEffective === 1 ? '有' : '无'}效${libLabel}？`}
          iconType={isEffective === 1 ? 'icon-S_Photo_ThumbEffective' : 'icon-S_Photo_ThumbInvalid'}
        />
      </div>
    );
  }
}

export default HistoryAlarmList;
