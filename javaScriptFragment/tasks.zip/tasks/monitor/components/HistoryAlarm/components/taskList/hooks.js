
import React , { useEffect, useState, useRef } from 'react'
import TaskListFilter from '../taskListFilter'
import { Popover, Checkbox, message } from 'antd'
import './index.less'

const { Loader, Service, Utils } = window

const SimpleList = Loader.loadBaseComponent('List', 'SimpleList')
const SearchInput = Loader.loadBaseComponent('Form', 'SearchInput')
const IconFont = Loader.loadBaseComponent('IconFont')
const Notice = Loader.loadBusinessComponent('Modal', 'Notice')

const statusMap = [
    {
      value: -1,
      statusLabel: '全部'
    },
    {
      value: 0,
      statusLabel: '已暂停',
      statusCls: 'be-paused'
    },
    {
      value: 1,
      statusLabel: '运行中',
      statusCls: 'be-running'
    },
    {
      value: 2,
      statusLabel: '未开始',
      statusCls: 'out-of-date'
    },
    {
      value: 3,
      statusLabel: '已过期',
      statusCls: 'out-of-date'
    },
    {
      value: 4,
      statusLabel: '已删除',
      statusCls: 'be-deleted'
    }
  ]

function TaskList(props){
    let { list = [], alarmCheckAll, checkAll = false, searchData, changeSearchData, 
        taskIds = [], changeAlarmTask } = props;
    const listRef = useRef();
    const [confirmVisible, setConfirmVisible] = useState(false);
    const [confirmOptions, setConfirmOptions] = useState(false);
    
    useEffect(() => {
        listRef && listRef.current && listRef.current.forceUpdateGrid()
    }, [taskIds])

    //判断布控任务状态
    function taskTypeStr(item) {
        const statusData = statusMap.find(v => v.value === item.taskStatus)
        return statusData
    }

    /*设置忽略/取消忽略他人授权的布控任务报警 */
    function setWhetherIgnoreAlarm (e, data) {
      const { libType } = props;
      const proName = (libType === 5 || libType === 6) ? 'isPush' : 'ignore';
        Utils.stopPropagation(e)
        let confirmOptions = {
            taskId: data.id,
            [proName]: data[proName === 'ignore' ? 'ignoreStatus' : 'isPush'] === 0 ? 1 : 0
        }
        setConfirmVisible(true)
        setConfirmOptions(confirmOptions)
    }

    // 设置忽略/取消忽略他人授权的布控任务报警 --- 二次确认取消
    function handleCancelIgnoreStatus(){
        setConfirmVisible(false)
        setConfirmOptions({})
    }
    // 设置忽略/取消忽略他人授权的布控任务报警 --- 二次确认确认修改
    function handleOkIgnoreStatus(){
      const { libType } = props;
      Service.monitorTask[(libType === 5 || libType === 6) ? 'updateTaskPush' : 'setWhetherIgnoreAlarm'](confirmOptions).then(res => {
          if (res.code === 0) {
              message.success('设置成功')
              setConfirmVisible(false)
              changeSearchData && changeSearchData(searchData, false)
          }
      })
    }


    // 渲染布控任务列表项
    function renderItem (v) {
      const { libType } = props;
      v.alarmStatus = v[(libType === 5 || libType === 6) ? 'isPush' : 'ignoreStatus'];
        const { statusCls, statusLabel } = taskTypeStr(v)
        return (
            <div className={`task-item ${taskIds.find(item => item === v.id) && 'active'}${checkAll ? 'check-all' : ''}`} onClick={() => changeAlarmTask(v.id)}>
            <p className="title-name" title={v.name || v.taskName}>
                {v.name || v.taskName}
            </p>
            <div className="item-content">
                <div className="item-status">
                <span className={`status ${statusCls}`} /> <span> {statusLabel} </span>
                </div>
                <div className="item-num">
                <span className="num"> {v.unhandledAlarmCount ? Utils.thousand(+v.unhandledAlarmCount) : 0}</span>
                {v.taskStatus === 1 && (
                    <IconFont
                    title={`${v.alarmStatus === 0 ? '关闭' : '开启'}实时提醒`}
                    onClick={e => setWhetherIgnoreAlarm(e, v)}
                    type={v.alarmStatus === 0 ? 'icon-S_Photo_AlarmOpen' : 'icon-S_Photo_AlarmClose'}
                    />
                )}
                </div>
            </div>
            </div>
        )
    }
    return (
        <div className="alarm-list-wrapper">
          <div style={{ padding: 15 }}>
            <SearchInput placeholder={'请输入任务名称搜索'} onChange={name => changeSearchData({ name })} />
          </div>
  
          <TaskListFilter searchData={searchData} changeSearchData={changeSearchData} />
          <div className="task-title">
            <span className="task-title-text"> 任务列表： </span>
            {list && list.length > 0 && (
              <div className="task-title-checkbox">
                <span className="checkbox-span"> 全部显示 </span>
                <Popover overlayClassName={'checkbox-span-pop'} placement="bottom" content={<div className="checkbox-span-pop-div"> 请选择下面列表查看单个任务告警 </div>}>
                  <Checkbox onChange={alarmCheckAll} checked={checkAll} />
                </Popover>
              </div>
            )}
          </div>
          <div className="task-list">
            <SimpleList ref={listRef} data={list} rowHeight={68} renderItem={renderItem} />
          </div>
          <Notice
            confirmText={''}
            endMark={''}
            visible={confirmVisible}
            onCancel={handleCancelIgnoreStatus}
            onOk={handleOkIgnoreStatus}
            confirmTitle={`${!!confirmOptions.ignore + !!confirmOptions.isPush === 0 ? '开启' : '关闭'}实时提醒确认`}
            desc={`点击“确认”${!!confirmOptions.ignore + !!confirmOptions.isPush === 0 ? '开启' : '关闭'}该任务的实时提醒`}
            iconType={!!confirmOptions.ignore + !!confirmOptions.isPush === 1 ? 'icon-S_Photo_AlarmClose' : 'icon-S_Photo_AlarmOpen'}
          />
        </div>
      )
}

export default TaskList;