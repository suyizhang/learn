import React, { Component } from 'react'
import _ from 'lodash'
import TaskList from './components/taskList'
import HistoryAlarmList from './components/historyAlarmList'
import { message } from 'antd'

const { Loader, Service } = window
const TwoColumnLayout = Loader.loadBaseComponent('Layout', 'TwoColumnLayout')

class HistoryAlarm extends Component {
  constructor(props) {
    super(props)
    const { taskTypes } = props
    // this.searchList = Shared.searchList(searchList);
    this.state = {
      taskIds: [], // 选中的任务ids
      checkAll: true, //全选状态
      searchData: {
        queryType: 1, // 任务来源
        taskStatuses: [1], // 任务状态
        name: '', // 搜索框
        taskTypes: [taskTypes],
        limit: 500
      }
    }
  }

  alarmAllIds = []

  componentDidMount() {
    const { taskTypes } = this.props
    this.changeSearchData({ taskTypes: [taskTypes] }, true)
  }

  componentWillReceiveProps(nextProps){
    if(nextProps.match!==this.props.match){
      const { taskTypes } = this.props
    this.changeSearchData({ taskTypes: [taskTypes] }, true);//更新的时机
    }
  }

  changeSearchData = (options, isChangeActive = true) => {
    let searchData = { ...this.state.searchData, ...options }
    this.setState({ searchData })
    let param = _.cloneDeep(searchData)
    if (param.taskStatuses[0] === -1) {
      delete param.taskStatuses
    }
    this.getTaskList(param, isChangeActive);
  }

  /**根据条件查询任务列表 */
  getTaskList = (option, isChangeActive) => {
    const {libType} = this.props
    let { queryType, name, taskTypes } = option;
    const isAlarm = true;
    let data = Object.assign({}, option);
    if (libType === 5 || libType === 6) {
      const source = queryType === 1 ? 0 : queryType === 4 ? 1 : queryType === 5 ? 2 : undefined;
      data = Object.assign(
        {},
        { taskTypes, taskName: name, limit: 500, offset: 0, taskStatus: data.taskStatuses ? data.taskStatuses[0] : undefined },
        { type: 1, source }
      ); 
    }
    return Service.monitorTask[(libType === 5 || libType === 6) ? 'getTasks' : 'queryMonitorTasks'](data, isAlarm).then(res => {  
      if (res.code === 0) {
        let list = res.data && res.data.list
        let taskIds = list.length > 0 ? list.map(v => v.id) : []
        isChangeActive && this.getAlarmHistoryId(taskIds)
        if (taskIds.length > 0) {
          let requestParams = taskIds, serviceName = 'countTaskUnhandledNum';
          if (libType === 5 || libType === 6) {
            requestParams = {
              isHandle: 0,
              taskIds
            }
            requestParams.isHandle = 0;
            serviceName = 'countAlarmByTaskId'
          }
          Service.monitorTask[serviceName](requestParams).then(res => {
            if (!res.data) {
              this.setState({ list })
              return
            }
            list.forEach(item => {
              if (res.data[item.id]) {
                item.unhandledAlarmCount = res.data[item.id]
              }
            })
            this.setState({ list })
          })
        } else {
          this.setState({ list })
        }
      } else {
        message.error('布控任务列表查询失败')
      }
    })
  }

  getAlarmHistoryId(taskIds) {
    //布控告警所有id-全局设置, 初始全部选中
    this.alarmAllIds = taskIds
    this.setState({
      taskIds,
      checkAll: true
    })
  }

  // 布控任务选中
  changeAlarmTask = id => {
    const taskIds = [id]
    const checkAll = this.alarmAllIds.length === 1
    this.setState({
      taskIds,
      checkAll
    })
    // console.log('taskIds---', taskIds)
  }

  // 全选
  alarmCheckAll = e => {
    let checkValue = e.target.checked
    this.setState({
      taskIds: checkValue ? this.alarmAllIds : [],
      checkAll: checkValue
    })
    // console.log('taskIds---', checkValue ? this.alarmAllIds : [])
  }

  render() {
    let { taskIds, searchData, checkAll, list } = this.state
    let { libType, ...props } = this.props
    return (
      <TwoColumnLayout
        className={`event-real-notify`}
        leftContent={
          <TaskList
            taskIds={taskIds}
            list={list}
            libType={libType}
            searchData={searchData}
            checkAll={checkAll}
            alarmCheckAll={this.alarmCheckAll}
            changeAlarmTask={this.changeAlarmTask}
            getTaskList={this.getTaskList}
            changeSearchData={this.changeSearchData}
          />
        }
      >
        <HistoryAlarmList {...props} libType={libType} taskIds={taskIds} />
      </TwoColumnLayout>
    )
  }
}
export default HistoryAlarm
