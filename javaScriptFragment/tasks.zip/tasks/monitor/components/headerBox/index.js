import React from 'react';
import { Progress } from 'antd';
import './index.less';

const { Loader } = window;
const ImageView = Loader.loadBaseComponent('ImageView');
const AuthComponent = Loader.loadBusinessComponent('AuthComponent');
const TextArea = Loader.loadBaseComponent('Form', 'TextArea');
const Button = Loader.loadBaseComponent('Form', 'Button');
const IconFont = Loader.loadBaseComponent('IconFont');

class HeaderBox extends React.Component {
  render() {
    let { data = {}, handleText, operationDetail, handleOpenModal, rightCenterP, saveText, score, isEvent, isVehicle, handleAuthName = 'keyPersonnelHandle' } = this.props;
    return (
      <>
        <div className="vehicle-tags-alarm-detail-header">
          <div className="alarm-detail-left">
            <div className="left-img">
              {data.imageUrl && (
                <div className="detailed-Cloth">
                  <div className="cloth-img">
                    <ImageView src={data.imageUrl} type="multiple" hasErrorImageStyle={false} />
                  </div>
                  <p className="cloth-p">布控人脸</p>
                </div>
              )}
              {(data.faceUrl || data.bodyUrl || data.picPath) && (
                <div className="detailed-Cloth">
                  <div className="cloth-img">
                    <ImageView src={data.faceUrl || data.bodyUrl || data.picPath} type="multiple" hasErrorImageStyle={false} />
                  </div>
                  <p className="cloth-p">{isEvent ? '抓拍人体' : isVehicle ? '抓拍车辆' : '抓拍人脸'}</p>
                </div>
              )}
              {data.isHandle === 1 && <div className={`monitore-detailed_rotate ${data.isEffective === 0 ? 'rotate_no' : 'rotate_yes'} `} />}
            </div>
            {!!score && (
              <div className="header-progress alarm-score-progress">
                <span className="progress-span">相似度</span>
                <Progress percent={data.score && Math.floor(data.score)} status="active" strokeWidth={2} />
              </div>
            )}
          </div>
          <div className="alarm-detail-right">
            <AuthComponent actionName={handleAuthName}>
              <div className="header-bottom">
                <div className="buttons">
                  <div className="detail-text">
                    <TextArea
                      className="detail-input"
                      placeholder={'请输入警情备注，最大长度不超过200'}
                      style={{ resize: 'none' }}
                      maxLength={201}
                      rows={4}
                      onChange={handleText}
                      value={operationDetail}
                    ></TextArea>

                    <span className="save" onClick={() => saveText()}>
                      {data.isHandle === 0 ? (
                        <>
                          <IconFont type="icon-S_Edit_Copy" /> 保存
                        </>
                      ) : (
                        <>
                          <IconFont type="icon-S_Edit_Copy" /> 编辑
                        </>
                      )}
                    </span>
                  </div>
                  {data.isHandle === 0 && (
                    <AuthComponent actionName={handleAuthName}>
                      <div className="detail_header_button">
                        <Button className="header_btn" onClick={() => handleOpenModal(0)}>
                          <IconFont type={'icon-S_Photo_ThumbInvalid'} theme="outlined" />
                          无效
                        </Button>
                        <Button className="header_btn" onClick={() => handleOpenModal(1)}>
                          <IconFont type={'icon-S_Photo_ThumbEffective'} theme="outlined" />
                          有效
                        </Button>
                      </div>
                    </AuthComponent>
                  )}
                </div>
              </div>
            </AuthComponent>
            <div className="right-center">{rightCenterP}</div>
          </div>
        </div>
      </>
    );
  }
}

export default HeaderBox;
