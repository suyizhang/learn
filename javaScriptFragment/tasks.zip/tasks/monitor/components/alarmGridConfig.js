
export const itemGrid = {
    normal: {
      xxl: 3, // ≥1600px
      xl: 4, // ≥1200px
      lg: 6, // ≥992px
      md: 8, // ≥768px
      sm: 8, // ≥576px 
      xs: 12, // <576px 
    },
    large: {
      xxl: 6, // ≥1600px
      xl: 8, // ≥1200px
      lg: 12, // ≥992px
      md: 12, // ≥768px
      sm: 12, // ≥576px
      xs: 24, // <576px 
    },
    vehicle: {
      xxl: 3, // ≥1600px
      xl: 6, // ≥1200px
      lg: 6, // ≥992px
      md: 8, // ≥768px
      sm: 8, // ≥576px 
      xs: 12, // <576px 
    }
};
export const offsetOptions = {
    normal: {
        xxl: 0, // ≥1600px
        xl: 2, // ≥1200px
        lg: 0, // ≥992px
        md: 1, // ≥768px
        sm: 0, // ≥576px
        xs: 2, // <576px 
      },
      large: {
        xxl: 2, // ≥1600px
        xl: 1, // ≥1200px
        lg: 2, // ≥992px
        md: 1, // ≥768px
        sm: 0, // ≥576px
        xs: 4, // <576px 
      }
}