import React from 'react';
import HistoryAlarm from '../components/HistoryAlarm';
import Task from '../../taskComponents';
const { Loader, BaseStore } = window;
const StaticRoute = Loader.loadBusinessComponent('AppRoute', 'StaticRoute');

class VehicleTags extends React.Component {
  constructor(props){
    super(props);
    this.tabList = [
      {
        title: '历史告警',
        icon: 'icon-S_Bar_Alarm',
        name: 'vehicleTagsHistory',
        content: <HistoryAlarm libType={5} taskTypes="101526" actionName={'vehicleTagsHandle'} />
      },
      {
        title: '任务管理',
        icon: 'icon-S_View_Task',
        name: 'vehicleTagsTask', 
        content: <Task
          type='vehicelTags'
        />
      }
    ] 
    // tip: 权限判断后期补加
    this.tabList.forEach((v, i) => {
      let target = BaseStore.menu.getInfoByName(v.name);
      if (!target) {
        this.tabList.splice(i, 1);
      }
    });
    this.state = {
      activeKey: this.tabList[0].name
    }
  }

  componentDidMount() {
    const { history, match, location } = this.props;
    let lastName = location.pathname.split('/').pop();
    if (!this.tabList.find(v => v.name === lastName)) {
      location.pathname = `${match.url}/${this.tabList[0].name}`;
      location.state = Object.assign({}, location.state);
      history.replace(location);
    }
  }
  render(){
    const { activeKey } = this.state;
    const { match, ...rest } = this.props;
    return <StaticRoute {...rest} defaultKey={activeKey} path={`${match.url}/:module`} match={match} onTabChange={this.onTabChange} tabList={this.tabList} isRightHead={true} />;
  }
}
export default VehicleTags;