function count(x, y) {
  return x - y;
}

export default count;
