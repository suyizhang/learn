export const name = 'jack';
export const age = 18;
